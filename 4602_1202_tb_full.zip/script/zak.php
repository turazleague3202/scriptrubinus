<?

    include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';
    
if(!$user) {

  header('location: /');
    
exit;

}

    $title = 'zakrito';    

include './system/h.php';

?>

    <div class="content">
    <div class="block center color3 s125"> Тех.работы</div>
            <div class="line"></div>

<div class="dotted"></div>
<center>
  <img src="/images/title/log.jpg" width="230" height="85" alt=""> 
<br>

Ведутся тех.работы Приносим свои извинения за неудобства.</center>
<div class="dotted"></div>
        <div class="block center">
  <span class="m3 btn_start middle"><span class="btn_end"><a class="btn" href="?">Обновить</a></span> </span> </div>
</div>

<?

include './system/f.php';

?>