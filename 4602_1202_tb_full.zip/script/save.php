<?
    include './system/common.php';

 include './system/functions.php';

      include './system/user.php';

if(!$user) {

  header('location: /');

exit;
}

if($user['save'] == 1) {

  header('location: /');
  exit;
}

$title = 'Сохранение';    
include './system/h.php';  


   $login = _string($_POST['login']);

$password = _string($_POST['password']);

$sex=_string($_POST['sex']);

$r=_string($_POST['r']);

$email = _string($_POST['email']); 

if($login && $password && $email) {

 

  if(!preg_match('/[a-z0-9]{2,10}/i', $password)) $errors[] = 'Ошибка, пароль введен неверно';



  if(strlen($login)<2 OR strlen($login)>30)$errors='Ошибка, длина погоняло должно быть 2-20 символов';

if(mysql_result(mysql_query('SELECT COUNT(*) FROM `users` WHERE `login` = \''.$login.'\''),0) != 0) $errors = 'Ошибка, выбранное погоняло уже занято';  

  if(mysql_result(mysql_query('SELECT COUNT(*) FROM `users` WHERE `email` = \''.$email.'\''),0) != 0) $errors = 'Ошибка, такой E-mail уже занят !';

  

  if($errors) {

echo '<div class="alert">';
          echo $errors;
echo '</div><div class="alert_bottom"></div>';
  }
  else
  {
    mysql_query('UPDATE `users` SET `login` = \''.$login.'\', `password` = \''.md5($password).'\',
`email` = \''.$email.'\', `save` = \'1\', `r`=\''.$r.'\', `sex`=\''.$sex.'\', `g` = `g` + 1250, `s` = `s` + 5500 WHERE `id` = \''.$user['id'].'\'');
    setCookie('password', md5($password), time() + 86400, '/');
    header('location: /menu');
  }
}


?>

<div class="content"><div class="block center color3 s125"><a href="/save?nocache=666272825">Сохранение</a>/ Персонаж</div>
            <div class="line"></div><div class="block">

<form action="/save/?" method="post">
    <div class="form-group field-saveavatar-name required">
<label class="control-label" for="saveavatar-name">Погоняло</label>
<input type="text" id="saveavatar-name" class="form-control" name="login" value="<?=$login?>">
<label class="control-label" for="saveavatar-name">Пароль</label>
<input type="text" id="saveavatar-name" class="form-control" name="password" value="<?=$password?>">
<label class="control-label" for="saveavatar-name">Email</label>
<input type="text" id="saveavatar-name" class="form-control" name="email" value="<?=$email?>">
<div class="help-block"></div>
</div>    <div class="form-group field-saveavatar-sex required">
<label class="control-label" for="saveavatar-sex">Пол</label>
<select id="saveavatar-sex" class="form-control" name="r">
<option value="0">Мужчина</option>
<option value="1">Женщина</option>
</select>

<div class="help-block"></div>
</div>    <span class="m3 btn_start middle"><span class="btn_end"><button type="submit" class="btn">Сохранить</button></span></span>
</form>
 </div>
</div>

<?
include './system/f.php';

?>