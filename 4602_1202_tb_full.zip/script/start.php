<?
    
    include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';
    
if($user) {

  header('location: /');
    
exit;

}


include './system/h.php';

 $capt = 7777;


?>
<div class="content"><div class="block center color3 s125"><a href="/">Тюремный Беспредел</a>/ Начать игру</div>
            <div class="line"></div><div class="block">

3.7.5 регистрации одним Пользователем более одной Учетной записи, т.н. «мультоводство»; БЛОК НАВСЕГДА

<form action="?start" method="post">
    <div class="form-group field-saveavatar-name required">
<label class="control-label" for="saveavatar-name">Введите код:
<?=$capt?>

</label>
<input type="number" class="form-control" name="kod">
<div class="help-block"></div>
</div>    <div class="form-group field-saveavatar-sex required">

<div class="help-block"></div>
</div>    <span class="m3 btn_start middle"><span class="btn_end"><button type="submit" class="btn">Продолжить</button></span></span>
</form>
 </div>
</div>
<?



$kode = _string($_POST['kod']);

if($capt == $kode){
 if(isset($_GET['start'])) {
$ref = _string(_num($_GET['ref']));
$password = rand(11111,99999);


  if(mysql_query('INSERT INTO `users` (`login`,
                                    `password`) VALUEs ("Незнакомец",
                                               "'.md5($password).'")')) {
    
    $id = mysql_insert_id();

if($ref) {

  $ref_user = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$ref.'"');
  $ref_user = mysql_fetch_array($ref_user);
   if($ref_user) {

mysql_query('INSERT INTO `ref` (`user`,
`ho`) VALUEs ("'.$ref_user['id'].'",
"'.$id.'")');
mysql_query("UPDATE `users` SET `g`  = `g`+ '25' WHERE `id` = '$ref_user[id]'");

$terxt='Я зарегистрировался по вашей Реф-ссылке вы получили <img src=/images/icons/gold.png> 100';
$tim=time();
$read=1;
mysql_query("INSERT INTO `mail` SET `from`='$id',`to`='$ref_user[id]',`text`='$terxt',`time`='$tim',`read`='$read'");
mysql_query("INSERT INTO `contacts` SET `ho`='$ref_user[id]',`user`='$id',`time`='$tim'");
}
}
  
  $user = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$id.'"');
  $user = mysql_fetch_array($user);
  
    $_g = 8000;
    $_s = 36000;



     mysql_query('UPDATE `users` SET `hp` = "'.($user['vit']).'",`mp` = "'.$user['mana'].'", `gold_clan_time` = "'.(time()+(3600*48)).'",`gold_clan`="100"WHERE `id` = "'.$id.'"');
mysql_query('UPDATE `users` SET `arena_xod` = `arena_xod` + 500, `color` =  "F5D76E" WHERE `id` = "'.$id.'"');

     mysql_query('UPDATE `users` SET `g`  ="'.$_g.'",
                                     `s`  ="'.$_s.'" WHERE `id` = "'.$id.'"');
mysql_query('INSERT INTO `amylet` (`user`) VALUES ("'.$id.'")');
mysql_query('INSERT INTO `farm_logs` (`user`) VALUES ("'.$id.'")');
mysql_query('INSERT INTO `farm` (`user`) VALUES ("'.$id.'")');


            setCookie('id', $user['id'], time() + 86400, '/');
setCookie('password', md5($password), time() + 86400, '/');
    
    
      header('location: /');

  }

}
}

?>