var ie=document.all?1:0;
var ns=document.getElementById&&!document.all?1:0;
function InsertSmile(SmileId)
{
    if(ie) {
        document.all.text.focus();
        document.all.text.value+=" "+SmileId+" ";
    }
    else if(ns) {
        document.forms['comment'].elements['text'].focus();
        document.forms['comment'].elements['text'].value+=""+SmileId+" ";
    }
    else alert("!");
}