<?

        /*
		*
		Create file chest_user.php
		Date 16.06.2017 10:14
		Author XxxDIABLOxxX
		*
		*/
		
		$_chest_setting = array(

            'name' => array(1 => 'Обычный', 2 => 'Редкий', 3 => 'Легендарный', 4 => 'Божественный'),
			'color' => array (1 => '#F6FF73', 2 => '#FF9F20', 3 => '#6CABFF', 4 => '#FF2222'),			
		

		 );
	
 $w_chanse = rand(1,50);
    $chanse = rand(1,10) * rand(1,50);

  if($chanse < $w_chanse) {

	$chestRand = rand(1,100);
		
	if(rand(1,100) <= 25) {

		
		if($chestRand > 0 && $chestRand <= 15) {
			$chestNumber = 4;
		}elseif($chestRand > 15 && $chestRand <= 25) {
			$chestNumber = 3;
		}elseif($chestRand > 25 && $chestRand <= 50) {
			$chestNumber = 2;
		}elseif($chestRand > 50 && $chestRand <= 100) {
			$chestNumber = 1;
		}

	$_SESSION['err'] = '	<div class="alert"><div><center>
		Вы получили <font color="'.$_chest_setting['color'][$chestNumber].'">'.$_chest_setting['name'][$chestNumber].'</font> сундук!</center>
		<div class="separator"></div>
		<center><img src="/images/chet.jpg" alt="*" width="50" height="50"> </center></div></div>';
	
		mysql_query("UPDATE `chest_user` SET `$chestNumber` = `$chestNumber` + 1 WHERE `user` = '".$user['id']."'");
	}
}
				
?>