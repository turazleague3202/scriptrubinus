<?
    
    include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';
    
if(!$user) {

  header('location: /');
    
exit;

}

switch($_GET['action']) {
  default:

  case 'item':
    $title = 'Мастерская';    

include './system/h.php';  

?>
  <div class="content"><div class="block center color3 s125"><a href="/equip">Снаряжение</a>/ Мастерская</div>
            <div class="line"></div><div class="block center blue">
    Улучшение позволяет сделать вещь еще мощнее!
</div>
<div class="dotted"></div>
<?
$id = _string(_num($_GET['id']));

if($id && $inv['quality'] == $i) {

  $inv = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$user['id'].'" AND `id` = "'.$id.'" AND `equip` = "1" AND `rune` = "0"');
  $inv = mysql_fetch_array($inv);
 
  if(!$inv) {

    header('location: /equip/');
    
  exit;

  }
 
  $item = mysql_query('SELECT * FROM `items` WHERE `id` = "'.$inv['item'].'"');    
  $item = mysql_fetch_array($item);

    switch($item['w']) {
    
      case 1:
      $rune_stat = 'str';
      $stat = 'силе';
       break;
      case 2:
      $rune_stat = 'vit'; 
      $stat = 'жизни';
       break;
      case 3:
      $rune_stat = 'def'; 
      $stat = 'броне';
       break;
      case 4:
      $rune_stat = 'str'; 
      $stat = 'удаче';
       break;
      case 5:
      $rune_stat = 'vit'; 
      $stat = 'силе';
       break;
      case 6:
      $rune_stat = 'def'; 
      $stat = 'силе';
       break;
      case 7:
      $rune_stat = 'str'; 
      $stat = 'броне';
       break;
      case 8:
      $rune_stat = 'vit'; 
      $stat = 'жизни';
       break;
      case 9:
      $rune_stat = 'vit'; 
      $stat = 'жизни';
       break;

    }

$rune = _string(_num($_GET['rune']));
  if($rune && $rune > 0 && $rune < 11) {
  
    switch($rune) {
        case 1:
           $cost = 10;
   $cost2 = 4100;
     $rune_stats = 400;
       break;
      case 2:
           $cost = 20;
   $cost2 = 8100;
     $rune_stats = 1650;
       break;
      case 3:
           $cost = 40;
   $cost2 = 16200;
     $rune_stats = 5400;
       break;
      case 4:
           $cost = 150;
   $cost2 = 32400;
     $rune_stats = 11500;
       break;
      case 5:
           $cost = 400;
   $cost2 = 64800;
     $rune_stats = 14800;
       break;
      case 6:
           $cost = 870;
   $cost2 = 82800;
     $rune_stats = 18700;
       break;
      case 7:
           $cost = 2280;
   $cost2 = 94800;
     $rune_stats = 22800;
       break;
      case 8:
           $cost = 3100;
   $cost2 = 162000;
     $rune_stats = 31000;
       break;
      case 9:
           $cost = 4100;
   $cost2 = 182000;
     $rune_stats = 62000;
       break;
    }
  
  if($cost && $user['g'] >= $cost && $cost2 && $user['s'] >= $cost2) {
 
    mysql_query('UPDATE `users` SET `g` = "'.($user['g'] - $cost).'", `s` = "'.($user['s'] - $cost2).'" WHERE `id` = "'.$user['id'].'"');
    
$texy="Улучшил (мастер) шмотку $item[name] <img src=/images/icons/silver.png width=16 height=16 alt=> $cost2 <img src=/images/icons/gold.png width=16 height=16 alt=> $cost ";
mysql_query('INSERT INTO `golds` SET `user` = "'.$user['id'].'",`time` = "'.time().'",`text` = "'.$texy.'",`loc`="2"');

    mysql_query('UPDATE `inv`   SET `_str` = `_str` + "'.$rune_stats.'",
`_vit`=  `_vit` + "'.$rune_stats.'",
`_def` =  `_def` + "'.$rune_stats.'",
                                               `rune` = "'.$rune.'" , `run` = "1" WHERE `id` = "'.$inv['id'].'"');


    mysql_query('UPDATE `users`   SET `str` = `str` + "'.$rune_stats.'",
`vit`=  `vit` + "'.$rune_stats.'",
`def` =  `def` + "'.$rune_stats.'" WHERE `id` = "'.$user['id'].'"');

  header('location: /smith/item/'.$inv['id'].'/');
  
  }
  else
  {
  
  
  }
  
  }

?>

  

<div class="block">
            <a href="#"><img class="left mr8" src="/images/items/<?=$item['id']?>.jpg" alt=""></a>

            <img src="/images/icons/equip.png" width="16" height="16" alt=""> <a href="#"><span class="color-quality<?=$inv['quality']?>"><?=$item['name']?></span></a>
        <span class="white">
    
    <img src="/images/icons/level.png" width="16" height="16" alt=""> <?=$item['lvl']?> ур.    </span>



<div>




<?


  for($i = 1; $i < 11; $i++) {

  switch($i) {
    case 1:
      $quality = 'Обычное качество'; 
$quality_color = "#6c3";
         $cost = 10;
   $cost2 = 4100;
   $rune_stats = 400;
     break;
    case 2:
      $quality = 'Редкое качество'; 
$quality_color = "#69c";
         $cost = 20;
   $cost2 = 8100;
   $rune_stats = 1650;
     break;
    case 3:
      $quality = 'Эпическое качество'; 
$quality_color = "#c6f";
         $cost = 40;
   $cost2 = 16200;
   $rune_stats = 5400;
     break;
    case 4:
      $quality = 'Легендарное качество'; 
$quality_color = "#f60";
         $cost = 150;
   $cost2 = 32400;
   $rune_stats = 11500;
     break;
    case 5:
      $quality = 'Божественное качество'; 
$quality_color = "#999";
         $cost = 400;
   $cost2 = 64800;
   $rune_stats = 14800;
     break;
   case 6:
      $quality = 'Божественное качество'; 
$quality_color = "#999";
         $cost = 870;
   $cost2 = 82800;
   $rune_stats = 18700;
 
     break;
   case 7:
      $quality = 'Божественное качество'; 
$quality_color = "#999";
         $cost = 2280;
   $cost2 = 94800;
   $rune_stats = 22800;
     break;
   case 8:
      $quality = 'Божественное качество'; 
$quality_color = "#999";
         $cost = 3100;
   $cost2 = 162000;
   $rune_stats = 31000;
     break;
case 9:
      $quality = 'Божественное качество'; 
$quality_color = "#999";
         $cost = 4100;
   $cost2 = 182000;
   $rune_stats = 62000;
     break;
  }

if($inv['quality'] == $i) {
?>

    <span class="color2">
    <img src="/images/icons/health.png" width="16" height="16" alt=""> <?=$inv['vit_']?></span>
                    <sup class="blue">+<?=$rune_stats?></sup>
            <span class="color2">
    <img src="/images/icons/damage.png" width="16" height="16" alt=""> <?=$inv['str_']?></span>
                    <sup class="blue">+<?=$rune_stats?></sup>
            <span class="color2">
    <img src="/images/icons/armor.png" width="16" height="16" alt=""> <?=$inv['def_']?></span>
                    <sup class="blue">+<?=$rune_stats?></sup>
        <div class="clear"></div>
</div></div>


<div class="dotted"></div>
<div class="block center s125">
    <img src="/images/icons/plus.png" width="16" height="16" alt="">    Усиление:
            
    <img src="/images/icons/health.png" width="16" height="16" alt=""> <?=$rune_stats?>            
    <img src="/images/icons/damage.png" width="16" height="16" alt=""> <?=$rune_stats?>            
    <img src="/images/icons/armor.png" width="16" height="16" alt=""> <?=$rune_stats?>    </div>
<div class="dotted"></div>

<div class="block center">
    <span class="btn_start"><span class="btn_end"><a class="btn" href="/smith/item/<?=$inv['id']?>/<?=$i?>/">Усилить за     <img src="/images/icons/silver.png" width="16" height="16" alt=""> <?=$cost2?>    <img src="/images/icons/gold.png" width="16" height="16" alt=""> <?=$cost?></a></span> </span></div>

<?

  }
  
}
}
?>

<div class="line"></div>
<div class="menu"><li><a href="/equip/"><img src="/images/icons/equip.png" width="16" height="16" alt=""> Перейти в снаряжение</a></li><li><a href="/inv/bag/"><img src="/images/icons/bag.png" width="16" height="16" alt=""> Открыть тумбочку</a></li></div></div>

<?
include './system/f.php';

  break;

  case 'po':

    $title = 'установка прошивки';    

include './system/h.php';  

?>

    <div class="content"><div class="block center color3 s125"><a href="/equip/">Снаряжение</a>/ Установка нашивки</div>
            <div class="line"></div><div class="block center blue">Нашивка позволит тебе сделать шмотку мощнее</div>
<div class="dotted"></div>


<?

$id = _string(_num($_GET['id']));

if($id && $inv['quality'] <= $inv['smith']) {

  $inv = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$user['id'].'" AND `id` = "'.$id.'" AND `equip` = "1" AND `smith` <8');
  $inv = mysql_fetch_array($inv);
 
  if(!$inv &&  $inv['quality'] <= $inv['smith']) {
header('location: /equip/');exit;}
if($inv['quality'] == 1 && $inv['smith'] == 1 OR $inv['quality'] == 2 && $inv['smith'] == 1 OR $inv['quality'] == 3 && $inv['smith'] == 2 OR $inv['quality'] == 4 && $inv['smith'] == 3 OR $inv['quality'] == 5 && $inv['smith'] == 4 OR $inv['quality'] == 6 && $inv['smith'] == 5 OR $inv['quality'] == 7 && $inv['smith'] == 6 OR $inv['quality'] == 8 && $inv['smith']  == 7 OR $inv['quality'] == 9 && $inv['smith']  == 8) {

header('location: /equip/');exit;}
  $item = mysql_query('SELECT * FROM `items` WHERE `id` = "'.$inv['item'].'"');    
  $item = mysql_fetch_array($item);

  switch($item['quality']) {
    case 0:
  $bonus = 0;
      $quality = 'Простой';
$quality_color = "#986";
     break;
    case 1:
  $bonus = 5;
      $quality = 'Обычный';
$quality_color = "#6c3";
     break;

    case 2:
 $bonus = 10;
      $quality = 'Редкий';
$quality_color = "#69c";
     break;

    case 3:
 $bonus = 15;
 
      $quality = 'Эпический';
$quality_color = "#c6f";
     break;

    case 4:
 $bonus = 20;
 
      $quality = 'Легенарный';
$quality_color = "#f60";
     break;


    case 5:
 $bonus = 50;
      $quality = 'Божественный';
$quality_color = "#999";
     break;


    case 6:
 $bonus = 65; 
      $quality = 'Сверх Божественный';
$quality_color = "#999";
     break;

  }





  switch($inv['smith']) {

    
case 1:
    $costy = 3300;
     $smith = 5500;
     break;
    case 2:
    $costy = 10800;
     $smith = 7500;
     break;
    case 3:
    $costy = 23000;
     $smith = 12200;
     break;
    case 4:
    $costy = 29600;
     $smith = 6300;
     break;
    case 5:
    $costy = 37400;
     $smith = 7800;
     break;
    case 6:
    $costy = 45600;
     $smith = 8200;
     break;
    case 7:
    $costy = 62000;
     $smith = 16400;
     break;
    case 8:
    $costy = 82000;
     $smith = 24400;
     break;
  }



    $g = 350 + ($inv['smith'] * 7);
      
    $s = 14000 + ($inv['smith'] * 13000);

  if(isset($_GET['start'])) {
  
    if($user['g'] < $g OR $user['s'] < $s) {
    
      header('location: /smith/po/'.$inv['id'].'/');
    
    exit;
    
    }

if($inv['smith'] == 1 && $inv['quality'] < 1 OR $inv['smith'] == 2 && $inv['quality'] < 2 OR $inv['smith'] == 3 && $inv['quality'] < 3 OR $inv['smith'] == 4 && $inv['quality'] < 4 OR $inv['smith'] == 5 && $inv['quality'] < 5 OR $inv['smith'] == 6 && $inv['quality']  < 6 OR $inv['smith'] == 7 && $inv['quality']  < 7 OR $inv['smith'] == 8 && $inv['quality']  < 8 OR $inv['smith'] == 9 && $inv['quality']  < 9 ) {

header('location: /equip/');exit;}

    mysql_query('UPDATE `users` SET `s` = `s` - '.$s.', `g` = `g` - '.$g.' WHERE `id` = "'.$user['id'].'"');
    
$texy="Улучшил (нашивка) шмотку $item[name] <img src=/images/icons/silver.png width=16 height=16 alt=> $s <img src=/images/icons/gold.png width=16 height=16 alt=> $g ";
mysql_query('INSERT INTO `golds` SET `user` = "'.$user['id'].'",`time` = "'.time().'",`text` = "'.$texy.'",`loc`="2"');

mysql_query('UPDATE `inv` SET `smith` = `smith` + 1,
`_str` = `_str` + '.$smith.', `_vit` = `_vit` + '.$smith.', `_def` = `_def` + '.$smith.' WHERE `id` = "'.$inv['id'].'"');
mysql_query('UPDATE `users` SET `str` = `str` + '.$smith.', `vit` = `vit` + '.$smith.', `def` = `def` + '.$smith.' WHERE `id` = "'.$user['id'].'"');

header('location: /smith/po/'.$inv['id'].'/?');
  
  }

?>

<div class="block">
            <a href="#"><img class="left mr8" src="/images/items/<?=$item['id']?>.jpg" alt=""></a>

            <img src="/images/icons/equip.png" width="16" height="16" alt=""> <a href="#"><span class="color-quality<?=$inv['quality']?>"><?=$item['name']?></span></a>
        <span class="white">
    
    <img src="/images/icons/level.png" width="16" height="16" alt=""> <?=$item['lvl']?> ур.    </span>



<div>





    <span class="color2">
    <img src="/images/icons/health.png" width="16" height="16" alt=""> <?=$inv['vit_']?></span>
                
            <span class="color2">
    <img src="/images/icons/damage.png" width="16" height="16" alt=""> <?=$inv['str_']?></span>
                
            <span class="color2">
    <img src="/images/icons/armor.png" width="16" height="16" alt=""> <?=$inv['def_']?></span>
                    
        <div class="clear"></div>
</div></div>

<?

  $quality_col = array('#F6FF73', '#FF9F20', '#FF7032', '#7BFF6C', '#6CABFF', '#FF2222', '#FF1B6E','#D822FF');

$itemqualit = array('Обычное качество', 'Редкое качество', 'Очень редкое качество', 'Великолепное качество', 'Легендарное качество', 'Божественное качество', 'Сверх-Божественное качество','Эксклюзивное качество');

?>

<div class="dotted"></div>
    <div class="block center s125">
        <img src="/images/icons/equip.png" width="16" height="16" alt="">    <font color="<?=$quality_col[$inv['smith']]?>"><?=$itemqualit[$inv['smith']]?></font> <br/>
        Параметры:
                    
    <img src="/images/icons/health.png" width="16" height="16" alt=""> <?=$costy?>                    
    <img src="/images/icons/damage.png" width="16" height="16" alt=""> <?=$costy?>                    
    <img src="/images/icons/armor.png" width="16" height="16" alt=""> <?=$costy?>            </div>
    <div class="dotted"></div>


    <div class="dotted"></div>

    <div class="block center">
                <span class="btn_start"><span class="btn_end"><a class="btn" href="/smith/po/<?=$inv['id']?>/?start">Установить за     <img src="/images/icons/silver.png" width="16" height="16" alt=""> <?=$s?>    <img src="/images/icons/gold.png" width="16" height="16" alt=""> <?=$g?></a></span> </span>            </div>
<div class="dotted"></div>


<?

}

?>

<ul class="block small">
    <li class="color2">Внимание! Нашивки не суммируются. Это значит что при переходе от одного качества к другому,
        параметрыстарого качества заменяются параметрами нового</li>
</ul></div>
 
<?
  
include './system/f.php';

  break;

}

?>