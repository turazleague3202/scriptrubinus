﻿<?
include './system/common.php';  
include './system/functions.php';     
include './system/user.php';
   
if(!$user) {
header('location: /');  
exit;
}

$title = 'Редактирование';
include './system/h.php';
{
$id = _string(_num($_GET['id']));
$result = mysql_query("SELECT `name`,`text` FROM `forum_topic` WHERE `id` = '".$id."'");
$row = mysql_fetch_assoc($result);
if(isset($_POST['save'])){
$name = _string($_POST['name']);
$text = _string($_POST['text']); 
mysql_query("UPDATE `forum_topic` SET `name` = '".$name."',`text` = '".$text."' WHERE `id` = '".$id."'");
header('location: /forum/topic/'.$id.'/');
mysql_close();
}
}
?>

<div class="content">
<form method="post" action="/forum/topic/red/<?=$id?>">
<div>Название обсуждения:<br>
<input class="control-label" name="name" maxlength="40" value="<?=$row['name']?>" type="text">
<br>
<div class="form-group field-text required">
<label class="control-label" for="text">Тема обсуждения</label>
<textarea class="form-control" name="text" rows="10"><?=$row['text']?></textarea>

<div class="help-block"></div>
</div>        <div class="form-group field-topicmessageform-topic_id">
<div class="help-block"></div>
</div>        <span class="m3 btn_start middle"><span class="btn_end"><button type="submit" name="save" class="btn">Сохранить</button></span></span>
        </form> 
<div class="dotted"></div>
<div class="block">
    Для форматирования обсуждений, вы можете использовать специальные BB коды:<br/>
    [b]жирный[/b] - <b>жирный</b> <br/>
    [i]наклонный[/i] - <i>наклонный</i> <br/>
    [u]подчёркнутый[/u] - <span style="text-decoration: underline">подчёркнутый</span><br/>
    [color=red]цвет[/color] - <span style="color: red">цвет</span><br/>
</div>
<div class="dotted"></div>
<div class="block">
    Ключевые значения цветов для тэга [color] <br/>
    Gray - <span style="color: gray">серый</span><br/>
    Silver - <span style="color: silver">серебрянный</span><br/>
    White - <span style="color: white">белый</span><br/>
    Fuchsia - <span style="color: fuchsia">розовый</span><br/>
    Purple - <span style="color: purple">пурпурный</span><br/>
    Red - <span style="color: red">красный</span><br/>
    Maroon - <span style="color: maroon">бордовый</span><br/>
    Yellow - <span style="color: yellow">жёлтый</span><br/>
    Olive - <span style="color: olive">оливковый</span><br/>
    Lime - <span style="color: olive">лаймовый</span><br/>
    Green - <span style="color: green">зелёный</span><br/>
    Aqua - <span style="color: aqua">голубой</span><br/>
    Blue - <span style="color: blue">синий</span><br/>
    Teal - <span style="color: teal">травянной</span><br/>
</div>
<div class="dotted"></div>
<div class="block">
    Заголовки:<br/>
    <h1>[h1]Заголовок 1[/h]</h1>
    <h2>[h2]Заголовок 2[/h]</h2>
    <h3>[h3]Заголовок 3[/h]</h3>
    <h4>[h4]Заголовок 4[/h]</h4>
    <h5>[h5]Заголовок 5[/h]</h5>
    <h6>[h6]Заголовок 6[/h]</h6>
</div>
<div class="dotted"></div>
<div class="block">
    <div style="text-align: center">[center]текст по-центру[/center]</div>
    <div style="text-align: left">[left]текст по-левому краю[/left]</div>
    <div style="text-align: right">[right]текст по-правому краю[/right]</div>
</div>
<div class="dotted"></div>
<div class="block">
    [hr]линия
 
</div> <div class="dotted"></div>
<div class="menu">            <li><a href="/forum/topic/<?=$id?>/?<?=$udet?>"><img src="/images/icons/right_blue.jpg" width="16" height="16" alt=""> Вернуться к обсуждению </a></li></div><div class="dotted"></div> </div>
<?
include './system/f.php';

?>