<?
    
    include './system/common.php';
    
 include './system/functions.php';
         
      include './system/user.php';
    
if(!$user) {

  header('location: /');
    
exit;

}

$action = _string($_GET['action']);

switch($action) {
  default:
    
    $title = 'Онлайн';


include './system/h.php';  

$onclan = mysql_num_rows(mysql_query("SELECT `id` FROM `users` WHERE (SELECT COUNT(`user`) FROM `clan_memb` WHERE `user` = `users`.`id`)  = 0  and `users`.`online` > '".(time() -  (3400))."'"));

$onus = mysql_result(mysql_query('SELECT COUNT(*) FROM `users` WHERE `online` > "'.(time() - 3400).'"'),0);
?>

    <div class="content"><div class="block center color3 s125">Все игроки</div>
            <div class="line"></div><div class="h-navig"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tbody><tr><td class="h-navig-item"><a href="/online">Все игроки <span class="white bold">( <?=$onus?>)</span></a></td><td class="h-navig-item"><a href="/online/clan">Без банды <span class="white bold">(<?=$onclan?>)</span></a></td><td class="h-navig-item"><a href="/online/mod">Администрация </a></td></tr></tbody></table></div><div class="line"></div>

<?

    $max = 10;
  $count = mysql_result(mysql_query('SELECT COUNT(*) FROM `users` WHERE `online` > "'.(time() - 3400).'"'),0);
  $pages = ceil($count/$max);
   $page = _string(_num($_GET['page']));

    if($page > $pages) {
    
   $page = $pages;
    
    }
  
    if($page < 1) {
    
   $page = 1;
    
    }
    
  $start = $page * $max - $max;

$q = mysql_query('SELECT * FROM `users` WHERE `online` > "'.(time() - 3400).'" AND `access` = "0" ORDER BY `level` DESC, `level` DESC LIMIT '.$start.', '.$max.'');

  while($row = mysql_fetch_array($q)) {
  
$color=$row['color'];
?>

<div class="block">
            <div>
<?
if($row['vip'] == 0 && $row['access'] == 0){
?>
<img src="/images/icons/<?=$row['r']?>.png" width="16" height="16" alt="">
<?
}

if($row['access'] == 1) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt="">
<?}
if($row['access'] == 2) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt="">
<?}
if($row['access'] == 3) {
?>
<img src="/images/icons/adminy.png" width="16" height="16" alt="">
<?
}
if($row['vip'] == 1 && $row['access'] == 0){
?>
<img src="/images/icons/vip_<?=($row['r'] == man ? 'woman':'man')?>_<?=$row['r']?>.png" width="16" height="16" alt="">
<?
}
?>

 <a class="color3" href="/user/<?=$row['id']?>/"><font style="text-shadow: 0px 5px 6px;" color=#<?=$color?>><?=$row['login']?></font></a>,
            
    <img src="/images/icons/level.png" width="16" height="16" alt=""> <?=$row['level']?> ур.                
<h6>
<?
if($user['access'] >= 1){
echo ' '.$row['ip'].' ';}
if($user['access'] >= 2){
echo'['._times(time() - $row['online']).']';}
?>
</div>
</h6>
       </div>



<?
}
?>

  <div class="dotted"></div>
<ul class="pagination"><li class="next"><?=pages('?');?></li></ul>

<div class="dotted"></div>
<?
$id = _string($_POST['id']);
  if($id) {
    $users = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$id.'"');
    $users = mysql_fetch_array($users);
  
  if($users) {

    header('location: /user/'.$users['id'].'/');

  }
  else
  {
  
  }

  }


?>

  <form class="block" action="/online" method="post">

<label class="control-label" for="searchavatarform-ui">Номер дела</label>
<input type="text" class="form-control" name="id">

<div class="help-block"></div>
  <span class="m3 btn_start middle"><span class="btn_end"><button type="submit" class="btn">Найти игрока</button></span></span>
    </form><div class="dotted"></div>
<ul class="block small">
    <li>Онлайн обновляется каждые 10 минут</li>
</ul></div>

<?

include './system/f.php';

        break;

case 'search':
    
    $title = 'Поиск игрока';


include './system/h.php';  


$login = _string($_POST['login']);
  if($login) {
    $users = mysql_query('SELECT * FROM `users` WHERE `login` = "'.$login.'"');
    $users = mysql_fetch_array($users);
  
  if($users) {

    header('location: /user/'.$users['id'].'/');

  }
  else
  {
  
  }

  }

?>

  <form class="block" action="/online" method="post">

<label class="control-label" for="searchavatarform-ui">Номер дела или погоняло</label>
<input type="text" class="form-control" name="login">

<div class="help-block"></div>
</div>    <span class="m3 btn_start middle"><span class="btn_end"><button type="submit" class="btn">Найти игрока</button></span></span>
    </form><div class="dotted"></div>
<ul class="block small">
    <li><span class="small green"> * </span> - игрок проявлял активность в течении последних 7 минут</li>
    <li>Онлайн обновляется каждые 10 минут</li>
</ul></div>
            <div class="line2"></div>

<?

include './system/f.php';

  break;

case 'clan':
$title = 'Без банды';
include './system/h.php';
$onclan = mysql_num_rows(mysql_query("SELECT `id` FROM `users` WHERE (SELECT COUNT(`user`) FROM `clan_memb` WHERE `user` = `users`.`id`)  = 0  and `users`.`online` > '".(time() -  (3400))."'"));

$onus = mysql_result(mysql_query('SELECT COUNT(*) FROM `users` WHERE `online` > "'.(time() - 3400).'"'),0);
?>


    <div class="content"><div class="block center color3 s125">Все игроки</div>
            <div class="line"></div><div class="h-navig"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tbody><tr><td class="h-navig-item"><a href="/online">Все игроки <span class="white bold">( <?=$onus?>)</span></a></td><td class="h-navig-item"><a href="/online/clan">Без банды <span class="white bold">(<?=$onclan?>)</span></a></td><td class="h-navig-item"><a href="/online/mod">Администрация</a></td></tr></tbody></table></div><div class="line"></div>


<?	
$max = 10;
$count = mysql_num_rows(mysql_query("SELECT `id` FROM `users` WHERE (SELECT COUNT(`user`) FROM `clan_memb` WHERE `user` = `users`.`id`)  = 0  and `users`.`online` > '".(time() -  (3400))."'"));
$pages = ceil($count/$max);
$page = _string(_num($_GET['page']));
if($page > $pages) {
$page = $pages;
}
if($page < 1) {
$page = 1;
}
$start = $page * $max - $max;
$q = "SELECT * FROM `users` WHERE (SELECT COUNT(`user`) FROM `clan_memb` WHERE `user` = `users`.`id`)  = 0  and `users`.`online` > '".(time() - (3400))."' ORDER BY  `level` DESC, `level` DESC LIMIT ".$start.", ".$max."";
$q = mysql_query($q);
while($row = mysql_fetch_assoc($q)) {
	
$a=mysql_fetch_array(mysql_query('SELECT * FROM `users` WHERE `id` = "'.$row['user'].'"'));
?>



    <div class="block">
            <div>
<?
if($row['vip'] == 0 && $row['access'] == 0){
?>
<img src="/images/icons/<?=$row['r']?>.png" width="16" height="16" alt="">
<?
}

if($row['access'] == 1) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt="">
<?}
if($row['access'] == 2) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt="">
<?}
if($row['access'] == 3) {
?>
<img src="/images/icons/adminy.png" width="16" height="16" alt="">
<?
}
if($row['vip'] == 1 && $row['access'] == 0){
?>
<img src="/images/icons/vip_<?=($row['r'] == man ? 'woman':'man')?>_<?=$row['r']?>.png" width="16" height="16" alt="">
<?
}
?>
 <a class="color3" href="/user/<?=$row['id']?>/">  <?=$row['login']?></a>,
            
    <img src="/images/icons/level.png" width="16" height="16" alt=""> <?=$row['level']?> ур.                </div>
       </div>



<?
}
?>

<?

?>
  <div class="dotted"></div>
<ul class="pagination"><li class="next"><?=pages('/online/clan/?');?></li></ul>

<?

?>
<div class="dotted"></div>
<ul class="block small">
    <li>Онлайн обновляется каждые 30 минут</li>
</ul></div>


<?
include './system/f.php';
break;

case 'mod':
$title = 'Администрация';
include './system/h.php';
$onclan = mysql_num_rows(mysql_query("SELECT `id` FROM `users` WHERE (SELECT COUNT(`user`) FROM `clan_memb` WHERE `user` = `users`.`id`)  = 0  and `users`.`online` > '".(time() -  (3400))."'"));
$onus = mysql_result(mysql_query('SELECT COUNT(*) FROM `users` WHERE `online` > "'.(time() - 3400).'"'),0);
?>

   <div class="content"><div class="block center color3 s125">Все игроки</div>
            <div class="line"></div><div class="h-navig"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tbody><tr><td class="h-navig-item"><a href="/online">Все игроки <span class="white bold">( <?=$onus?>)</span></a></td><td class="h-navig-item"><a href="/online/clan">Без банды <span class="white bold">(<?=$onclan?>)</span></a></td><td class="h-navig-item"><a href="/online/mod">Администрация</a></td></tr></tbody></table></div><div class="line"></div>


<?	
$max = 15;
 $count = mysql_result(mysql_query('SELECT COUNT(*) FROM `users` WHERE `online` > "'.(time() - 3400).'"'),0);
$pages = ceil($count/$max);
$page = _string(_num($_GET['page']));
if($page > $pages) {
$page = $pages;
}
if($page < 1) {
$page = 1;
}
$start = $page * $max - $max;

$q = mysql_query('SELECT * FROM `users` WHERE `online` > "'.(time() - 3400).'" AND `access` > "0" ORDER BY  `level` DESC, `online` DESC LIMIT '.$start.', '.$max.'');

  while($row = mysql_fetch_array($q)) {
  

$color=$row['color'];
?>


    <div class="block">
            <div>
<?
if($row['vip'] == 0 && $row['access'] == 0){
?>
<img src="/images/icons/<?=$row['r']?>.png" width="16" height="16" alt="">
<?
}

if($row['access'] == 1) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt="">
<?}
if($row['access'] == 2) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt="">
<?}
if($row['access'] == 3) {
?>
<img src="/images/icons/adminy.png" width="16" height="16" alt="">
<?
}
if($row['vip'] == 1 && $row['access'] == 0){
?>
<img src="/images/icons/vip_<?=($row['r'] == man ? 'woman':'man')?>_<?=$row['r']?>.png" width="16" height="16" alt="">
<?
}
?>
 <a class="color3" href="/user/<?=$row['id']?>/"> <font style="text-shadow: 0px 5px 6px;" color=#<?=$color?>> <?=$row['login']?> </font></a><span class="small green"> * </span>,
            
    <img src="/images/icons/level.png" width="16" height="16" alt=""> <?=$row['level']?> ур.             
<?
if($row['access'] == 1) {
?>
<img src="/images/icons/privilege.png" width="16" height="16" alt="">
Модератор
<?}
if($row['access'] == 2) {
?>
<img src="/images/icons/privilege.png" width="16" height="16" alt="">
Старший модератор

<?}
if($row['access'] == 3) {
?>
<img src="/images/icons/privilege.png" width="16" height="16" alt=""> Администратор<?}?>
  </div></div>
<?
}
?>

<?
if($page == 2) {
?>
  <div class="dotted"></div>
<ul class="pagination"><li class="next"><?=pages('/online/mod/?');?></li></ul>

<?
}
?>

<div class="dotted"></div>
<ul class="block small">
    <li>Онлайн обновляется каждые 30 минут</li>
</ul></div>




<?
include './system/f.php';
break;

}

?>

