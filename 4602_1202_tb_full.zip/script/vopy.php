<?
    
    include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';
    
if(!$user) {

  header('location: /');
    
exit;

}

$title =' название';
    include './system/h.php';
$my_atk += rand(round($user['str']/1), round($user['str']/1));
$bos_atk += rand(round(420000/4), round(420000/8));
$bos_atk -= rand(round($user['def']/17), round($user['def']/8));
$my_atk -= rand(round(300000/1), round(300000/5));

$msy_atk += rand(round($user['str']/1), round($user['str']/2));
$bosy_atk += rand(round(420000/1), round(420000/2));
$bosy_atk -= rand(round($user['def']/1), round($user['def']/2));
$msy_atk -= rand(round(300000/1), round(300000/5));


if($bosy_atk < 0)$bosy_atk = 0;
if($msy_atk < 0)$msy_atk = 0;
if($bos_atk < 0)$bos_atk = 0;
if($my_atk < 0)$my_atk = 0;
$bosy=$bosy_atk;
$bos=$my_atk;
?>
 <div class="content"><div class="block center color3 s125">user<?=$bos?> vs <?=$bosy?>vrag
</div>
            <div class="line"></div> 




<?
include './system/f.php';
?>