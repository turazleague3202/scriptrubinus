<?
include '../system/common.php';
include '../system/functions.php';
include '../system/user.php';
if(!$user){header('location: /');exit;}
$title = 'Покупка сахара';
include '../system/h.php';
include 'sett.php';
?>

<div class="content"><div class="block center color3 s125">Покупка</div>
            <div class="line"></div><div class="menu"><li><a href="/exchanger?<?=$udet?>"><img src="/images/icons/exchanger.png" width="16" height="16" alt=""> Обменник</a></li></div><div class="dotted"></div>
<div class="block center m3 blue">Номер Киви +79328442652 <br> Комментарии к платежу: Ваш ID:<?=$user['id']?> </div>
<div class="block center m3 red">Как купить сахар через <a href="https://qiwi.com/replenish/categories/qiwi-terminals/qiwi.action">Киви кошелёк </a> </div>
<div class="block center m3 red"><h3>Купить сахар можно только через киви </h3></div>


<div class="block center">

    <img src="/images/title/shop.png" width="150" height="75" alt="">    <div class="m3 blue">Для порядочных арестантов всегда хорошие цены</div>
</div>
<?
if(isset($_GET['gold']))
{
$gold = intval($_GET['gold']);
if (isset($wk_cena_gold[$gold]))
{?>
<form method="POST" action="https://wapkassa.ru/merchant/oplata.php">
<input type="hidden" name="WK_PAYMENT_SITE" value="<?=wk_id?>">
<input type="hidden" name="WK_PAYMENT_AMOUNT" value="<?=wk_summ($wk_cena_gold[$gold])?>">
<input type="hidden" name="WK_PAYMENT_COMM" value="Покупка золота ID <?=$user['id']?>">
<input type="hidden" name="WK_PAYMENT_HASH" value="<?=strtoupper(hash("sha256",wk_id.wk_summ($wk_cena_gold[$gold]).wk_code))?>">
<input type="hidden" name="WK_PAYMENT_USER" value="<?=$user['id']?>">
<input type="hidden" name="WK_PAYMENT_TOVAR" value="gold">
<input type="hidden" name="WK_PAYMENT_COUNT" value="<?=$gold?>">
<div class="dotted"></div>
<div class="block center">
        <span class="btn_start"><span class="btn_end"><input class="btn" type="submit" value="Перейти к оплате"></span></span></div>
</form>
<?
include '../system/f.php';
exit;
}
}

foreach($wk_cena_gold as $key => $value)
{ $i++; 
echo '<div class="dotted"></div>
            <div class="block">
            <img class="left mr8" src="/images/pay/'.$i.'.jpg" width="50" height="50" alt="">                                        <img src="/images/icons/donate.png" width="16" height="16" alt=""> Сгущёнка:+'.$key.'            <div class="blue">+    <img src="/images/icons/gold.png" width="16" height="16" alt=""> '.$wku[$i].' в подарок!</div>
            <div class="clear"></div>
        </div>
        <div class="dotted"></div>
        <div class="block center">
        <span class="btn_start"><span class="btn_end">
                                <a class="btn" href="/paywk/gold='.$key.'">Купить за '.$value.' </a>            </span>
        </span>
        </div>';

}
echo'</div>';

include '../system/f.php';
?>
