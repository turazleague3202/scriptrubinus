<?
define('wk_id', '483'); //id площадки
define('wk_code', 'fU1FdN9MDvbSMJQM'); //секретный код

//цена на золото количество=>цена
$wk_cena_gold=array('1000'=>'60.00', '2500'=>'90.00', '7500'=>'180.00', '17500'=>'240.00', '45000'=>'400.00');
$wku=array('','600','1500','4500','10500','27000');
function wk_summ($summ)
{
return number_format(floatval($summ), 2, '.', '');
}
?>