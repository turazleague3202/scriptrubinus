<?php
include '../system/common.php';
include '../system/functions.php';
include '../system/user.php';
$title = 'Покупка золота';
include '../system/h.php';
$_SESSION['not'] = '<div class="alert">Покупка прошла с ошибкой.</div><div class="alert_bottom"></div>';
header('location: /paywk');
exit;

include '../system/f.php';
?>