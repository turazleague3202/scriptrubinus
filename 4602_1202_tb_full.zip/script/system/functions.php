<?

    function _string($string) {
      
    $string = trim($string);
    
          $string = mysql_escape_string($string);
      
    $string = htmlspecialchars($string);

    return $string;
    
    }
    
    function _num($i) {
    
      $i = (int) abs($i);
    
    return $i;
    
    }
function text($m){
	$m = htmlspecialchars($m);
	$m = mysql_escape_string($m);
	$m = trim($m);
	return $m;
} 
    
    
    function n_f($i) {

    if($i >= 10000 && $i < 1000000) {
    
      $i = number_format($i, 0, '', '.');
    
      $i = round($i,3).'k';
    
    }
if($i >= 1000000) {

      $i = number_format($i, 0, '', '.');
    
      $i = round($i,3).'m';

    }
    else
    {
      
      $i = number_format($i, 0, '', '\'');
     
}
       
    return $i;
    
    }

    function pages($path) {
  
    global $page, $pages;
    
      if(($page - 1) > 0) {

        echo ' <li class="next"><a href="'.$path.'page=1">1</a></li> ';

      }
      else
      {

        echo ' <li class="next"></li>';

      }
        
      if($page - 1 > 0) {

        echo ' <li><a href="'.$path.'page='.($page - 1).'">«</a></li> ';
        
      }
      else
      {

        echo ' <li class="first disabled">«</li> ';

      }
        




      if($page == $pages && $page - 6 > 0) {

        echo ' <li class="next"><a href="'.$path.'page='.($page - 6).'">'.($page - 6).'</a> </li>';
        
      }
      if($page == $pages && $page - 5 > 0) {

        echo ' <li class="next"><a href="'.$path.'page='.($page - 5).'">'.($page - 5).'</a> </li>';
        
      }
      if($page == $pages && $page - 4 > 0) {

        echo ' <li class="next"><a href="'.$path.'page='.($page - 4).'">'.($page - 4).'</a> </li>';
        
      }

        
      if($page == $pages && $page - 3 > 0) {

        echo ' <li class="next"><a href="'.$path.'page='.($page - 3).'">'.($page - 3).'</a></li> ';
        
      }
        
      if($page - 2 > 0) {

        echo ' <li class="next"><a href="'.$path.'page='.($page - 2).'">'.($page - 2).'</a></li> ';
        
      }

        
      if($page - 1 > 0) {

        echo ' <li class="next"><a href="'.$path.'page='.($page - 1).'">'.($page - 1).'</a></li> ';
        
      }


      echo '<li class="first disabled">'.$page.'</li> ';
        
       
      if($page + 1 <= $pages) {

        echo '<li class="next"><a href="'.$path.'page='.($page + 1).'">'.($page + 1).'</a></li> ';
        
      }

        
      if($page + 2 <= $pages) {

        echo ' <li class="next"><a href="'.$path.'page='.($page + 2).'">'.($page + 2).'</a></li> ';
        
      }
        
      if($page == 1 && $page + 3 <= $pages) {

        echo ' <li class="next"><a href="'.$path.'page='.($page + 3).'">'.($page + 3).'</a></li> ';
        
      }
        
      if($page == 1 && $page + 4 <= $pages) {

        echo ' <li class="next"><a href="'.$path.'page='.($page + 4).'">'.($page + 4).'</a></li> ';
        
      }
      if($page == 1 && $page + 5 <= $pages) {

        echo ' <li class="next"><a href="'.$path.'page='.($page + 5).'">'.($page + 5).'</a></li> ';
        
      }
      if($page == 1 && $page + 6 <= $pages) {

        echo ' <li class="next"><a href="'.$path.'page='.($page + 6).'">'.($page + 6).'</a></li> ';
        
      }




        
      if($page + 1 <= $pages) {

        echo '  <li class="next"><a href="'.$path.'page='.($page + 1).'">»</a></li> ';

      }
      else
      {

        echo ' <li class="first disabled">»</li>';

      }
        
      if(($page + 2) <= $pages) {

        echo '  <li class="next"><a href="'.$path.'page='.$pages.'">'.$pages.'</a> </li>';
        
      }
      else
      {

        echo ' <li class="first disabled">'.$pages.'</li> ';

      }
      
    }
    
   function smiles($string) {
    
      $string = str_replace(array(':)'), '<img src="/images/icons/emoji/1.png" alt=""/>',      $string);
      $string = str_replace(array(':-D'), '<img src="/images/icons/emoji/2.png" alt="*"/>',      $string);
      $string = str_replace(array(';-)'), '<img src="/images/icons/emoji/3.png" alt=""/>',      $string);
      $string = str_replace(array('xD'), '<img src="/images/icons/emoji/4.png" alt=""/>',      $string);
      $string = str_replace(array(';-P'), '<img src="/images/icons/emoji/5.png" alt=""/>',      $string);
      $string = str_replace(array('8-)'), '<img src="/images/icons/emoji/6.png" alt=""/>',      $string);
      $string = str_replace(array(':]'), '<img src="/images/icons/emoji/7.png" alt=""/>',      $string);
      $string = str_replace(array('3('), '<img src="/images/icons/emoji/8.png" alt=""/>',      $string);
      $string = str_replace(array(':_-('), '<img src="/images/icons/emoji/9.png" alt=""/>',      $string);
      $string = str_replace(array(':_('), '<img src="/images/icons/emoji/10.png" alt=""/>',      $string);
      $string = str_replace(array(':|'), '<img src="/images/icons/emoji/11.png" alt=""/>',      $string);
      $string = str_replace(array('8|'), '<img src="/images/icons/emoji/12.png" alt=""/>',      $string);
      $string = str_replace(array('^3'), '<img src="/images/icons/emoji/13.png" alt=""/>',      $string);
      $string = str_replace(array('(XX)'), '<img src="/images/icons/emoji/14.png" alt=""/>',      $string);
      $string = str_replace(array('|O^'), '<img src="/images/icons/emoji/15.png" alt=""/>',      $string);
      $string = str_replace(array('^FU^'), '<img src="/images/icons/emoji/16.png" alt=""/>',      $string);
      $string = str_replace(array('^(('), '<img src="/images/icons/emoji/17.png" alt=""/>',      $string);
      $string = str_replace(array('^zz'), '<img src="/images/icons/emoji/18.png" alt=""/>',      $string);
      $string = str_replace(array(':*'), '<img src="/images/icons/emoji/19.png" alt=""/>',      $string);
      $string = str_replace(array(':^|'), '<img src="/images/icons/emoji/20.png" alt=""/>',      $string);
      $string = str_replace(array(':(x)'), '<img src="/images/icons/emoji/21.png" alt=""/>',      $string);
      $string = str_replace(array(':pf'), '<img src="/images/icons/emoji/22.png" alt=""/>',      $string);
      $string = str_replace(array('O^^O'), '<img src="/images/icons/emoji/23.png" alt=""/>',      $string);
      $string = str_replace(array('}:}'), '<img src="/images/icons/emoji/24.png" alt=""/>',      $string);
      $string = str_replace(array('}:{'), '<img src="/images/icons/emoji/25.png" alt=""/>',      $string);
      $string = str_replace(array(':like:'), '<img src="/images/icons/emoji/26.png" alt=""/>',      $string);
      $string = str_replace(array(':dislike:'), '<img src="/images/icons/emoji/27.png" alt=""/>',      $string);
      $string = str_replace(array(':up:'), '<img src="/images/icons/emoji/28.png" alt=""/>',      $string);
      $string = str_replace(array(':v:'), '<img src="/images/icons/emoji/29.png" alt=""/>',      $string);
      $string = str_replace(array(':ok:'), '<img src="/images/icons/emoji/30.png" alt=""/>',      $string);
      $string = str_replace(array(':beer:'), '<img src="/images/icons/emoji/31.png" alt=""/>',      $string);
      $string = str_replace(array(':banan:'), '<img src="/images/icons/emoji/32.png" alt=""/>',      $string);
      $string = str_replace(array('rose'), '<img src="/images/icons/emoji/33.png" alt=""/>',      $string);
      $string = str_replace(array(':pitushok:'), '<img src="/images/icons/emoji/34.png" alt=""/>',      $string);
      $string = str_replace(array(':sos:'), '<img src="/images/icons/emoji/35.png" alt=""/>',      $string);
      $string = str_replace(array(':cel:'), '<img src="/images/icons/emoji/36.png" alt=""/>',      $string);
      $string = str_replace(array(':crown:'), '<img src="/images/icons/emoji/37.png" alt=""/>',      $string);
     $string = str_replace(array(':baby:'), '<img src="/images/icons/emoji/38.png" alt=""/>',      $string);
      $string = str_replace(array(':boom:'), '<img src="/images/icons/emoji/39.png" alt=""/>',      $string);
      $string = str_replace(array(':gun:'), '<img src="/images/icons/emoji/40.png" alt=""/>',      $string);
      $string = str_replace(array(':love:'), '<img src="/images/icons/emoji/41.png" alt=""/>',      $string);
      $string = str_replace(array(':hurt:'), '<img src="/images/icons/emoji/42.png" alt=""/>',      $string);
      $string = str_replace(array(':police:'), '<img src="/images/icons/emoji/43.png" alt=""/>',      $string);
      $string = str_replace(array(':bolls:'), '<img src="/images/icons/emoji/44.png" alt=""/>',      $string);
      $string = str_replace(array(':ear:'), '<img src="/images/icons/emoji/45.png" alt=""/>',      $string);
      $string = str_replace(array(':fuck:'), '<img src="/images/icons/emoji/46.png" alt=""/>',      $string);
      $string = str_replace(array(':smoke:'), '<img src="/images/icons/emoji/47.png" alt=""/>',      $string);
      $string = str_replace(array(':donate:'), '<img src="/images/icons/emoji/48.png" alt=""/>',      $string);
      $string = str_replace(array(':gold:'), '<img src="/images/icons/emoji/49.png" alt=""/>',      $string);
      $string = str_replace(array(':silver:'), '<img src="/images/icons/emoji/50.png" alt=""/>',      $string);
      $string = str_replace(array(':health:'), '<img src="/images/icons/emoji/51.png" alt=""/>',      $string);
      $string = str_replace(array(':damage:'), '<img src="/images/icons/emoji/52.png" alt=""/>',      $string);
      $string = str_replace(array(':armor:'), '<img src="/images/icons/emoji/53.png" alt=""/>',      $string);
      $string = str_replace(array(':energy:'), '<img src="/images/icons/emoji/54.png" alt=""/>',      $string);
      $string = str_replace(array(':vp1:'), '<img src="/images/icons/emoji/vp1.png" alt=""/>',      $string);
      $string = str_replace(array(':vp2:'), '<img src="/images/icons/emoji/vp2.png" alt=""/>',      $string);
      $string = str_replace(array(':vp3:'), '<img src="/images/icons/emoji/vp3.png" alt=""/>',      $string);
      $string = str_replace(array(':vp4:'), '<img src="/images/icons/emoji/vp4.png" alt=""/>',      $string);
      $string = str_replace(array(':vp5:'), '<img src="/images/icons/emoji/vp5.png" alt=""/>',      $string);
      $string = str_replace(array(':vp6:'), '<img src="/images/icons/emoji/vp6.png" alt=""/>',      $string);
      $string = str_replace(array(':vp7:'), '<img src="/images/icons/emoji/vp7.png" alt=""/>',      $string);
      $string = str_replace(array(':vp8:'), '<img src="/images/icons/emoji/vp8.png" alt=""/>',      $string);
      $string = str_replace(array(':vp9:'), '<img src="/images/icons/emoji/vp9.png" alt=""/>',      $string);
      $string = str_replace(array(':vp10:'), '<img src="/images/icons/emoji/vp10.png" alt=""/>',      $string);
      $string = str_replace(array(':vp11:'), '<img src="/images/icons/emoji/vp11.png" alt=""/>',      $string);
      $string = str_replace(array(':vp12:'), '<img src="/images/icons/emoji/vp12.png" alt=""/>',      $string);
      $string = str_replace(array(':vp13:'), '<img src="/images/icons/emoji/vp13.png" alt=""/>',      $string);
      $string = str_replace(array(':vp14:'), '<img src="/images/icons/emoji/vp14.png" alt=""/>',      $string);
      $string = str_replace(array(':vp15:'), '<img src="/images/icons/emoji/vp15.png" alt=""/>',      $string);
      $string = str_replace(array(':vp16:'), '<img src="/images/icons/emoji/vp16.png" alt=""/>',      $string);
      $string = str_replace(array(':vp17:'), '<img src="/images/icons/emoji/vp17.png" alt=""/>',      $string);
      $string = str_replace(array(':vp18:'), '<img src="/images/icons/emoji/vp18.png" alt=""/>',      $string);
$string = str_replace(array(':sm1:'), '<img src="/images/icons/sm/sm1.gif" alt=""/>',      $string);
$string = str_replace(array(':sm2:'), '<img src="/images/icons/sm/sm2.gif" alt=""/>',      $string);
$string = str_replace(array(':sm3:'), '<img src="/images/icons/sm/sm3.gif" alt=""/>',      $string);
$string = str_replace(array(':sm4:'), '<img src="/images/icons/sm/sm4.gif" alt=""/>',      $string);
$string = str_replace(array(':sm5:'), '<img src="/images/icons/sm/sm5.gif" alt=""/>',      $string);
$string = str_replace(array(':sm6:'), '<img src="/images/icons/sm/sm6.gif" alt=""/>',      $string);
$string = str_replace(array(':sm7:'), '<img src="/images/icons/sm/sm7.gif" alt=""/>',      $string);
$string = str_replace(array(':sm8:'), '<img src="/images/icons/sm/sm8.gif" alt=""/>',      $string);
$string = str_replace(array(':sm9:'), '<img src="/images/icons/sm/sm9.gif" alt=""/>',      $string);
$string = str_replace(array(':sm10:'), '<img src="/images/icons/sm/sm10.gif" alt=""/>',      $string);
$string = str_replace(array(':sm11:'), '<img src="/images/icons/sm/sm11.gif" alt=""/>',      $string);
$string = str_replace(array(':sm12:'), '<img src="/images/icons/sm/sm12.gif" alt=""/>',      $string);
$string = str_replace(array(':sm13:'), '<img src="/images/icons/sm/sm13.gif" alt=""/>',      $string);
$string = str_replace(array(':sm14:'), '<img src="/images/icons/sm/sm14.gif" alt=""/>',      $string);
$string = str_replace(array(':sm15:'), '<img src="/images/icons/sm/sm15.gif" alt=""/>',      $string);
$string = str_replace(array(':sm16:'), '<img src="/images/icons/sm/sm16.gif" alt=""/>',      $string);
$string = str_replace(array(':sm17:'), '<img src="/images/icons/sm/sm17.gif" alt=""/>',      $string);
$string = str_replace(array(':sm18:'), '<img src="/images/icons/sm/sm18.gif" alt=""/>',      $string);
$string = str_replace(array(':sm19:'), '<img src="/images/icons/sm/sm19.gif" alt=""/>',      $string);
$string = str_replace(array(':sm20:'), '<img src="/images/icons/sm/sm20.gif" alt=""/>',      $string);
$string = str_replace(array(':sm21:'), '<img src="/images/icons/sm/sm21.gif" alt=""/>',      $string);
$string = str_replace(array(':sm22:'), '<img src="/images/icons/sm/sm22.gif" alt=""/>',      $string);
$string = str_replace(array(':sm23:'), '<img src="/images/icons/sm/sm23.gif" alt=""/>',      $string);
$string = str_replace(array(':sm24:'), '<img src="/images/icons/sm/sm24.gif" alt=""/>',      $string);
$string = str_replace(array(':sm25:'), '<img src="/images/icons/sm/sm25.gif" alt=""/>',      $string);
$string = str_replace(array(':sm26:'), '<img src="/images/icons/sm/sm26.gif" alt=""/>',      $string);
$string = str_replace(array(':sm27:'), '<img src="/images/icons/sm/sm27.gif" alt=""/>',      $string);
$string = str_replace(array(':sm28:'), '<img src="/images/icons/sm/sm28.gif" alt=""/>',      $string);
    return $string;
    
    }


    function _time($i) {

      $h  = floor(($i / 3600) - $d * 24); 
      
      $m  = floor(($i - $h * 3600 - $d * 86400) / 60); 
      
      $s  = $i - ($m * 60 + $h * 3600 + $d * 86400);
    
      
    return ($h > 0 ? ($h < 10 ? '0':'').$h.':':'').($m > 0 ? ($m < 10 ? '0':'').$m.':':'00:').($s > 0 ? ($s < 10 ? '0':'').$s:'00');
    
    }
    
    function bb($string) {
      
      $string = str_replace("\r\n","<br/>",$string);
    
    return $string;
    
    }
    
    function _times($i) {

      $d  = floor($i / 86400); 
      
      $h  = floor(($i / 3600) - $d * 24); 
      
      $m  = floor(($i - $h * 3600 - $d * 86400) / 60); 
      
      $s  = $i - ($m * 60 + $h * 3600 + $d * 86400);

    
      if($d > 0) {
      
        $result = $d.' д';
       
      }
      elseif($h > 0)
                 {
       
        $result = $h.' ч';
                
      }elseif($m > 0)
                 {
       
      $result = $m.' мин';
                
      }elseif($s >= 0)
                 {
       
      $result = $s.' сек';
                
      }

  return $result.' ';
  
  }

    function _timees($i) {

      $d  = floor($i / 86400); 
      
      $h  = floor(($i / 3600) - $d * 24); 
      
      $m  = floor(($i - $h * 3600 - $d * 86400) / 60); 
      
      $s  = $i - ($m * 60 + $h * 3600 + $d * 86400);

    
      if($d > 0) {
      
        $result = 'заходил '.(date('d ', $user['online']) . $monthes[(date('n', $user['online']))] . date(' Y.г H:i', $user['online']));
       
      }
      elseif($h > 0)
                 {
       
        $result = ' заходил  '.(date('d ', $user['online']) . $monthes[(date('n', $user['online']))] . date(' Y.г H:i', $user['online']));
                
      }elseif($m > 0)
                 {
       
      $result = 'сейчас в игре ';
                
      }elseif($s >= 0)
                 {
       
      $result = 'сейчас в игре ';
                
      }

  return $result.' ';
  
  }


// Вывод даты на русском
$monthes = array(1 => 'Января', 2 => 'Февраля', 3 => 'Марта', 4 => 'Апреля', 5 => 'Мая', 6 => 'Июня', 7 => 'Июля', 8 => 'Августа', 9 => 'Сентября', 10 => 'Октября', 11 => 'Ноября', 12 => 'Декабря');



function bbc($str)
{

//$str = strip_tags($str);
//$str=preg_replace("/@(.+)\@/Usi","<a href='/site.php?nick=\\1'>\\1</a>",$str);
//$str = preg_replace("/@(. )/si","<a href='/site.php?nick=\\1'>\\1</a>",$str);
$str=preg_replace("/\[b\](.+)\[\/b\]/Usi","<strong>\\1</strong>",$str);
$str=preg_replace("/\[i\](.+)\[\/i\]/Usi","<em>\\1</em>",$str);
$str=preg_replace("/\[u\](.+)\[\/u\]/Usi","<u>\\1</u>",$str);
//$str=preg_replace("/\[b\](.+)\[\/b\]/Usi","<big>\\1</big>",$str);
$str=preg_replace("/\[sup\](.+)\[\/sup\]/Usi","<sup>\\1</sup>",$str);
$str=preg_replace("/\[code\](.+)\[\/code\]/Usi","<code>\\1</code>",$str);
$str=preg_replace("/\[color=(.*)](.*)\[\/color\]/Usi", "<font color='\\1'>\\2</font>", $str);
$str=preg_replace("/\[h1\](.+)\[\/h1\]/Usi", "<h1>\\1</h1>", $str);
$str=preg_replace("/\[h2\](.+)\[\/h2\]/Usi", "<h2>\\1</h2>", $str);
$str=preg_replace("/\[h3\](.+)\[\/h3\]/Usi", "<h3>\\1</h3>", $str);
$str=preg_replace("/\[h4\](.+)\[\/h4\]/Usi", "<h4>\\1</h4>", $str);

$str=preg_replace("/\[h5\](.+)\[\/h5\]/Usi", "<h5>\\1</h5>", $str);
$str=preg_replace("/\[h6\](.+)\[\/h6\]/Usi", "<h6>\\1</h6>", $str);
$str=preg_replace("/\[rang=(.*)](.*)\[\/rang\]/Usi", "<div style='background-color:\\1'>\\2</div>", $str);
$str=preg_replace("/\[img=(.*)\]/Usi","<img src='\\1' border=\"0\"/>",$str);
$str=preg_replace("/\[br]/Usi","<br>",$str);
$str=preg_replace("/\[hr]/Usi","<hr>",$str);
//$str = preg_replace("/@(.*)/si","<a href='/site.php?nick=\\1'>$1</a>",$str);
$str=preg_replace("/\[center](.*)\[\/center\]/Usi","<div align=center>\\1</div>",$str);
$str=preg_replace("/\[right](.*)\[\/right\]/Usi","<div align=right>\\1</div>",$str);
$str=preg_replace("/\[left](.*)\[\/left\]/Usi","<div align=left>\\1</div>",$str);
$str=preg_replace("/\[gra3=(.*),(.*),(.*)](.*)\[\/gra\]/Usi","<span style='background: linear-gradient(90deg, #\\1 20%, #\\2 40%, #\\3);-webkit-background-clip: text;-webkit-text-fill-color: transparent;'>\\4</span>",$str);
$str=str_replace("\r\n","<br/>",$str);
return $str;
}


$lik=rand(111111,999999);

$udet=rand(111111,999999);

?>