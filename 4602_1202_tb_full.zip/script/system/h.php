<?

    ob_start();

  list($msec,$sec)
             = explode(chr(32), microtime()); 
  $gtime     = $sec+$msec; 


?>

<!DOCTYPE html PUBLIC "-//WAPFORUM//DTD XHTML Mobile 1.0//EN" "http://www.wapforum.org/DTD/xhtml-mobile10.dtd">
<html lang="ru" xmlns="http://www.w3.org/1999/xhtml">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="csrf-param" content="_csrf">
    <meta name="csrf-token" content="WjFXT1RGOHEfZ2ALJhJUCwUGECINL09HPQQcF2V0XTcYBgImOyNACw==">
        <title>Тюремный беспредел</title>
        <link href="/style.css" rel="stylesheet">
<script src="/js/js-sm.js"></script>
<script src="/js/js-sma.js"></script>

 <link rel="shortcut icon" href="/images/icons/favicon.jpg" />
    </head>
    <body>


<?


      if($user) {


 function _expy($i) {
    switch($i) {
    
      case 1:
          $expy = 36;
       break;

      case 2:
          $expy = 36;
       break;

      case 3:
          $expy = 144;
       break;

      case 4:
          $expy = 216;
       break;

      case 5:
          $expy = 288;
       break;

      case 6:
          $expy = 360;
       break;

      case 7:
          $expy = 432;
       break;

      case 8:
          $expy = 504;
       break;

      case 9:
          $expy = 576;
       break;

      case 10:
          $expy = 648;
       break;

      case 11:
          $expy = 720;
       break;

      case 12:
          $expy = 792;
       break;

      case 13:
          $expy = 864;
       break;

      case 14:
          $expy = 936;
       break;

      case 15:
          $expy = 1008;
       break;

      case 16:
          $expy = 1080;
       break;

      case 17:
          $expy = 1152;
       break;

      case 18:
          $expy = 1224;
       break;

      case 19:
          $expy = 1296;
       break;

      case 20:
          $expy = 1368;
       break;

      case 21:
          $expy = 1440;
       break;

      case 22:
          $expy = 1512;
       break;

      case 23:
          $expy = 1584;
       break;

      case 24:
          $expy = 1656;
       break;

      case 25:
          $expy = 1728;
       break;

      case 26:
          $expy = 1800;
       break;

      case 27:
          $expy = 1872;
       break;

      case 28:
          $expy = 1944;
       break;

      case 29:
          $expy = 2016;
       break;

      case 30:
          $expy = 2088;
       break;

      case 31:
          $expy = 2160;
       break;

      case 32:
          $expy = 2232;
       break;

      case 33:
          $expy = 2304;
       break;

      case 34:
          $expy = 2376;
       break;

      case 35:
          $expy = 2448;
       break;

      case 36:
          $expy = 2520;
       break;

      case 37:
          $expy = 2592;
       break;

      case 38:
          $expy = 2664;
       break;

      case 39:
          $expy = 2736;
       break;

      case 40:
          $expy = 2808;
       break;

      case 41:
          $expy = 2880;
       break;

      case 42:
          $expy = 2952;
       break;

      case 43:
          $expy = 3024;
       break;

      case 44:
          $expy = 3096;
       break;

      case 45:
          $expy = 3168;
       break;

      case 46:
          $expy = 3240;
       break;

      case 47:
          $expy = 3312;
       break;

      case 48:
          $expy = 3384;
       break;
       
      case 49:
          $expy = 3456;
       break;

      case 50:
          $expy = 3528;
       break;

      case 51:
          $expy = 3600;
       break;

      case 52:
          $expy = 3672;
       break;

      case 53:
          $expy = 3744;
       break;

      case 54:
          $expy = 3816;
       break;

      case 55:
          $expy = 3888;
       break;

      case 56:
          $expy = 3960;
       break;

      case 57:
          $expy = 4032;
       break;

      case 58:
          $expy = 4104;
       break;

      case 59:
          $expy = 4176;
       break;

      case 60:
          $expy = 4248;
       break;
      
      case 61:
          $expy = 4320;
        break;

      case 62:
          $expy = 4392;
        break;

      case 63:
          $expy = 4464;
        break;

      case 64:
          $expy = 4536;
        break;

      case 65:
          $expy = 4608;
        break;

      case 66:
          $expy = 4680;
        break;

      case 67:
          $expy = 4752;
        break;

      case 68:
          $expy = 4824;
        break;

      case 69:
          $expy = 4896;
        break;

      case 70:
          $expy = 1569888;
        break;

      case 71:
          $expy = 50400;
        break;

      case 72:
          $expy = 51120;
        break;

      case 73:
          $expy = 51840;
        break;

      case 74:
          $expy = 52560;
        break;

      case 75:
          $expy = 53280;
        break;

      case 76:
          $expy = 54000;
        break;

      case 77:
          $expy = 54720;
        break;

      case 78:
          $expy = 55440;
        break;

      case 79:
          $expy = 56160;
        break;

      case 80:
          $expy = 56880;
        break;

      case 81:
          $expy = 57600;
        break;

      case 82:
          $expy = 58320;
        break;

      case 83:
          $expy = 59040;
        break;

      case 84:
          $expy = 59760;
        break;

      case 85:
          $expy = 60480;
        break;

      case 86:
          $expy = 61200;
        break;

      case 87:
          $expy = 61920;
        break;

      case 88:
          $expy = 62640;
        break;

      case 89:
          $expy = 63360;
        break;

      case 90:
          $expy = 64080;
        break;

      case 91:
          $expy = 64800;
        break;

      case 92:
          $expy = 65520;
        break;

      case 93:
          $expy = 66240;
        break;

      case 94:
          $expy = 66960;
        break;

      case 95:
          $expy = 67680;
        break;

      case 96:
          $expy = 68400;
        break;

      case 97:
          $expy = 69120;
        break;

      case 98:
          $expy = 69840;
        break;

      case 99:
          $expy = 70560;
        break;

      case 100:
          $expy = 12147280;
        break;

      case 101:
          $expy = 720000;
        break;

      case 102:
          $expy = 727200;
        break;

      case 103:
          $expy = 734400;
        break;

      case 104:
          $expy = 741600;
        break;

      case 105:
          $expy = 748800;
        break;

      case 106:
          $expy = 756000;
        break;

      case 107:
          $expy = 763200;
        break;

      case 108:
          $expy = 770400;
        break;

      case 109:
          $expy = 777600;
        break;

      case 110:
          $expy = 784800;
        break;

      case 111:
          $expy = 792000;
        break;

      case 112:
          $expy = 799200;
        break;

      case 113:
          $expy = 813600;
        break;

      case 114:
          $expy = 820800;
        break;

      case 115:
          $expy = 828000;
        break;

      case 116:
          $expy = 835200;
        break;

      case 117:
          $expy = 842400;
        break;

      case 118:
          $expy = 856800;
        break;

      case 119:
          $expy = 864000;
        break;

      case 120:
          $expy = 871200;
        break;

      case 121:
          $expy = 878400;
        break;

      case 122:
          $expy = 885600;
        break;
     
      case 123:
          $expy = 892800;
        break;

      case 124:
          $expy = 900000;
        break;

      case 125:
          $expy = 907200;
        break;

      case 126:
          $expy = 914400;
        break;

      case 127:
          $expy = 921600;
        break;

      case 128:
          $expy = 928800;
        break;

      case 129:
          $expy = 936000;
        break;

      case 130:
          $expy = 943200;
        break;

      case 131:
          $expy = 950400;
        break;

      case 132:
          $expy = 957600;
        break;

      case 133:
          $expy = 964800;
        break;

      case 134:
          $expy = 972000;
        break;

      case 135:
          $expy = 979200;
        break;

      case 136:
          $expy = 993600;
        break;

      case 137:
          $expy = 1000800;
        break;

      case 138:
          $expy = 1008000;
        break;

      case 139:
          $expy = 1015200;
        break;

      case 140:
          $expy = 1022400;
        break;

      case 141:
          $expy = 1029600;
        break;

      case 142:
          $expy = 1036800;
        break;

      case 143:
          $expy = 1044000;
        break;

      case 144:
          $expy = 1051200;
        break;

      case 145:
          $expy = 1058400;
        break;

      case 146:
          $expy = 1065600;
        break;

      case 147:
          $expy = 1072800;
        break;

      case 148:
          $expy = 1092800;
        break;

      case 149:
          $expy = 1112000;
        break;

      case 150:

          $expy = 1142000;

        break;
   }
      return $expy;
    }


    function _exp($i) {
    switch($i) {
    
      case 1:
          $exp = 36;
       break;

      case 2:
          $exp = 72;
       break;

      case 3:
          $exp = 216;
       break;

      case 4:
          $exp = 432;
       break;

      case 5:
          $exp = 720;
       break;

      case 6:
          $exp = 1080;
       break;

      case 7:
          $exp = 1512;
       break;

      case 8:
          $exp = 2016;
       break;

      case 9:
          $exp = 2592;
       break;

      case 10:
          $exp = 3240;
       break;

      case 11:
          $exp = 3960;
       break;

      case 12:
          $exp = 4752;
       break;

      case 13:
          $exp = 5616;
       break;

      case 14:
          $exp = 6552;
       break;

      case 15:
          $exp = 7560;
       break;

      case 16:
          $exp = 8640;
       break;

      case 17:
          $exp = 9792;
       break;

      case 18:
          $exp = 11016;
       break;

      case 19:
          $exp = 12312;
       break;

      case 20:
          $exp = 13680;
       break;

      case 21:
          $exp = 15120;
       break;

      case 22:
          $exp = 16632;
       break;

      case 23:
          $exp = 18216;
       break;

      case 24:
          $exp = 19872;
       break;

      case 25:
          $exp = 21600;
       break;

      case 26:
          $exp = 23400;
       break;

      case 27:
          $exp = 25272;
       break;

      case 28:
          $exp = 27216;
       break;

      case 29:
          $exp = 29232;
       break;

      case 30:
          $exp = 31320;
       break;

      case 31:
          $exp = 33480;
       break;

      case 32:
          $exp = 35712;
       break;

      case 33:
          $exp = 38016;
       break;

      case 34:
          $exp = 40392;
       break;

      case 35:
          $exp = 42840;
       break;

      case 36:
          $exp = 45360;
       break;

      case 37:
          $exp = 47952;
       break;

      case 38:
          $exp = 50616;
       break;

      case 39:
          $exp = 53352;
       break;

      case 40:
          $exp = 56160;
       break;

      case 41:

          $exp = 59040;
       break;

      case 42:
          $exp = 61992;
       break;

      case 43:
          $exp = 65016;
       break;

      case 44:
          $exp = 68112;
       break;

      case 45:
          $exp = 71280;
       break;

      case 46:
          $exp = 74520;
       break;

      case 47:
          $exp = 77832;
       break;

      case 48:
          $exp = 81216;
       break;
       
      case 49:
          $exp = 84672;
       break;

      case 50:
          $exp = 88200;
       break;

      case 51:
          $exp = 91800;
       break;

      case 52:
          $exp = 95472;
       break;

      case 53:
          $exp = 99216;
       break;

      case 54:
          $exp = 103032;
       break;

      case 55:
          $exp = 106920;
       break;

      case 56:
          $exp = 110880;
       break;

      case 57:
          $exp = 114912;
       break;

      case 58:
          $exp = 119016;
       break;

      case 59:
          $exp = 123192;
       break;

      case 60:
          $exp = 127440;
       break;
      
      case 61:
          $exp = 131760;
        break;

      case 62:
          $exp = 136152;
        break;

      case 63:
          $exp = 140616;
        break;

      case 64:
          $exp = 145152;
        break;

      case 65:
          $exp = 149760;
        break;

      case 66:
          $exp = 154440;
        break;

      case 67:
          $exp = 159192;
        break;

      case 68:
          $exp = 164016;
        break;

      case 69:
          $exp = 168912;
        break;

      case 70:
          $exp = 1738800;
        break;

      case 71:
          $exp = 1789200;
        break;

      case 72:
          $exp = 1840320;
        break;

      case 73:
          $exp = 1892160;
        break;

      case 74:
          $exp = 1944720;
        break;

      case 75:
          $exp = 1998000;
        break;

      case 76:
          $exp = 2052000;
        break;

      case 77:
          $exp = 2106720;
        break;

      case 78:
          $exp = 2162160;
        break;

      case 79:
          $exp = 2218320;
        break;

      case 80:
          $exp = 2275200;
        break;

      case 81:
          $exp = 2332800;
        break;

      case 82:
          $exp = 2391120;
        break;

      case 83:
          $exp = 2450160;
        break;

      case 84:
          $exp = 2509920;
        break;

      case 85:
          $exp = 2570400;
        break;

      case 86:
          $exp = 2631600;
        break;

      case 87:
          $exp = 2693520;
        break;

      case 88:
          $exp = 2756160;
        break;

      case 89:
          $exp = 2819520;
        break;

      case 90:
          $exp = 2883600;
        break;

      case 91:
          $exp = 2948400;
        break;

      case 92:
          $exp = 3013920;
        break;

      case 93:
          $exp = 3080160;
        break;

      case 94:
          $exp = 3147120;
        break;

      case 95:
          $exp = 3214800;
        break;

      case 96:
          $exp = 3283200;
        break;

      case 97:
          $exp = 3352320;
        break;

      case 98:
          $exp = 3422160;
        break;

      case 99:
          $exp = 0;
        break;

      case 100:
          $exp = 12147280;
        break;

      case 101:
          $exp = 12867280;
        break;

      case 102:
          $exp = 13594280;
        break;

      case 103:
          $exp = 14328680;
        break;

      case 104:
          $exp = 15070280;
        break;

      case 105:
          $exp = 15819080;
        break;

      case 106:
          $exp = 16575080;
        break;

      case 107:
          $exp = 17338280;
        break;

      case 108:
          $exp = 18108680;
        break;

      case 109:
          $exp = 18886280;
        break;

      case 110:
          $exp = 19671080;
        break;

      case 111:
          $exp = 20463080;
        break;

      case 112:
          $exp = 21262280;
        break;

      case 113:
          $exp = 22075880;
        break;

      case 114:
          $exp = 22896680;
        break;

      case 115:
          $exp = 23724680;
        break;

      case 116:
          $exp = 24559880;
        break;

      case 117:
          $exp = 25402280;
        break;

      case 118:
          $exp = 26259080;
        break;

      case 119:
          $exp = 27123080;
        break;

      case 120:
          $exp = 27994280;
        break;

      case 121:
          $exp = 28872680;
        break;

      case 122:
          $exp = 29758280;
        break;
     
      case 123:
          $exp = 30651080;
        break;

      case 124:
          $exp = 31551080;
        break;

      case 125:
          $exp = 32458280;
        break;

      case 126:
          $exp = 33372680;
        break;

      case 127:
          $exp = 34294280;
        break;

      case 128:
          $exp = 35223080;
        break;

      case 129:
          $exp = 36159080;
        break;

      case 130:
          $exp = 37102280;
        break;

      case 131:
          $exp = 38052680;
        break;

      case 132:
          $exp = 39017480;
        break;

      case 133:
          $exp = 39989480;
        break;

      case 134:
          $exp = 40961480;
        break;

      case 135:
          $exp = 41040680;
        break;

      case 136:
          $exp = 42934280;
        break;

      case 137:
          $exp = 43935080;
        break;

      case 138:
          $exp = 44943080;
        break;

      case 139:
          $exp = 45958280;
        break;

      case 140:
          $exp = 46980680;
        break;

      case 141:
          $exp = 48010280;
        break;

      case 142:
          $exp = 49047080;
        break;

      case 143:
          $exp = 50091080;
        break;

      case 144:
          $exp = 51142280;
        break;

      case 145:
          $exp = 52200680;
        break;

      case 146:
          $exp = 53266280;
        break;

      case 147:
          $exp = 54330080;
        break;

      case 148:
          $exp = 55431880;
        break;

      case 149:
          $exp = 56543880;
        break;

      case 150:

          $exp = 57685880;

        break;
   }
      return $exp;
    }





$exy = 40 + ($user['level'] * 45)*17;
        $exp_progress = round(100/(_expy($user['level'])/$user['exp']));

    
    if($exp_progress > 100) {
        
        $exp_progress = 100;
     
    }

    function clan_exp($i) {
    
    switch($i) {
    
      case 1:
          $clan_exp = 300;
       break;

      case 2:
          $clan_exp = 580;
       break;

      case 3:
          $clan_exp = 1101;
       break;

      case 4:
          $clan_exp = 2010;
       break;

      case 5:
          $clan_exp = 3094;
       break;

      case 6:
          $clan_exp = 7032;
       break;

      case 7:
          $clan_exp = 13046;
       break;

      case 8:
          $clan_exp = 20449;
       break;

      case 9:
          $clan_exp = 44008;
       break;

      case 10:
          $clan_exp = 78046;
       break;

      case 11:
          $clan_exp = 138008;
       break;

      case 12:
          $clan_exp = 240205;
       break;

      case 13:
          $clan_exp = 413203;
       break;

      case 14:
          $clan_exp = 702490;
       break;

      case 15:
          $clan_exp = 1180108;
       break;

      case 16:
          $clan_exp = 1959009;
       break;

      case 17:
          $clan_exp = 3212900;
       break;

      case 18:
          $clan_exp = 5204809;
       break;

      case 19:
          $clan_exp = 8327802;
       break;

      case 20:
          $clan_exp = 13157905;
       break;

      case 21:
          $clan_exp = 20526040;
       break;

      case 22:
          $clan_exp = 31610065;
       break;

      case 23:
          $clan_exp = 48048018;
       break;

      case 24:
          $clan_exp = 72072027;
       break;

      case 25:
          $clan_exp = 106660695;
       break;

      case 26:
          $clan_exp = 155730374;
       break;

      case 27:
          $clan_exp = 224250658;
       break;

      case 28:
          $clan_exp = 318444034;
       break;

      case 29:
          $clan_exp = 445802207;
       break;

      case 30:
          $clan_exp = 601500000;
       break;

      case 31:
          $clan_exp = 830700000;
       break;

      case 32:
          $clan_exp = 1102100000;
       break;

      case 33:
          $clan_exp = 1408000000;
       break;

      case 34:
          $clan_exp = 1920400000;


       break;




      case 35:
          $clan_exp = 2406300000;
       break;

      case 36:
          $clan_exp = 3010300000;
       break;

     case 37:
          $clan_exp = 30010300000;
       break;

    case 38:
          $clan_exp = 3910300000;
       break;
   
    case 39:
          $clan_exp = 4010300000;
       break;

   case 40:
          $clan_exp = 5000000000;

       break; 
    }
    
      return $clan_exp;
    
    }

$lvlc = 250 + ($clan['level'] * $clan['level'] * 125)*4;
    if($clan && $clan['level'] < 4000 && $clan['exp'] >= $lvlc) {
      
      mysql_query('UPDATE `clans` SET `level` = `level` + 1,
                                        `exp` = "'.$clan['exp'].'" WHERE `id` = "'.$clan['id'].'"');

    }


  $mail = mysql_result(mysql_query('SELECT COUNT(*) FROM `mail` WHERE `to` = "'.$user['id'].'" AND `read` = "0"'),0);




?>

      <div class="header"> <div class="block center small">
    <img src="/images/icons/currentHealth.png" width="16" height="16" alt=""> <?=$user['hp']?>                
    <img src="/images/icons/currentEnergy.png" width="16" height="16" alt=""> <?=$user['mp']?>                                                                                                                    
<?
if(!$clan){
if(!$clan && $clan['id']){
$dop = mysql_query('SELECT * FROM `podval` WHERE `start` = "0" LIMIT 1');
  $dop = mysql_fetch_array($dop);
  $dop_time = round(($dop['time'] - time(200)));
echo'  
'.($dop_time > 200 ? ' ':' <a href="/dop/"><img src="/images/icons/clan.png" width="16" height="16" alt=""></a> ').' ';
}
}
?>
<?
if($user['level'] >= 10 && $user['level'] <= 29) {
$lvlh=1;
}
if($user['level'] >= 30 && $user['level'] <= 49) {
$lvlh=2;
}
if($user['level'] >= 50 && $user['level'] <= 69) {
$lvlh=3;
}
if($user['level'] >= 70 && $user['level'] <= 79) {
$lvlh=4;
}
if($user['level'] >= 80 && $user['level'] <= 99) {
$lvlh=5;
}
if($user['level'] >= 100 && $user['level'] <= 129) {
$lvlh=6;
}
if($user['level'] >= 130 && $user['level'] <= 150) {
$lvlh=7;
}
$undying = mysql_query('SELECT * FROM `undying` WHERE `start` = "0" AND `lvl`="'.$lvlh.'" LIMIT 1');
  $undying = mysql_fetch_array($undying);
  $undying_time = round(($undying['time'] - time(200)));
echo'  
'.($undying_time > 200 ? ' ':'<a href="/bunt/"><img src="/images/icons/boss.png" width="16" height="16" alt=""></a>').' ';
?>
<?

if($mail > 0) {

?>

<a href='/mail/?<?=$udet?>'><img src='/images/icons/mail.png' alt=''/></a>

<?

}
if($user['gift']==1){
?>
<a href='/gift/?con'><img src="/images/icons/gift.png" width="16" height="16" alt=""></a>
<?
}
$journal = mysql_result(mysql_query('SELECT COUNT(*) FROM `journal` WHERE `from` = "'.$user['id'].'" AND `read` = "0"'),0);
if($journal > 0) {
?>
<a href='/journal.php'><img src="/images/icons/dialog.png" width="16" height="16" alt=""></a>
<?
}
if($user['clan_chaat']==1){
?>
<a href='/chat/clan/?cot'><img src="/images/icons/circle.png" width="16" height="16" alt=""></a>
<?
}

$hp_u = round(100 / ($user['vit']/ $user['hp']));
if($hp_u){
$hp_u=100;
}
?>

</div>
            </div>    


         <div style="width: 100%; height: 2px"
            class="progress-grey">
            <div style="width: <?=$exp_progress?>%; height: 2px" class="progress-green"></div></div>

<?
if($user['bg_d']==1){
?>
<div class="alert">
        <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Босяцкий подгон <img src="/images/icons/reward.png" width="16" height="16" alt=""></div>
    <div class="a_separator"></div>
    За верность к игре, для тебя есть бодрый подгон!
    <div class="m3">
        <span class="btn_start"><span class="btn_end"><a class="btn" href="/take/?day">Получить подгон</a></span> </span>    </div>
</div>
<div class="line"></div>
<?
}
if ($user['news_read'] == '1')
{

	$newsCheck = mysql_query("SELECT * FROM `forum_topic` WHERE `sub`='13' ORDER BY `id` DESC LIMIT 1");
	$data = mysql_fetch_assoc($newsCheck);

	if (isset($_GET['readandgo']))
	{
		mysql_query("UPDATE `users` SET `news_read` ='0' WHERE `id`='".$user['id']."'");
		header("Location:/forum/topic/".$data['id']);
		exit;
	}

	if (isset($_GET['news']))
	{
		mysql_query("UPDATE `users` SET `news_read` ='0' WHERE `id`='".$user['id']."'");
		header("Location: ?'.$udet.'");
		exit;
	}

   $news = mysql_query('SELECT * FROM `forum_topic` WHERE `id` = "'.$data['id'].'"');
     while($news = mysql_fetch_array($news))
     {

		?>

    <div class="alert">
    <div class="blue s125">Тюремный вестник</div>
    <i><?=$news['name']?></i>
    <div class="a_separator"></div>
            <a href="?readandgo">читать</a>       <span class='color2 small'>|</span>            <a href="?news?<?=$udet?>">скрыть</a>        </div>
<div class="line"></div>
	<?
	 }
}
?>

<?
$gu = mysql_query('SELECT * FROM `quest` WHERE `user` = "'.$user['id'].'"');  
  $gu = mysql_fetch_array($gu);
 if(!$gu) {
    mysql_query('INSERT INTO `quest` (`user`) VALUES ("'.$user['id'].'")');
  }

$var = 1;
$qulets = mysql_fetch_array(mysql_query('SELECT * FROM `quest` WHERE `user` = "'.$user['id'].'"'));
if($qulets['boss4']==0){
if($user['boss4']>=50){
mysql_query('UPDATE `quest` SET `boss4` = "'.$var.'" WHERE `user` = "'.$user['id'].'" LIMIT 1');
mysql_query('UPDATE `users` SET `zdk`=`zdk` +1
WHERE `id` = "'.$user['id'].'"');
}
}
if($qulets['bos7']==0){
if($user['bos7']>=10){
mysql_query('UPDATE `quest` SET `bos7` = "'.$var.'" WHERE `user` = "'.$user['id'].'" LIMIT 1');
mysql_query('UPDATE `users` SET `zdk`=`zdk` +1
WHERE `id` = "'.$user['id'].'"');
}
}
if($qulets['bos10']==0){
if($user['bos10']>=8){
mysql_query('UPDATE `quest` SET `bos10` = "'.$var.'" WHERE `user` = "'.$user['id'].'" LIMIT 1');
mysql_query('UPDATE `users` SET `zdk`=`zdk` +1
WHERE `id` = "'.$user['id'].'"');
}
}
if($qulets['bunt']==0){
if($user['bunt']>=6){
mysql_query('UPDATE `quest` SET `bunt` = "'.$var.'" WHERE `user` = "'.$user['id'].'" LIMIT 1');
mysql_query('UPDATE `users` SET `zdk`=`zdk` +1
WHERE `id` = "'.$user['id'].'"');
}
}
if($qulets['go']==0){
if($user['go']>=3){
mysql_query('UPDATE `quest` SET `go` = "'.$var.'" WHERE `user` = "'.$user['id'].'" LIMIT 1');
mysql_query('UPDATE `users` SET `zdk`=`zdk` +1
WHERE `id` = "'.$user['id'].'"');
}
}
if($qulets['are']==0){
if($user['are']>=100){
mysql_query('UPDATE `quest` SET `are` = "'.$var.'" WHERE `user` = "'.$user['id'].'" LIMIT 1');
mysql_query('UPDATE `users` SET `zdk`=`zdk` +1
WHERE `id` = "'.$user['id'].'"');
}
}
if($qulets['zdk']==0){
if($user['zdk']>=6){
?>
<div class="alert"><div><div>
<div class="green s125">Ты выполнил срочняки</div></div><div class="a_separator"></div><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Награда:</div>
    <img src='/images/icons/gold.png' alt=''/> 780 <img src='/images/icons/silver.png' alt=''/> 16460 <img src='/images/icons/experience.png' alt=''/> 23870
</div></div></div>
<div class="line"></div>
<?
   
mysql_query('UPDATE `quest` SET `zdk` = "'.$var.'" WHERE `user` = "'.$user['id'].'" LIMIT 1');
   mysql_query('UPDATE `users` SET `g` = "'.($user['g']+780).'",`exp`=`exp` +23870,`exepy`=`exepy` +23870,`s`=`s` +16460 WHERE `id` = "'.$user['id'].'"');

}
}

if($qulets['bosy2']==0){
if($user['bosy2']>=30){
?>
<div class="alert"><div><div>
<div class="green s125">Ты выполнил срочняки</div></div><div class="a_separator"></div><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Награда:</div>
    <img src='/images/icons/gold.png' alt=''/> 16 <img src='/images/icons/silver.png' alt=''/> 1200 <img src='/images/icons/experience.png' alt=''/> 1130
</div></div></div>
<div class="line"></div>
<?
   
mysql_query('UPDATE `quest` SET `bosy2` = "'.$var.'" WHERE `user` = "'.$user['id'].'" LIMIT 1');
   mysql_query('UPDATE `users` SET `g` = "'.($user['g']+16).'",`exp`=`exp` +1130,`exepy`=`exepy` +1130,`s`=`s` +1200 WHERE `id` = "'.$user['id'].'"');

}
}
if($qulets['bosy4']==0){
if($user['bosy4']>=15){
?>
<div class="alert"><div><div>
<div class="green s125">Ты выполнил срочняки</div></div><div class="a_separator"></div><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Награда:</div>
    <img src='/images/icons/gold.png' alt=''/> 18 <img src='/images/icons/silver.png' alt=''/> 1750 <img src='/images/icons/experience.png' alt=''/> 1367
</div></div></div>
<div class="line"></div>
<?
   
mysql_query('UPDATE `quest` SET `bosy4` = "'.$var.'" WHERE `user` = "'.$user['id'].'" LIMIT 1');
   mysql_query('UPDATE `users` SET `g` = "'.($user['g']+18).'",`exp`=`exp` +1130,`exepy`=`exepy` +1750,`s`=`s` +1367 WHERE `id` = "'.$user['id'].'"');

}
}
if($qulets['bosy6']==0){
if($user['bosy6']>=20){
?>
<div class="alert"><div><div>
<div class="green s125">Ты выполнил срочняки</div></div><div class="a_separator"></div><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Награда:</div>
    <img src='/images/icons/gold.png' alt=''/> 16 <img src='/images/icons/silver.png' alt=''/> 1300 <img src='/images/icons/experience.png' alt=''/> 1424
</div></div></div>
<div class="line"></div>
<?
   
mysql_query('UPDATE `quest` SET `bosy6` = "'.$var.'" WHERE `user` = "'.$user['id'].'" LIMIT 1');
   mysql_query('UPDATE `users` SET `g` = "'.($user['g']+16).'",`exp`=`exp` +1130,`exepy`=`exepy` +1130,`s`=`s` +1424 WHERE `id` = "'.$user['id'].'"');

}
}
if($qulets['are1']==0){
if($user['are1']>=80){
?>
<div class="alert"><div><div>
<div class="green s125">Ты выполнил срочняки</div></div><div class="a_separator"></div><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Награда:</div>
    <img src='/images/icons/gold.png' alt=''/> 20 <img src='/images/icons/silver.png' alt=''/> 2458 <img src='/images/icons/experience.png' alt=''/> 1589
</div></div></div>
<div class="line"></div>
<?
   
mysql_query('UPDATE `quest` SET `are1` = "'.$var.'" WHERE `user` = "'.$user['id'].'" LIMIT 1');
   mysql_query('UPDATE `users` SET `g` = "'.($user['g']+20).'",`exp`=`exp` +1589,`exepy`=`exepy` +1589,`s`=`s` +2458 WHERE `id` = "'.$user['id'].'"');

}
}
if($qulets['bossy3']==0){
if($user['bossy3']>=18){
?>
<div class="alert"><div><div>
<div class="green s125">Ты выполнил срочняки</div></div><div class="a_separator"></div><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Награда:</div>
    <img src='/images/icons/gold.png' alt=''/> 18 <img src='/images/icons/silver.png' alt=''/> 2320 <img src='/images/icons/experience.png' alt=''/> 2368
</div></div></div>
<div class="line"></div>
<?
   
mysql_query('UPDATE `quest` SET `bossy3` = "'.$var.'" WHERE `user` = "'.$user['id'].'" LIMIT 1');
   mysql_query('UPDATE `users` SET `g` = "'.($user['g']+18).'",`exp`=`exp` +2320,`exepy`=`exepy` +2320,`s`=`s` +2368 WHERE `id` = "'.$user['id'].'"');

}
}
if($qulets['bossy5']==0){
if($user['bossy5']>=14){
?>
<div class="alert"><div><div>
<div class="green s125">Ты выполнил срочняки</div></div><div class="a_separator"></div><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Награда:</div>
    <img src='/images/icons/gold.png' alt=''/> 35 <img src='/images/icons/silver.png' alt=''/> 3480 <img src='/images/icons/experience.png' alt=''/> 2186
</div></div></div>
<div class="line"></div>
<?
   
mysql_query('UPDATE `quest` SET `bossy5` = "'.$var.'" WHERE `user` = "'.$user['id'].'" LIMIT 1');
   mysql_query('UPDATE `users` SET `g` = "'.($user['g']+35).'",`exp`=`exp` +3480,`exepy`=`exepy` +3480,`s`=`s` +2186 WHERE `id` = "'.$user['id'].'"');

}
}
if($qulets['chat_ob']==0){
if($user['chat_ob']>=200){
?>
<div class="alert"><div><div>
<div class="green s125">Ты выполнил срочняки</div></div><div class="a_separator"></div><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Награда:</div>
    <img src='/images/icons/gold.png' alt=''/> 100 <img src='/images/icons/silver.png' alt=''/> 3677 <img src='/images/icons/experience.png' alt=''/> 3367
<img src='/images/icons/donate.png' alt=''/> 50
</div></div></div>
<div class="line"></div>
<?
   
mysql_query('UPDATE `quest` SET `chat_ob` = "'.$var.'" WHERE `user` = "'.$user['id'].'" LIMIT 1');
   mysql_query('UPDATE `users` SET `g` = "'.($user['g']+100).'",`exp`=`exp` +3367,`exepy`=`exepy` +3367,`s`=`s` +3677,`d`=`d` +50 WHERE `id` = "'.$user['id'].'"');

}
}
$gy = mysql_query('SELECT * FROM `clan_quest` WHERE `clan` = "'.$clan['id'].'"');  
  $gy = mysql_fetch_array($gy);
 if(!$gy) {
    mysql_query('INSERT INTO `clan_quest` (`clan`) VALUES ("'.$clan['id'].'")');
  }
$qul = mysql_fetch_array(mysql_query('SELECT * FROM `clan_quest` WHERE `clan` = "'.$clan['id'].'"'));
if($qul['bos3']==0){
if($clan['bos3']>=700){
?>
<div class="alert"><div><div>
<div class="green s125">Ваша банда выполнила срочняки</div></div><div class="a_separator"></div><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Награда:</div>
    <img src='/images/icons/gold.png' alt=''/> 350 <img src='/images/icons/silver.png' alt=''/> 24'200 <img src='/images/icons/experience.png' alt=''/> 240'000
</div></div></div>
<div class="line"></div>
<?
$texy="Ваша банда выполнила срочняки награда: <img src=/images/icons/silver.png width=16 height=16 alt=> 24200 <img src=/images/icons/gold.png width=16 height=16 alt=> 350 <img src=/images/icons/experience.png width=16 height=16 alt=> 240000";
mysql_query('INSERT INTO `chat` SET `user` = "3",`time` = "'.time().'",`text` = "'.$texy.'",`clan` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_quest` SET `bos3` = "'.$var.'" WHERE `clan` = "'.$clan['id'].'" LIMIT 1');
   mysql_query('UPDATE `clans` SET `g` = "'.($clan['g']+350).'", `s` = "'.($clan['s']+24200).'",`exp`=`exp` +240000 WHERE `id` = "'.$clan['id'].'"');

}
}
if($qul['bos5']==0){
if($clan['bos5']>=350){
?>
<div class="alert"><div><div>
<div class="green s125">Ваша банда выполнила срочняки</div></div><div class="a_separator"></div><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Награда:</div>
    <img src='/images/icons/gold.png' alt=''/> 400 <img src='/images/icons/silver.png' alt=''/> 34'750 <img src='/images/icons/experience.png' alt=''/> 290'000
</div></div></div>
<div class="line"></div>
<?
$texy="Ваша банда выполнила срочняки награда: <img src=/images/icons/silver.png width=16 height=16 alt=> 34750 <img src=/images/icons/gold.png width=16 height=16 alt=> 400 <img src=/images/icons/experience.png width=16 height=16 alt=> 290000";
mysql_query('INSERT INTO `chat` SET `user` = "2",`time` = "'.time().'",`text` = "'.$texy.'",`clan` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_quest` SET `bos5` = "'.$var.'" WHERE `clan` = "'.$clan['id'].'" LIMIT 1');
   mysql_query('UPDATE `clans` SET `g` = "'.($clan['g']+400).'", `s` = "'.($clan['s']+34750).'",`exp`=`exp` +290000 WHERE `id` = "'.$clan['id'].'"');

}
}
if($qul['bos7']==0){
if($clan['bos7']>=200){
?>
<div class="alert"><div><div>
<div class="green s125">Ваша банда выполнила срочняки</div></div><div class="a_separator"></div><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Награда:</div>
    <img src='/images/icons/gold.png' alt=''/> 750 <img src='/images/icons/silver.png' alt=''/> 45360 <img src='/images/icons/experience.png' alt=''/> 350'000
</div></div></div>
<div class="line"></div>
<?
$texy="Ваша банда выполнила срочняки награда: <img src=/images/icons/silver.png width=16 height=16 alt=> 45360 <img src=/images/icons/gold.png width=16 height=16 alt=> 750 <img src=/images/icons/experience.png width=16 height=16 alt=> 350000";
mysql_query('INSERT INTO `chat` SET `user` = "2",`time` = "'.time().'",`text` = "'.$texy.'",`clan` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_quest` SET `bos7` = "'.$var.'" WHERE `clan` = "'.$clan['id'].'" LIMIT 1');
   mysql_query('UPDATE `clans` SET `g` = "'.($clan['g']+750).'", `s` = "'.($clan['s']+45360).'",`exp`=`exp` +350000 WHERE `id` = "'.$clan['id'].'"');

}
}
?>
<?

$exy = 40 + ($user['level'] * 45)*17;
    if($user['level'] < 150 && $user['exp'] >= _expy($user['level'])) {
        
        $g = 4 + ($user['level'] * 2) - 5;
    
$s = 35 + ($user['level'] * 15) - 5;
    mysql_query('UPDATE `users` SET `level` = `level` + 1,
 `exp` = "0", `exepy` = "'._exp($user['level']).'",
`hp` = "'.($user['vit']).'",
`mp` = "'.$user['mana'].'", `g` = "'.($user['g'] + $g).'", `s` = "'.($user['s'] + $s).'" WHERE `id` = "'.$user['id'].'"');

mysql_query('DELETE FROM `undying_member` WHERE `user` = "'.$user['id'].'"');
?>

 <div class="alert"><div><div>
<div class="green s125">Ты достиг <?=($user['level']+1)?> <img src="/images/icons/level.png" width="16" height="16" alt=""> уровня</div></div><div class="a_separator"></div><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Прибыль:</div>
    <img src="/images/icons/gold.png" width="16" height="16" alt=""> Сахар:+<?=$g?>
</div><div class="a_separator"></div><div>                         <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Прибыль:</div>
<img src="/images/icons/silver.png" width="16" height="16" alt=""> Рубли:+<?=$s?>
</div></div></div>
<div class="line"></div>

<?

        
    }

if($clan) {

      $clan_msg = mysql_fetch_array(mysql_query('SELECT * FROM `clan_msg` WHERE `clan` = "'.$clan['id'].'" AND `time` >= "'.$clan_memb['time'].'" ORDER BY `time` DESC LIMIT 1'));
  if($clan_msg && mysql_result(mysql_query('SELECT COUNT(*) FROM `clan_msg_read` WHERE `msg` = "'.$clan_msg['id'].'" AND `user` = "'.$user['id'].'"'),0) == 0 ) {
 $clan_msg_user = mysql_fetch_array(mysql_query('SELECT * FROM `users` WHERE `id` = "'.$clan_msg['user'].'"'));

  if($_GET['clan_msg_read'] == true) {
    
    mysql_query('INSERT INTO `clan_msg_read` (`msg`,
                                             `user`, `clan`) VALUES ("'.$clan_msg['id'].'",
                                                                 "'.$user['id'].'", "'.$clan['id'].'")');

  header('location: '.$_SERVER['PHP_SELF'].'?'.$udet.'');
  

  }

?>




 <div class="alert">


        <div class="color3">Оповещение
            <img src="/images/icons/clan.png" width="16" height="16" alt="">            <a href="/clan/<?=$clan['id']?>/?<?=$udet?>">банды</a></div>
        <div class="a_separator"></div>
        
                <span class="small">
        <i>  <?=smiles($clan_msg['text'])?></i>
        <img src="/images/icons/<?=$clan_msg_user['r']?>.png" width="16" height="16" alt=""> <a class="color3" href="/user/<?=$clan_msg_user['id']?>/"><?=$clan_msg_user['login']?></a>  <span class="small green"> * </span>        <span class="color2">, <?=_times(time() - $clan_msg['time'])?>. назад</span>
    </span>
        <div><a class="color2 small" href="?clan_msg_read=true?<?=$udet?>">скрыть оповещение</a>        </div>
    </div>
    <div class="line"></div>

<?

}

}
else
{

  if(mysql_result(mysql_query('SELECT COUNT(*) FROM `clan_invite` WHERE `user` = "'.$user['id'].'"'),0) > 0) {
  
    $_invite = mysql_fetch_array(mysql_query('SELECT * FROM `clan_invite` WHERE `user` = "'.$user['id'].'"'));
$clan_invite = mysql_fetch_array(mysql_query('SELECT * FROM `clans` WHERE `id` = "'.$_invite['clan'].'"'));
        


      if($_GET['invite'] == $clan_invite['id']) {

        mysql_query('INSERT INTO `clan_memb` (`clan`,
                                                `user`,
                                                `time`,
                                         `last_update`,`rank`) VALUES ("'.$clan_invite['id'].'",  
                                                                       "'.$user['id'].'",
                                                                            "'.time().'",
                                                       "'.(time() + ((60 * 60) * 24)).'","1")');


$timey = time();

$texy="присоединился к банде по приглашению  <img src=/images/icons/1.png alt=> <a href=/user/$_invite[us]>$_invite[logn]</a> ";
mysql_query('INSERT INTO `clan_journal` SET `cl_id` = "'.$clan_invite['id'].'",`time` = "'.$timey.'",`login` = "'.$user['login'].'",`user` = "'.$user['id'].'", `cl` = "2",`text` = "'.$texy.'",`loginp` = "'.$_invite['logn'].'",`userp` = "'.$_invite['us'].'"');

mysql_query('INSERT INTO `clan_rud_user` SET `clan` = "'.$clan_invite['id'].'",`user` = "'.$user['id'].'"');

mysql_query('DELETE FROM `clan_invite` WHERE `user` = "'.$user['id'].'"');

        header('location: /clan/');
        exit;
    
      }
    
    if($_GET['cancel_invite'] == true){
    
      mysql_query('DELETE FROM `clan_invite` WHERE `clan` = "'.$clan_invite['id'].'" AND `user` = "'.$user['id'].'"');
    
      header('location: '.$_SERVER['PHP_SELF'].'');
      exit;
    
    }

?>


<div class="alert"><div><span class="color3 s125">Вас приглашают в банду</span></div><div class="a_separator"></div><div>
<img src="/images/icons/clan.png" width="16" height="16" alt="">&nbsp;<a href="/clan/<?=$clan_invite['id']?>"><?=$clan_invite['name']?></a>,
<?=$clan_invite['level']?> <img src="/images/icons/level.png" width="16" height="16" alt=""> ур.
<br/> Члены банды: <b><?=mysql_result(mysql_query('SELECT COUNT(*) FROM `clan_memb` WHERE `clan` = "'.$clan_invite['id'].'"'),0)?>/10</b>
<div class="a_separator"></div>
<span class="btn_start"><span class="btn_end"><a class="btn" href="?invite=<?=$clan_invite['id']?>">Вступить</a></span> </span>&nbsp;<span class="btn_start"><span class="btn_end"><a class="btn" href="?cancel_invite=true">Отказаться</a></span> </span></div></div>
<div class="line"></div>
<?
    
    }

}


if(isset($_SESSION['not'])){
echo $_SESSION['not'];
unset($_SESSION['not']);
}
if(isset($_SESSION['err'])){
echo $_SESSION['err'];
unset($_SESSION['err']);
}



    }
    else
    {

if(isset($_SESSION['noty'])){
echo $_SESSION['noty'];
unset($_SESSION['noty']);
}
?>
  
<?

    }


?>