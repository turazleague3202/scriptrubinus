<?

session_start();
      
      
error_reporting(0);
 
$db_host = 'localhost';
$db_user = 'starkkga_lo';
$db_table = 'starkkga_lo';
$db_pass = 'lopyyy1234';
$connect = mysql_pconnect($db_host, $db_user, $db_pass) OR die('Нет подключения!');
mysql_select_db($db_table) OR die('Нет подключения!');
mysql_query("SET NAMES 'utf8'", $connect);


?>