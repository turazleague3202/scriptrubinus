<?



list($msec, $sec) = explode( chr(32), microtime() );

$udet=rand(111111,999999);
$online = mysql_num_rows( mysql_query('SELECT * FROM `users` WHERE `online` > \''.( time() - (3400) ).'\'') );


$_chat = mysql_query('SELECT COUNT(*) FROM `chat` WHERE `clan` = "0" AND `to` = "'.$user['id'].'" AND `read` = "0"');
$_chat = mysql_result($_chat,0);

$c_chat = mysql_query('SELECT COUNT(*) FROM `chat` WHERE `clan` = "'.$clan['id'].'" AND `to` = "'.$user['id'].'" AND `read` = "0"');
$c_chat = mysql_result($c_chat,0);

$mod_chat = mysql_query('SELECT COUNT(*) FROM `mod_chat` WHERE `clan` = "0" AND `to` = "'.$user['id'].'" AND `read` = "0"');
$mod_chat = mysql_result($mod_chat,0);

 $acy = mysql_query('SELECT * FROM `agame` WHERE `id` = "1"');
  $acy = mysql_fetch_array($acy);

if($user)
{
 
?>

            <div class="line2"></div>
        <div class="content">
        <div class="menu">                                                <li><a href="/user"><img src="/images/icons/back.png" width="16" height="16" alt=""> В камеру</a></li>

<?
$member = mysql_query('SELECT * FROM `undying_member` WHERE `user` = "'.$user['id'].'" ORDER BY `id` DESC LIMIT 1');
  $member = mysql_fetch_array($member);
  
  $battle = mysql_query('SELECT * FROM `undying` WHERE `id` = "'.$member['battle'].'"');
  $battle = mysql_fetch_array($battle); 
if($member['exit'] == 0 && $battle['start'] == 1 && $battle['end'] == 0) {

echo '<div class="menu">    <li><a href="/bunt/?<?=$udet?>"><img src="/images/icons/starvation.jpg" width="16" height="16" alt=""> Бунт
<font color="#30c030">(+)</font>
</a></li></div><div class="dotted"></div>';

}
?>
<?php

  if($clan) echo '<li><a  href=\'/clan/?'.$udet.'\' class="menu_link"><img src=\'/images/icons/clan.png\' alt=\'*\'/> '.$clan['name'].' '.($c_chat > 0 ? '<font color=\'#30c030\'>(+)</font>':'').'</a></li>';
  
?>
<li><a href="/menu?<?=$udet?>"><img src="/images/icons/back.png" width="16" height="16" alt=""> На главную</a></li>
<? if($user['access'] >= 1){
?>
<li><a href="/modchat?<?=$udet?>"><img src="/images/icons/back.png" width="16" height="16" alt=""> Чат mod [<?=n_f(mysql_result(mysql_query('SELECT COUNT(*) FROM `mod_chat`'),0))?>]<?=($mod_chat > 0 ? '<font color=\'#30c030\'>(+)</font>':'')?></a></li>
<?}?>
</div>        </div>

       <div class="line2"></div>
        
<div class="footer">
    <div class="block small">
                        
    <img src="/images/icons/level.png" width="16" height="16" alt="">  <?=$user['level']?> ур.            <img src="/images/icons/experience.png" width="16" height="16" alt=""> <?=$user['exepy']?>               (<?=$exp_progress?>%)
                    <img src="/images/icons/silver.png" width="16" height="16" alt="">  <?=$user['s']?>            <img src="/images/icons/gold.png" width="16" height="16" alt="">  <?=$user['g']?>            <img src="/images/icons/donate.png" width="16" height="16" alt="">  <?=$user['d']?>      
<?
      if($user['top_c'] == 2){echo '<img src="/images/icons/candy.png" width="16" height="16" alt="">  '.$user['c'].'';
}
?>          </div>
</div>     


<div class="block center color2">
<? if($acy['sh'] >= 1){
?>
  <a class="green" href="/outfit?nocache=642780481">Акция на шмот!</a>
<?}?>

        <div>
            <a href="/chat?<?=$udet?>">Чат [<?=n_f(mysql_result(mysql_query('SELECT COUNT(*) FROM `chat` WHERE `clan` = "0"'),0))?>]<?=($_chat > 0 ? '<font color=\'#30c030\'>(+)</font>':'')?></a> |
            <a href="/forum?<?=$udet?>">Форум</a>         </div>
        <div class="m3"></div>
        <a href="/agreement?<?=$udet?>">Соглашение</a> |
            <a href="/online?<?=$udet?>">Онлайн</a>            <span class="bold white">(<?=n_f($online)?>)</span>

            <div class="m3">
            <a href="/ticket?<?=$udet?>">Тех. поддержка</a>   
 [<a href="/ref/">Реф-система</a>]   
</div>
<a class="color-quality9" href="/nar/1?nocache=284171925">Магазин эксклюзивных шмоток</a>       
     <div class="small">
    Т. Беспредел: ВП |  <?=date('H:i:s')?> 
    <br/>
        <?=round((($sec+$msec)-$gtime),3)?> сек.
    <br/>

    18 +
 <br/>
 <h3>
 <a href="http://vk.com/club147925439">Мы вк</a>    
 </h3>
    </div>



<?php

if($user['access'] > 0) echo '<br/><a href=\'/ticket/?mode=viev_all\'>Тех поддержка ['.n_f(mysql_result(mysql_query('SELECT COUNT(*) FROM `ticket`'),0)).'] (Админка)</a> <br/>
';


  if($user['access'] > 0) echo '<br/><a href=\'/adm/?'.$udet.'\'>Панель управления</a>';

?>
</div></div>


<?php

}
else
{

?>

        <div class="block center color2">
        <a href="/common?<?=$udet?>">Соглашение</a> |
            Онлайн
            <span class="bold white">(<?=n_f($online)?>)</span>

     <div class="small">
    Т. Беспредел: ВП |  <?=date('H:i:s')?>   <br/>
        <?=round((($sec+$msec)-$gtime),3)?> сек.
    <br/>
    18 +
   

<br/>
 <h3>
 <a href="http://vk.com/club147925439">Мы вк</a>    
 </h3>

 </div>

<script type="text/javascript" src="http://mobtop.ru/c/116946.js"></script><noscript><a href="http://mobtop.ru/in/116946"><img src="http://mobtop.ru/116946.gif" alt="MobTop.Ru - Рейтинг и статистика мобильных сайтов"/></a></noscript>
<a href="http://statok.net/go/15917"><img src="http://statok.net/image/15917" alt="Statok.net" /></a>
<?php

}

?>
<div align='center'>

  
</body></html>



<script type="text/javascript">
        var secS = 'с';
        var secM = 'сек';
        var minS = 'м';
        var minM = 'мин';
        var hourS = 'ч';
        var hourM = 'час';
        var dayS = 'д';
        var dayM = 'дн';
        var detailOut = false;
        var readyLink = '0'+(detailOut?secS:' ' + secM);    </script><script src="/js/t.js" type="text/javascript"></script>


<script type="text/javascript" src="http://mobtop.ru/c/116947.js"></script><noscript><a href="http://mobtop.ru/in/116947"><img src="http://mobtop.ru/116947.gif" alt="MobTop.Ru - Рейтинг и статистика мобильных сайтов"/></a></noscript>
<a href="http://statok.net/go/15917"><img src="http://statok.net/imageOther/15917" alt="Statok.net" /></a>

<?php

ob_end_flush();

?>
