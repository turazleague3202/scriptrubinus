<?

      $id = _string(_num($_COOKIE['id']));
$password = _string($_COOKIE['password']);

if($id && $password) {
    
       $q = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$id.'" AND `password` = "'.$password.'"');
    $user = mysql_fetch_array($q);

  if(!$user) {
    
      setCookie('id', '');

setCookie('password', '');
  
  }

      mysql_query('UPDATE `users` SET `online` = "'.time().'",
                                          `ip` = "'.$_SERVER['REMOTE_ADDR'].'",
                                          `ua` = "'.$_SERVER['HTTP_USER_AGENT'].'",
                                        `self` = "'.$_SERVER['PHP_SELF'].'" WHERE `id` = "'.$user['id'].'"');



if($user['last_update'] - $user['timon'] > 1) {

mysql_query('UPDATE `users` SET `timon` = "'.($user['timon'] + 1).'" WHERE `id` ="'.$user['id'].'"');
}

 


      $_time = 40;

       if($user['last_update'] < (time() - $_time)){

        mysql_query('UPDATE `users` SET `last_update` = "'.time().'" WHERE `id` = "'.$user['id'].'"');

      }



      if((time() - $user['last_update']) > $_time) {

        mysql_query('UPDATE `users` SET `last_update` = "'.time().'" WHERE `id` = "'.$user['id'].'"');



        if($user['self'] != '/coliseum.php') {

          $hp = $user['vit'];
          
          if($user['hp'] < $hp) {
              $_hp = (((time() - $user['last_update']) / $_time) - 1 );
           if($_hp > $hp) {
              
$_hp = $hp - $user['hp'];

              }


$_hpy= round(100 / ($user['vit']/ $user['hp']));

            mysql_query('UPDATE `users` SET `hp` = "'.($user['hp'] + $_hp*60).'"  WHERE `id` = "'.$user['id'].'"');
          
          }    
        

          if($user['mp'] < $user['mana']) {

              $_mp = (((time() - $user['last_update']) / $_time) - 1 );
           if($_mp > $user['mana']) {
              $_mp = $user['mana'] - $user['mp'];
              }
            mysql_query('UPDATE `users` SET `mp` = "'.($user['mp'] +$_mp*150 ).'" WHERE `id` = "'.$user['id'].'"');
          

          }
      
        }    
    
      }


    if($user['last_update'] - $user['duel_last_update'] > (60 * 30)) {

        mysql_query('UPDATE `users` SET `duel_last_update` = "'.($user['duel_last_update'] + (60 * 30)).'",
                                             `duel_fights` = "'.($user['duel_fights']  + (($user['duel_fights'] < 11) ? 1:0)).'",
                                            `duel_changes` = "'.($user['duel_changes'] + (($user['duel_changes'] < 11) ? 1:0)).'" WHERE `id` = "'.$user['id'].'"');

    }

  if($user['hp'] > $user['vit'] ) {
    mysql_query('UPDATE `users` SET `hp` = "'.($user['vit']).'" WHERE `id` = "'.$user['id'].'"');
  }
  
  if($user['hp'] < 0) {
    mysql_query('UPDATE `users` SET `hp` = "0" WHERE `id` = "'.$user['id'].'"');
  }

  if($user['mp'] > $user['mana']) {
    mysql_query('UPDATE `users` SET `mp` = "'.$user['mana'].'" WHERE `id` = "'.$user['id'].'"');
  }

  if($user['mp'] < 0) {
    mysql_query('UPDATE `users` SET `mp` = "0" WHERE `id` = "'.$user['id'].'"');
  }
 if($user['d'] > 10000000) {
    mysql_query('UPDATE `users` SET `d` = "0" WHERE `id` = "'.$user['id'].'"');
  }
 if($user['g'] > 5000000) {
    mysql_query('UPDATE `users` SET `g` = "0" WHERE `id` = "'.$user['id'].'"');
  }




$clan_memb = mysql_query('SELECT * FROM `clan_memb` WHERE `user` = "'.$user['id'].'"');
  $clan_memb = mysql_fetch_array($clan_memb);

 
    if($clan_memb) {

       $clan = mysql_fetch_array(mysql_query('SELECT * FROM `clans` WHERE `id` = "'.$clan_memb['clan'].'"'));

    if($clan_memb['last_update'] <= time()) {
        
      mysql_query('UPDATE `clan_memb` SET `last_update` = "'.($clan_memb['last_update'] + ((60 * 60) * 24 )).'",
                                                    `v` = `v` + 3 WHERE `id` = "'.$clan_memb['id'].'"');

    }
   
    $clan_1 = ($clan['built_1'] * 250);


    if($clan['built_1'] > 0 && $clan_1) {
 
      $user['vit'] += $clan_1*6;

      $user['hp'] += $clan_1*6;

    }

 $clan_2 = ($clan['built_2'] * 250);


    
 if($clan['built_2'] > 0 && $clan_2) {
    
 
       $user['str'] += $clan_2*6;
    }

 $clan_3 = ($clan['built_3'] * 250);



 if($clan['built_3'] > 0 && $clan_3) {
  
      $user['def'] += $clan_3*6;
 
    }

  

}










    $ban = mysql_fetch_array(mysql_query('SELECT * FROM `ban` WHERE `user` = "'.$user['id'].'"'));
if($ban) {
  if($ban['time'] <=time()) {
      mysql_query('DELETE FROM `ban` WHERE `user` = "'.$user['id'].'"');
  }
  if($ban['time'] > time() && $_SERVER['PHP_SELF'] != '/ban.php') {
    header('location: /ban.php?'.$udet=rand(111111,999999).'');
    exit;
  }
}

# banned chat / forum
    $banned = mysql_fetch_array(mysql_query('SELECT * FROM `banned` WHERE `user` = "'.$user['id'].'"'));
  if($banned['time'] <=time()) {
      mysql_query('DELETE FROM `banned` WHERE `user` = "'.$user['id'].'"');
  }






if($user['time_d'] < time()){
mysql_query('UPDATE `users` SET `time_d` = "0", `bg_d` = "1" WHERE `id` = "'.$user['id'].'"');

if($user['lvl_d'] == 20){
mysql_query('UPDATE `users` SET `lvl_d` = "0" WHERE `id` = "'.$user['id'].'"');
}
}



 $ar = mysql_fetch_array(mysql_query('SELECT * FROM `arena_xod` WHERE `user` = "'.$user['id'].'"'));
  
if($user['arena_xod'] == 1) {
mysql_query('INSERT INTO `arena_xod` SET `user` = "'.$user['id'].'",`time` = "'.(time() + (3600)).'"');
}
if($ar) {
    if($ar['time'] < time()) {

if($user['vip']==0){ $xod=100;}else{$xod=200; }
mysql_query('UPDATE `users` SET `arena_xod` = "'.$xod.'" WHERE `id` = "'.$user['id'].'"');
mysql_query('DELETE FROM `arena_xod` WHERE `user` = \''.$user['id'].'\'');
}}

  $premium = mysql_fetch_array(mysql_query('SELECT * FROM `premium` WHERE `user` = "'.$user['id'].'"'));
  
  if($premium) {
  
    if($premium['time'] < time()) {
    

 $vip_1 = 30000;

 $vip_2 = 30000;

 $vip_3 = 30000;


          mysql_query('UPDATE `users` SET `str` = `str` - '.$vip_1.',
                                      `vit` = `vit` - '.$vip_2.',
                                    
                                      `def` = `def` - '.$vip_3.', `vip` =  "0" WHERE `id` = \''.$user['id'].'\'');

      mysql_query('DELETE FROM `premium` WHERE `user` = \''.$user['id'].'\'');
  
    }
  
  }

 $limt = mysql_fetch_array(mysql_query('SELECT * FROM `users` WHERE `id` = "'.$user['id'].'"'));
  
if($limt) {
    if($user['gold_clan_time'] < time()) {
if($user['save'] == 1) {
          mysql_query('UPDATE `users` SET `gold_clan`= "1000" WHERE `id` = \''.$user['id'].'\'');

if($user['gold_clan']==0){ mysql_query('UPDATE `users` SET `gold_clan_time` =  "'.(time() +(23*3600)).'" WHERE `id` = \''.$user['id'].'\'');
}
}
if($user['save'] == 0) {
mysql_query('UPDATE `users` SET `gold_clan_time` =  "'.(time() +(48*3600)).'",`gold_clan`= "100" WHERE `id` = \''.$user['id'].'\'');
}}}

$limit = mysql_fetch_array(mysql_query('SELECT * FROM `users` WHERE `id` = "'.$user['id'].'"'));
  
if($limit) {
    if($user['times_limit'] < time()) {
if($user['save'] == 1) {
if($user['s_limit'] == 0) {
          mysql_query('UPDATE `users` SET `s_limit`= "300000" WHERE `id` = \''.$user['id'].'\'');
if($user['s_limit']==0){ mysql_query('UPDATE `users` SET `times_limit` =  "'.(time() +(23*3600)).'" WHERE `id` = \''.$user['id'].'\'');}}}
if($user['save'] == 0) {
mysql_query('UPDATE `users` SET `times_limit` =  "'.(time() +(23*3600)).'"`s_limit`= "100000" WHERE `id` = \''.$user['id'].'\'');
}}}

if($user['level'] >= 10 && $user['level'] <= 29) {
$lvlh=1;
}
if($user['level'] >= 30 && $user['level'] <= 49) {
$lvlh=2;
}
if($user['level'] >= 50 && $user['level'] <= 69) {
$lvlh=3;
}
if($user['level'] >= 70 && $user['level'] <= 79) {
$lvlh=4;
}
if($user['level'] >= 80 && $user['level'] <= 99) {
$lvlh=5;
}
if($user['level'] >= 100 && $user['level'] <= 129) {
$lvlh=6;
}
if($user['level'] >= 130 && $user['level'] <= 150) {
$lvlh=7;
}

 $member = mysql_query('SELECT * FROM `undying_member` WHERE `user` = "'.$user['id'].'" ORDER BY `id` DESC LIMIT 1');
  $member = mysql_fetch_array($member);
  

$battle = mysql_query('SELECT * FROM `undying` WHERE `start` = "0" AND `lvl` = "'.$lvlh.'"');
  $battle = mysql_fetch_array($battle);  


if(!$battle) {
  
  $h = date('H',time());
    
  if($h > 22 && $h < 6)
  {
  
    $time = 3600;
  
  }
  else
  {

    $time = 3600;
  
  }

if($user['level'] >= 10 && $user['level'] <= 29) {
$lvlx=1;
mysql_query('INSERT INTO `undyingg` (`time`,`lvl`) VALUES ("'.(time() + $time).'","1")');
}
if($user['level'] >= 30 && $user['level'] <= 49) {
$lvlx=2;
mysql_query('INSERT INTO `undyingg` (`time`,`lvl`) VALUES ("'.(time() + $time).'","2")');
}
if($user['level'] >= 50 && $user['level'] <= 69) {
$lvlx=3;
mysql_query('INSERT INTO `undyingg` (`time`,`lvl`) VALUES ("'.(time() + $time).'","3")');
}
if($user['level'] >= 70 && $user['level'] <= 79) {
$lvlx=4;
mysql_query('INSERT INTO `undyingg` (`time`,`lvl`) VALUES ("'.(time() + $time).'","4")');
}
if($user['level'] >= 80 && $user['level'] <= 99) {
$lvlx=5;
mysql_query('INSERT INTO `undyingg` (`time`,`lvl`) VALUES ("'.(time() + $time).'","5")');
}
if($user['level'] >= 100 && $user['level'] <= 129) {
$lvlx=6;
mysql_query('INSERT INTO `undyingg` (`time`,`lvl`) VALUES ("'.(time() + $time).'","6")');
}
if($user['level'] >= 130 && $user['level'] <= 149) {
$lvlx=7;
mysql_query('INSERT INTO `undyingg` (`time`,`lvl`) VALUES ("'.(time() + $time).'","7")');
}
  
  }
  if($battle['time'] <= time()) {
    mysql_query('UPDATE `undying` SET `start` = "1", `time` = "'.(time() + (240)).'" WHERE `id` = "'.$battle['id'].'" AND `lvl` ="'.$lvlx.'"');
}


$battl = mysql_query('SELECT * FROM `podval` WHERE `start` = "0" AND `clan` = "'.$clan['id'].'"');
  $battl = mysql_fetch_array($battl);  

  if(!$battl) {
  
  $h = date('H',time());
  if($h > 22 && $h < 6)
  {
    $timy = 3600;
  }
  else
  {
    $timy = 2400;
  }
    mysql_query('INSERT INTO `podval` (`time`,`clan`) VALUES ("'.(time() + $timy).'","'.$clan['id'].'")');
  }
if($battl['time'] <= time()) {
    
    mysql_query('UPDATE `podval` SET `start` = "1", `time` = "'.(time() + (220)).'" WHERE `id` = "'.$battle['id'].'" AND `clan` = "'.$clan['id'].'"');
}


if($user['access'] < 0 && $_SERVER['PHP_SELF'] != '/zak.php') {
  header('location: /zak.php');
exit;
}
}

?>