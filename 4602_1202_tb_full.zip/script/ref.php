<?
    
    include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';
    
if(!$user) {
header('location: /');    
exit;
}

$title = 'Реферальная система';
include './system/h.php';  
?>

  <div class="content"><div class="block center color3 s125">Реферальная система</div>
            <div class="line"></div>
<div class="block">
Ваша ссылка: 
<input type="text" class="form-control" value="http://bespredell.ru/start/ref=<?=$user['id']?>">
</div>
<span class="Admin">Если игрок зарегистрируется по вашей ссылке, вы получите <img src="/images/icons/gold.png"> 100</span>

<?
$count = mysql_result(mysql_query('SELECT COUNT(*) FROM `ref` WHERE `user` = "'.$user['id'].'"'),0);
?>

<div class="dotted"></div>
<div class="block center color3 s125">
<b>Приглашено друзей: [<?=$count?>]</b></div>
<div class="dotted"></div>
<?
$max = 10;
$pages = ceil($count/$max);
$page = _string(_num($_GET['page']));
if($page > $pages) {
$page = $pages;
}
if($page < 1) {
$page = 1;
}
$start = $page * $max - $max;

if($count > 0) {

$q = mysql_query('SELECT * FROM `ref` WHERE `user` = "'.$user['id'].'" ORDER BY `id` DESC LIMIT '.$start.', '.$max.'');
while($row = mysql_fetch_array($q)) {
$ho = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$row['ho'].'"');
$ho = mysql_fetch_array($ho); 

$color=$ho['color'];
?>

<div class="block">
<?
if($ho['vip'] == 0 && $ho['access'] == 0){
?>
<img src="/images/icons/<?=$ho['r']?>.png" width="16" height="16" alt="">
<?
}

if($ho['access'] == 1) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt="">
<?
}

if($ho['access'] == 2) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt="">
<?}
if($ho['access'] == 3) {
?>
<img src="/images/icons/adminy.png" width="16" height="16" alt="">
<?
}
if($ho['vip'] == 1 && $ho['access'] == 0){
?>
<img src="/images/icons/vip_<?=($ho['r'] == man ? 'woman':'man')?>_<?=$ho['r']?>.png" width="16" height="16" alt="">
<?
}
?>

 <a class="color3" href="/user/<?=$ho['id']?>/"><font style="text-shadow: 0px 5px 6px;" color=#<?=$color?>><?=$ho['login']?></font></a>,
            
    <img src="/images/icons/level.png" width="16" height="16" alt=""> <?=$ho['level']?> ур.                
</div>
     



<?
}
?>

  <div class="dotted"></div>
<ul class="pagination"><li class="next"><?=pages('?');?></li></ul>

<div class="dotted"></div>


<?
}else{
?>

<font color='#999'>Вы ещё никого не пригласили</font>

<?
}
?>

</div>
</div>
<?
include './system/f.php';
?>