<?
    
    include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';
    
if(!$user) {

  header('location: /');
  exit;

}

if($user['save'] == 0) {

  header('location: /save/'); 
  exit;

}

$title = 'Настройки';    

include './system/h.php';  


$login = _string($_POST['login']);

if($login) {
   
  if($user['g'] < 250) $errors[] = 'Ошибка, нехватает <img src=\'/images/icon/gold.png\' alt=\'*\'> '.(250 - $user['g']).' золота<div class=\'separator\'></div><a href=\'/trade/\' class=\'button\'>Купить</a>';  
  
  if(!preg_match('/[a-z0-9а-я †‡±™®©¶°«»§~”“„’‘‹›‚′″ßæðğĥĵķľœīĩöºþýŕèŵçźñĺł]{2,20}/i', $login)) $errors[] = 'Ошибка, имя персонажа введено не верно';
        
  if(mysql_result(mysql_query('SELECT COUNT(*) FROM `users` WHERE `login` = \''.$login.'\''),0) != 0) $errors[] = 'Ошибка, персонаж с такими именем уже зарегестрирован';
        
  if($errors) {

    echo '<div class=\'content\' align=\'center\'>';
          
    foreach($errors as $error) {
    
      echo $error.'<br/>';
            
    }
        
    echo '</div>
<div class=\'line\'></div>';

  }
  else
  {
  
$texy=" $user[login] сменил логин <img src=/images/icons/gold.png width=16 height=16 alt=> 250 ";
mysql_query('INSERT INTO `golds` SET `user` = "'.$user['id'].'",`time` = "'.time().'",`text` = "'.$texy.'",`loc`="1"');
 
    mysql_query('UPDATE `users` SET `login` = \''.$login.'\',
                                     `g` = `g` - 250 WHERE `id` = \''.$user['id'].'\'');
    header('location: /');
  
  }

}


    
$password = _string($_POST['password']);

if($password) {  
  
  if(!preg_match('/[a-z0-9]{2,20}/i', $password)) $errors[] = 'Ошибка, пароль введен неверно';
  
  if($errors) {

    echo '<div class=\'content\' align=\'center\'>';
          
    foreach($errors as $error) {
    
      echo $error.'<br/>';
            
    }
        
    echo '</div>
<div class=\'line\'></div>';

  }
  else
  {

    mysql_query('UPDATE `users` SET `password` = \''.md5($password).'\' WHERE `id` = \''.$user['id'].'\'');

    setCookie('password', $password, time() + 86400, '/');



    header('location: /');
    
  }
  
}
  


echo '    <div class="content"><div class="block center color3 s125">Настройки</div>
            <div class="line"></div><div class="menu">            <li><a href="/settings/login/"><img src="/images/icons/right_blue.png" width="16" height="16" alt=""> Изменить погоняло</a></li><li><a href="/settings/password/"><img src="/images/icons/right_blue.png" width="16" height="16" alt=""> Изменить пароль</a></li><li><a href="/settings/race/"><img src="/images/icons/right_blue.png" width="16" height="16" alt=""> Изменить пол</a></li>
';


if($_GET['action']) {
  
  echo '
<div class=\'content\'>';

  switch($_GET['action']) {
    case 'login':

    echo '<form action=\'/settings/login/\' method=\'post\'>
  Введите новое имя:<br/>
  <input name=\'login\'/><br/>
  <input type=\'submit\' value=\'Сменить\'/>
</form>';

    break;
    case 'password':
  
    echo '<form action=\'/settings/password/\' method=\'post\'>
  Введите новый пароль:<br/>
  <input name=\'password\'/><br/>
  <input type=\'submit\' value=\'Сменить\'/>
</form>';

    break;
    case 'race':

    if($_GET['change'] == true && $user['g'] >= 0) {  
  
      mysql_query('UPDATE `users` SET `r` = "'.($user['r'] == 0 ? 1:0).'", `g` = `g` - 0 WHERE `id` = "'.$user['id'].'"');

      header('location: ?');
  
    }

    echo 'Текущая пол: '.($user['r'] == 0 ? 'Мужчина':'Женщина').'<br/>
Желаете сменить пол на   '.($user['r'] == 0 ? 'Женщина':'Мужчина').'?<br/><br/>
<a href=\'/settings/race/?change=true\' class=\'button\'>Да, сменить</a>';

    break;
    

    echo '</div>';
    
  } 

  echo '</div>';

}

echo '<li><a href="/?exit"><img src="/images/icons/cross.png" width="16" height="16" alt=""> Выйти из игры</a></li></div></div>
           
';

  
include './system/f.php';

?>