<?
    
    include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';
    
if(!$user) {

  header('location: /');
    
exit;

}

$title = 'Похан ТБ';

include './system/h.php';

if(isset($_GET['buy'])) {
  
  if($premium) $errors[] = 'Ошибка, вы уже активировали';
  
  if($user['d'] < 1700) $errors[] = 'Ошибка, нехватает <img src=\'/images/icons/donate.png\' alt=\'\'/> '.(1700 - $user['d']).' ';
  
  if($errors) {
    
    foreach($errors as $error) {
      
echo '<div class="alert">';
          echo $error;
echo '</div><div class="alert_bottom"></div>';
    }
  }
  else
  {

    mysql_query('UPDATE `users` SET `d` = `d` - 1700 WHERE `id` = \''.$user['id'].'\'');
      
    mysql_query('INSERT INTO `premium` (`user`,
                                        `time`) VALUES ("'.$user['id'].'",
                                            "'.(time() + (3*86400)).'")');   



 $vip_1 = 30000;

 $vip_2 = 30000;

 $vip_3 = 30000;

      mysql_query('UPDATE `users` SET `str` = `str` + '.$vip_1.',
                                      `vit` = `vit` + '.$vip_2.',
                                    
                                      `def` = `def` + '.$vip_3.', `vip` = "1" WHERE `id` = \''.$user['id'].'\'');


    header('location: /vip/');
  
  }

}


$vip1 = 30000;

 $vip2 = 30000;

 $vip3 = 30000;
   echo '<div class="content"><div class="block center color3 s125">Пахан ТБ</div>
            <div class="line"></div><div class="block center">
    <img src="/images/title/vip.png" width="180" height="57" alt=""></div>
<div class="dotted"></div>
<div class="block center">
    <span class="blue">Пахан ТБ - это супер-улучшение! Игрок, которой арендует это улучшение, получает
        следующие бонусы:</span>
</div>
<div class="dotted"></div>
<div class="block">
    1. Авторитет X2<img src="/images/icons/experience.png" width="16" height="16" alt="">    <br/>
    2. Доход с <img src="/images/icons/job.jpg" width="16" height="16" alt="">    <a class="blue" href="/job">Работы</a>    X2 <img src="/images/icons/reward.png" width="16" height="16" alt="">    <br/>
    3. Возможность меньше уставать на <img src="/images/icons/arena.jpg" width="16" height="16" alt="">    <a class="blue" href="/arena">Разборках</a>.
        200 боёв <img src="/images/icons/swords.png" width="16" height="16" alt=""> в час, вместо 100 <img src="/images/icons/swords.png" width="16" height="16" alt="">!
    <br/>
    4. Иконка, выделяющая тебя среди других игроков!
    <img src="/images/icons/vip_man_1.png" width="16" height="16" alt="">    <img src="/images/icons/vip_woman_1.png" width="16" height="16" alt="">
             
    <br/>
   5. к параметрам <img src="/images/icons/currentHealth.png" width="16" height="16" alt=""> '.$vip1.'
 <img src="/images/icons/damage.png" width="16" height="16" alt="">  '.$vip2.'  <img src="/images/icons/armor.png" width="16" height="16" alt=""> '.$vip3.'
      </div>
<div class="dotted"></div>';


    echo '<div class="block center">
                <span class="btn_start"><span class="btn_end"><span class="btn">'; 

  $tyui = rand(333,999);
echo' '.($premium ? 'Осталось: '._times($premium['time'] - time()):'<a href=\'/vip/?buy='.$tyui.'\'>Арендовать на 3 дня за     <img src=\'/images/icons/donate.png\' width=\'16\' height=\'16\' alt=\'\'> 1700</a>').'
';

 echo '</span> </span>  </span>  </div>
</div>';


include './system/f.php';
     


?>