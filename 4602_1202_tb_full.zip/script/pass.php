<?
include './system/common.php';
include './system/functions.php';
include './system/user.php'; 
//-----Переадресация для авторизированых-----//
if($user['id']){header('Location: /');exit();}
$title = 'Восстановление Пароля';    
include './system/h.php';

//-----Если жмут submit(кнопку)-----//
if(isset($_REQUEST['submit'])){

	
if(mysql_result(mysql_query("SELECT COUNT(*)  FROM `users` WHERE `login` = ".$login.""),0) == true){
echo '<div class="god4 center light_bottom"><center><b><font color="red">Такого игрока нет в базе данных!</font></b></center></div>';
echo'<div class="god3 center light_bottom"><div class="menu_link"><a href="/pass.php">Вернуться назад</a></div></div>';
exit();
}

//-----Фильтрируем перемменые-----//
$login = _string($_POST['login']);
if(empty($login)){
echo '<div class="god4 center light_bottom"><center><b><font color="red">Вы не ввели ник игрока!</font></b></center></div>';
echo'<div class="god3 center light_bottom"><div class="menu_link"><a href="/pass.php">Вернуться назад</a></div></div>';
exit();
}

//-----Фильтрируем перемменые-----//
$email = _string($_POST['email']);
if(empty($email)){
echo '<div class="god4 center light_bottom"><center><b><font color="red">Вы не ввели свой email почту!</font></b></center></div>';
echo'<div class="god3 center light_bottom"><div class="menu_link"><a href="/pass.php">Вернуться назад</a></div></div>';
exit();
}
if(mysql_result(mysql_query("SELECT COUNT(*)  FROM `users` WHERE `email` = ".$email.""),0) == true){
echo '<div class="god4 center light_bottom"><center><b><font color="red">Вы не правильно ввели почту данного игрока!</font></b></center></div>';
echo'<div class="god3 center light_bottom"><div class="menu_link"><a href="/pass.php">Вернуться назад</a></div></div>';
exit();
}

$kutere = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `login` like '%".$login."%'"),0);
$kutere1 = mysql_result(mysql_query("SELECT COUNT(*) FROM `users` WHERE `email` like '%".$email."%'"),0);
if ($kutere==0 OR $kutere1==0){
echo '<div class="god4 center light_bottom"><center><b><font color="red">Не правильно ввели свои данные!</font></b></center></div>';
echo'<div class="god3 center light_bottom"><div class="menu_link"><a href="/pass.php">Вернуться назад</a></div></div>';
exit();
}

$rou = rand(1000000, 5000000);
mysql_query("UPDATE `users` SET `password` = '".md5($rou)."' WHERE `login` = '".$login."' LIMIT 1");
$title = 'Восстановление пароля';
$to = $email;
$from = 'info@bespredell.ru';
$text = 'Здравствуйте, '.$login.' 

Вы выполнили операцию восстановления пароля в игре http://'.$_SERVER['HTTP_HOST'].' 

Ваши Данные для входа : 
Логин: '.$login.'
Пароль: '.$rou.' 
P.S Если вы не выполняли данной операци то просто проигноируйте письмо!
-----------------------------------------------------------------------------------------------------------------------
Пароль сгенерировался автоматически после авторизации обязательно смените его! Удачи вам в сражениях!  С уважением Администрация игры';
mail($to, $title, $text, 'From:'.$from);

echo '<div class="block"><center><img src="/images/icon/ok.png"><font color="green">Спасибо! На указанный Email отправлено письмо с ссылкой для смены пароля.<br/><font color="red">Не забудьте взглянут в папку со спамом!</font></font></center></div>';       
}

?>    

<div class="content"><div class="block center color3 s125"><a href="/">Тюремный Беспредел</a>/ Восстановление пароля</div>
            <div class="line"></div><div class="block">

<form action="/pass/?" method="post">
    <div class="form-group field-saveavatar-name required">
<label class="control-label" for="saveavatar-name">Погоняло</label>
<input type="text" id="saveavatar-name" class="form-control" name="login">

<label class="control-label" for="saveavatar-name">Email</label>
<input type="text" id="saveavatar-name" class="form-control" name="email">
<div class="help-block"></div>
</div>    <div class="form-group field-saveavatar-sex required">

<div class="help-block"></div>
</div>    <span class="m3 btn_start middle"><span class="btn_end"><button type="submit" name="submit" class="btn">Сохранить</button></span></span>
</form>
 </div>
</div>
        
<?php include './system/f.php'; ?>
