<?
    
    include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';
    
if(!$user) {

  header('location: /menu');
    
exit;

}
if($user['bg_d'] ==0){
header('location: /menu');
exit;
}

$title =' Босяцкий подгон';
    include './system/h.php';

$se=200+($user['lvl_d'] *200);
$go=10+($user['lvl_d']*5);
$key=($user['lvl_d']*5);
$dot=($user['lvl_d']*2);


$h = date('H',time());
$hu=date('11');
  if($h == $hu)
  {
  
    $timye = 10;

mysql_query("INSERT INTO `chatt` SET `user`='346',`to`='0',`text`='В битве со мной активно лидирует новый герой ".$user['login']." | ТОП 3!',`time`='".time()."'");
  }


$time_d=21*3600;
if(isset($_GET['day'])){
if($user['bg_d'] >=1){

if($user['lvl_d'] == 9){
mysql_query('UPDATE `users` SET `d` = `d` +200 WHERE `id` = "'.$user['id'].'"');
}
if($user['lvl_d'] == 19){
mysql_query('UPDATE `users` SET `d` = `d` +400 WHERE `id` = "'.$user['id'].'"');
}
    
if($user['bg_d'] ==0){
if($user['lvl_d'] == 14){
  $w = mysql_fetch_array(mysql_query('SELECT * FROM `shop` WHERE `quality` = \'6\' ORDER BY RAND() LIMIT 1'));

  if(mysql_num_rows(mysql_query('SELECT * FROM `inv` WHERE `place` = \'0\' AND `user` = \''.$user['id'].'\'')) + 1 < 20) {

mysql_query('INSERT INTO `inv` (`user`,
                                    `item`,
                                  `quality`,
                                   `smith`,
                                    `_str`,
                                    `_vit`, 
                                    `_def`,
                                   `place`, 
                                    `str_`,
                                    `vit_`, 
                                    `def_`) VALUES (\''.$user['id'].'\',
                                                \''.$w['id'].'\',
                                           \''.$w['quality'].'\',
                                             \'2\',
                                              \''.$w['_str'].'\',
                                              \''.$w['_vit'].'\',
                                              \''.$w['_def'].'\',
                                                                  \'0\', 
                                              \''.$w['_str'].'\',
                                              \''.$w['_vit'].'\',
                                              \''.$w['_def'].'\')');

  $w_id = mysql_insert_id();

     $w = mysql_fetch_array(mysql_query('SELECT * FROM `inv` WHERE `id` = \''.$w_id.'\''));
  $item = mysql_fetch_array(mysql_query('SELECT * FROM `items` WHERE `id` = \''.$w['item'].'\''));
  

  $_SESSION['not'] = '<div class="alert"><div><font color="#f0c060">Новая вещь в </font> <img src="/images/icons/bag.png" alt=""/> <a href="/inv/bag/"><u>Тумбочке</u></a></div>';
header('location: ?');
exit;
  }

}
}

mysql_query('UPDATE `users` SET `g` = `g` + '.$go.',`s` = `s` + '.$se.', `vor` = `vor` + '.$key.',`d` = `d` + '.$dot.',`time_d` = "'.(time()+$time_d).'", `bg_d` = "0", `lvl_d` = `lvl_d` +1 WHERE `id` = "'.$user['id'].'"');
$_SESSION['not'] = '<div class="dotted"></div>
<div class="alert"><div>                                                 <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Прибыль:</div>
    <img src="/images/icons/silver.png" width="16" height="16" alt=""> Рубли:+'.$se.',    <img src="/images/icons/gold.png" width="16" height="16" alt=""> Сахар:+'.$go.' <img src="/images/icons/key.png" width="16" height="16" alt=""> Ключи:+'.$key.' <img src="/images/icons/donate.png" width="16" height="16" alt=""> Сгущёнка:+'.$dot.'</div></div><div class="alert_bottom"></div>';
header('location: ?');
exit;
}
}
 
?>
    <div class="content"><div class="block center color3 s125">Босяцкий подгон</div>
            <div class="line"></div><div class="center">
    <div class="block">
        <img src="/images/title/daily.jpg" width="150" height="75" alt="">    </div>
    <div class="dotted"></div>
    <div class="block">
        <div class="blue">Твой подогрев:</div>
            <img src="/images/icons/silver.png" width="16" height="16" alt=""> <?=$se?>    <img src="/images/icons/gold.png" width="16" height="16" alt=""> <?=$go?>  <img src="/images/icons/key.png" width="16" height="16" alt=""> Ключи:+<?=$key?> <img src="/images/icons/donate.png" width="16" height="16" alt=""> Сгущёнка:+<?=$dot?>  </div>
    <div class="dotted"></div>
            <div class="block color3">
            Этот подогрев будет доступен через <span id='time_<?=$user['time_d'] - time()?>000'><?=_time($user['time_d'] - time())?>  </span>
  


 <div class="m3">
                <span class="btn_start"><span class="btn_end"><a class="btn" href="/menu/?<?=$udet?>">На главную</a></span> </span>            </div>
        </div>
    </div>
<div class="line"></div>
<div class="block">
    <img src="/images/icons/topic.png" width="16" height="16" alt="">    Таблица подогревов:
</div>
<div class="dotted"></div>
<div class="block">

            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        
<b class="color2">День 1</b>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 200    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 10        </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>1) { echo '<b class="color2">День 2</b>';} ?><? if($user['lvl_d']<2) { echo '<b class="blue">День 2</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 400    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 15        </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>2) { echo '<b class="color2">День 3</b>';} ?><? if($user['lvl_d']<3) { echo '<b class="blue">День 3</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 600    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 20        </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                         <? if($user['lvl_d']>3) { echo '<b class="color2">День 4</b>';} ?><? if($user['lvl_d']<4) { echo '<b class="blue">День 4</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 800    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 25        </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>4) { echo '<b class="color2">День 5</b>';} ?><? if($user['lvl_d']<5) { echo '<b class="blue">День 5</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 1000    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 30        </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>5) { echo '<b class="color2">День 6</b>';} ?><? if($user['lvl_d']<6) { echo '<b class="blue">День 6</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 1200    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 35        </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>6) { echo '<b class="color2">День 7</b>';} ?><? if($user['lvl_d']<7) { echo '<b class="blue">День 7</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 1400    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 40        </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>7) { echo '<b class="color2">День 8</b>';} ?><? if($user['lvl_d']<8) { echo '<b class="blue">День 8</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 1600    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 45        </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>8) { echo '<b class="color2">День 9</b>';} ?><? if($user['lvl_d']<9) { echo '<b class="blue">День 9</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 1800    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 50        </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>9) { echo '<b class="color2">День 10</b>';} ?><? if($user['lvl_d']<10) { echo '<b class="blue">День 10</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 2000    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 55  <img src="/images/icons/donate.png" width="16" height="16" alt=""> 200   </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>10) { echo '<b class="color2">День 11</b>';} ?><? if($user['lvl_d']<11) { echo '<b class="blue">День 11</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 2200    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 60        </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>11) { echo '<b class="color2">День 12</b>';} ?><? if($user['lvl_d']<12) { echo '<b class="blue">День 12</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 2400    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 65        </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>12) { echo '<b class="color2">День 13</b>';} ?><? if($user['lvl_d']<13) { echo '<b class="blue">День 13</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 2600    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 70        </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>13) { echo '<b class="color2">День 14</b>';} ?><? if($user['lvl_d']<14) { echo '<b class="blue">День 14</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 2800    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 75        </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>14) { echo '<b class="color2">День 15</b>';} ?><? if($user['lvl_d']<15) { echo '<b class="blue">День 15</b>';} ?>:
               <img src="/images/icons/silver.png" width="16" height="16" alt=""> 3000    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 80     <img src="/images/icons/equip.png" width="16" height="16" alt=""> легендарный шмот </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>15) { echo '<b class="color2">День 16</b>';} ?><? if($user['lvl_d']<16) { echo '<b class="blue">День 16</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 3200    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 85        </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>16) { echo '<b class="color2">День 17</b>';} ?><? if($user['lvl_d']<17) { echo '<b class="blue">День 17</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 3400    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 90        </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>17) { echo '<b class="color2">День 18</b>';} ?><? if($user['lvl_d']<18) { echo '<b class="blue">День 18</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 3600    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 95        </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>18) { echo '<b class="color2">День 19</b>';} ?><? if($user['lvl_d']<19) { echo '<b class="blue">День 19</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 3800    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 100       </div>
            <div>
            <img src="/images/icons/right_blue.png" width="16" height="16" alt="">                        <? if($user['lvl_d']>19) { echo '<b class="color2">День 20</b>';} ?><? if($user['lvl_d']<20) { echo '<b class="blue">День 20</b>';} ?>:
                <img src="/images/icons/silver.png" width="16" height="16" alt=""> 4000    <img src="/images/icons/gold.png" width="16" height="16" alt=""> 105  <img src="/images/icons/donate.png" width="16" height="16" alt=""> 400     </div>
    </div>
<div class="dotted"></div>
<ul class="block small">
    <li class="">Для того, чтобы получать лучший подогрев, необходимо в течении определенного кол-ва дней посещать
        игру без пропусков, в случае хотя-бы одного пропуска, исчесление бонусов начинается с 1-го дня</li>
</ul>
</div>
<?
include './system/f.php';
?>