<?

  include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';
    
if(!$user) {

  header('location: /');
  exit;

}
  $title = "Тех поддержка";

include './system/h.php';
?>
                       
    <div class="content"><div class="block center color3 s125">Техническая поддержка</div>


<?

switch ($_GET['mode'])
{
  default;
IF(isset($_get['COPY']))
{

}
if($_GET['create']=="true")
{
	

	$_title=_string($_POST['title']);


	$_ob=_string($_POST['ob']);

	$_sms=_string($_POST['sms']);



	if(empty($_title))$err="Пустой заголовок!";

	if(empty($_sms))$err="Пустой текст обращения!";

	if(mb_strlen($_title)<3 OR mb_strlen($_title)>25)$err="Длина заголовка от 5 до 25 символов";

	if(mb_strlen($_sms)<3 OR mb_strlen($_sms)>8048)$err="Длина сообщения от 50 до 8048 символов";

	if($err)
	{

		?>
		<div class="block"><font color="red"><?=$err;?></font>
</div>
		<?

	}elseif(!$err){


			mysql_query("INSERT INTO `ticket` SET `user`='".$user['id']."',`ob`='$_ob',`text`='$_sms',`title`='$_title',`status`='new'")OR DIE(mysql_error());



mysql_query('UPDATE `ticket` SET `time` = \''.time().'\',`login` = \''.$user['login'].'\' WHERE `user` = \''.$user['id'].'\'');


			?>
		<div class="block"><font color="green">Заявка успешно отправлена! Администратор ответит в близжайшее время.</font>
</div>

		<?

		



	}

	



}

?>



<div class="line"></div><form  class="block" action="?create=true" method="post">

<label class="control-label" for="ticketcreateform-name">Тема</label>
<input type="text" id="ticketcreateform-name" class="form-control" name="title">

<div class="help-block"></div>
<label class="control-label" for="ticketcreateform-type_id">Причина обращения</label>
<select name="ob">
<option value="1">Другое</option>
<option value="2">Восстановление аккаунта</option>
<option value="3">Ошибка/ баг</option>
<option value="4">Вопросы по игре</option>
<option value="5">Вопросы по оплате</option>
</select>

<div class="help-block"></div>
<div class="form-group field-ticketmessagecreateform-text required">
<label class="control-label" for="ticketmessagecreateform-text">Комментарий</label>
<textarea id="ticketmessagecreateform-text" class="form-control" name="sms" rows="5"></textarea>

<div class="help-block"></div>
</div><span class="m3 btn_start middle"><span class="btn_end">
    <button type="submit" class="btn">Отправить</button></span>
</span>
</form>


<div class="dotted"></div>
<?

$my_requests=mysql_query("SELECT * FROM `ticket` WHERE `user`='".$user['id']."'");

if(mysql_num_rows($my_requests)==0)
{

?>

    <div class="block">У вас пока нет ни одного обращения</div>
<?

}elseif(mysql_num_rows($my_requests)>0)
{

	while ($req=mysql_fetch_array($my_requests))
	{
		
		switch ($req[status])
		{
			case 'new';

			$status="<font color='yellow'>Ожидание</font>";

			break;

			case 'read';

			$status="<font color='green'>Есть ответ</font>";

			break;

			case 'close';

			$status="<font color='red'>Закрыт</font>";

			break;

			case 'user';

			$status="<font color='red'>Ответил пользователь</font>";

			break;

		}

		?>	

 <div class="menu">        <li><a href="?mode=viev&id=<?=$req['id'];?>"><img src="/images/icons/.jpg" width="16" height="16" alt=""> <?=$req['title'];?>(<?=$status;?>)N%<?=$req['id'];?></a></li></div>   
  
<div class="dotted"></div>
		<?
	}



}


break;

case 'viev';

$id=trim(htmlspecialchars($_GET['id']));

	$tik=mysql_fetch_array(mysql_query("SELECT * FROM `ticket` WHERE `id`='$id'  and `user`='".mysql_real_escape_string($user['id'])."'"));

	if($tik){
		
				switch ($tik[status])
		{
			case 'new';

			$status="<font color='yellow'>Ожидание</font>";

			break;

			case 'read';

			$status="<font color='green'>Есть ответ</font>";

			break;

			case 'close';

			$status="<font color='red'>Закрыт</font>";

			break;

			case 'user';

			$status="<font color='red'>Ответил пользователь</font>";

			break;
		}


if($_GET['close']=="true" && $tik['status']!="close")
{


mysql_query("UPDATE `ticket` SET `status`='close' WHERE `id`='".mysql_real_escape_string($tik['id'])."'");


?>

<div class="block"><div class="content">
						<span>обращение закрыто</span>
						</div>
</div>
<?

}

?>
<?
   
		
		if($_GET['answer']=="true")
		{

				$sms=_string($_POST['sms']);
	
				if(mb_strlen($sms)<2 OR mb_strlen($sms)>2048)$err="Длина сообщения от 5 до 2048 символов";

				if($tik['status']=="close")$err="Тикет закрыт.";

				if($tik['status']=="user")$err="Антифлуд.";

				if($err)
				{

					?>

						<div class="block"><div class="content">
						<span><?=$err;?></span>
						</div>
</div>
					
						<?
				}elseif(!$err)
				{


					mysql_query("INSERT INTO `ticket_bt` SET `text`='".mysql_real_escape_string($sms)."',`type`='user',`ticket`='".mysql_real_escape_string($tik['id'])."',`ot`='".mysql_real_escape_string($user['id'])."',`time`='".time()."'");

					mysql_query("UPDATE `ticket` SET `status`='user' WHERE `id`='".mysql_real_escape_string($tik['id'])."'");

					?>				
	
						<div class="block"><div class="content">
						<span color="green">Сообщение добавлено!</span>
						</div>
</div>

					<?



				}



		}
	




    function cst($i) {
        
        switch($i) {

  case 1:
    $cst = 'другое';
     break;
    case 2:
    $cst = 'Восстановления аккаунта';
     break;
    case 3:
    $cst = 'Ошибки / баги';
     break;
    case 4:
    $cst = 'Вопросы по игре';
     break;
    case 5:
    $cst = 'Вопросы по оплате';
     break;
        }
        
    return $cst;
    
    }


$ak=mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$tik['user']."'"));

		?>

                          
    <div class="content"><div class="block center color3 s125"></div>
            <div class="line"></div> 
                            <img src="/images/icons/1.png" width="16" height="16" alt=""> <a class="color3" href="/user/<?=$ak['user']?>"><?=$ak['login']?></a><span class="small green"> * </span><span class="color2 small">
                            , <?=(date('d ', $tik['time']) . $monthes[(date('n', $tik['time']))] . date(' H:i', $tik['time']));?>
</span>
                                    
                        <div> <?echo "".nl2br($tik['text'])."";?></div>
                    </div>
        <div class="dotted"></div>
			<div class="line"></div>
			<?

	if($tik['status']=="user" OR $tik['status']=="close"){
				?>
			<div class="block"><font color='#999'>Антифлуд, дождитесь ответа адмнистратора чтоб отправить повторно сообщение. Или же Ваше обращение закрыто.</font>
</div>
				<?
}else{
	?>


<div class="dotted"></div>
<form class="block" action="?mode=viev&id=<?=$tik['id'];?>&answer=true" method="post">
<div class="form-group field-ticketmessagecreateform-text required">
<label class="control-label" for="ticketmessagecreateform-text">Комментарий</label>
<textarea id="ticketmessagecreateform-text" class="form-control" name="sms" rows="5"></textarea>

<div class="help-block"></div>
</div>    <span class="m3 btn_start middle"><span class="btn_end">
    <button type="submit" class="btn">Отправить</button></span>
</span>
</form>
</div>



<?
}
?>

		
		<?

	$answer=mysql_query("SELECT  * FROM `ticket_bt` WHERE `ticket`='".$tik['id']."' ORDER BY `id` DESC");

	if(mysql_num_rows($answer)==0){

		?>

<div class="dotted"></div>
	<div class="block">	<div class="content">
		<font color='#999'>Сообщений не найдено.</font>
		</div>
	
<div class="dotted"></div>
		<?
	
	}elseif(mysql_num_rows($answer)>0)
	{

			while ($feed=mysql_fetch_array($answer))
			{
			  
$a=mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$feed['ot']."'"));

				if($feed['type']=="admin")
				{



					?>
  
    <div class="dotted"></div>
            <div class="block">
<?
if($a['vip'] == 0 && $a['access'] == 0){
?>
<img src="/images/icons/<?=$a['r']?>.png" width="16" height="16" alt="">
<?
}
if($a['access'] == 1) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt="">
<?}
if($a['access'] == 2) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt="">
<?}
if($a['access'] == 3) {
?>
<img src="/images/icons/adminy.png" width="16" height="16" alt="">
<?
}
if($a['vip'] == 1 && $a['access'] == 0){
?>
<img src="/images/icons/vip_<?=($a['r'] == man ? 'woman':'man')?>_<?=$a['r']?>.png" width="16" height="16" alt="">
<?
}
?>
 <a class="color3" href="/user/<?=$a['id']?>/"><?=$a['login']?></a> 

<?
  if($a['access'] == 1) {
?>
<font color='f09060'>
<?
  }
  if($a['access'] == 2) {
?>
<font color='008080'>
<?
  }
  if($a['access'] == 3) {
?>
<font color='90c0c0'>
<?}
?>

<?=$feed['text']?>

</font>
     <div class="small"><span class="color2">
<?=(date('d ', $feed['time']) . $monthes[(date('n', $feed['time']))] . date(' H:i', $feed['time']));?>
  </span>
</div>   
</div>
  
					<?

				}elseif($feed['type']=="user")
				{

					?>
  
   <div class="dotted"></div>
            <div class="block">
<?
if($a['vip'] == 0 && $a['access'] == 0){
?>
<img src="/images/icons/<?=$a['r']?>.png" width="16" height="16" alt="">
<?
}
if($a['access'] == 1) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt="">
<?}
if($a['access'] == 2) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt="">
<?}
if($a['access'] == 3) {
?>
<img src="/images/icons/adminy.png" width="16" height="16" alt="">
<?
}
if($a['vip'] == 1 && $a['access'] == 0){
?>
<img src="/images/icons/vip_<?=($a['r'] == man ? 'woman':'man')?>_<?=$a['r']?>.png" width="16" height="16" alt="">
<?
}
?>
 <a class="color3" href="/user/<?=$a['id']?>/"><?=$a['login']?></a> 

<?
  if($a['access'] == 1) {
?>
<font color='f09060'>
<?
  }
  if($a['access'] == 2) {
?>
<font color='008080'>
<?
  }
  if($a['access'] == 3) {
?>
<font color='90c0c0'>
<?}
?>

<?=$feed['text']?>

</font>
     <div class="small"><span class="color2">
<?=(date('d ', $feed['time']) . $monthes[(date('n', $feed['time']))] . date(' H:i', $feed['time']));?>
  </span>
</div>   
</div>  

					<?


				}

			}		

	}


	}elseif(!$tik)
	{

		header("Location:/ticket/");

		exit;

	}


break;
case 'admin';

if($user['access']=="3" OR $user['access']=="2")
{






$id=trim(htmlspecialchars($_GET['id']));

	$tik=mysql_fetch_array(mysql_query("SELECT * FROM `ticket` WHERE `id`='$id'"));

	if($tik){
		
				switch ($tik[status])
		{
			case 'new';

			$status="<font color='yellow'>Ожидание</font>";

			break;

			case 'read';

			$status="<font color='green'>Есть ответ</font>";

			break;

			case 'close';

			$status="<font color='red'>Закрыт</font>";

			break;

			case 'user';

			$status="<font color='red'>Ответил пользователь</font>";

			break;
		}

if($_GET['open']=="true")
{

mysql_query("UPDATE `ticket` SET `status`='read' WHERE `id`='".mysql_real_escape_string($tik['id'])."'");


}

?>




<?

if($_GET['delete']=="true")
{

mysql_query("DELETE FROM `ticket` WHERE `id`='".mysql_real_escape_string($tik['id'])."'");

mysql_query("DELETE FROM `ticket_bt` WHERE `ticket`='".mysql_real_escape_string($tik['id'])."'");


		header("Location:/ticket/");

		exit;

?>

<div class="block"><div class="content">
						<span>Тикет удален:)</span>
						</div>
</div>
<?


}


?>

<?

if($_GET['close']=="true" && $tik['status']!="close")
{


mysql_query("UPDATE `ticket` SET `status`='close' WHERE `id`='".mysql_real_escape_string($tik['id'])."'");




}
		
		if($_GET['answer']=="true")
		{

				$sms=_string($_POST['sms']);
	
				if(mb_strlen($sms)<0 OR mb_strlen($sms)>2048)$err="Длина сообщения от 5 до 2048 символов";

				if($tik['status']=="close")$err="Тикет закрыт.";

				

				if($err)
				{

					?>

						<div class="content">
						<span><?=$err;?></span>
						</div>
					
						<?
				}elseif(!$err)
				{

					mysql_query("INSERT INTO `ticket_bt` SET `text`='".mysql_real_escape_string($sms)."',`type`='admin',`ticket`='".mysql_real_escape_string($tik['id'])."',`ot`='".mysql_real_escape_string($user['id'])."',`time`='".time()."'");
$us=" Вам ответили в Тех.Поддержке тикет N%$tik[id] ";
mysql_query("INSERT INTO `mail` SET `from`='2',`to`='".$tik['user']."',`text`=' ".$us."  ',`time`='".time()."'");
mysql_query("INSERT INTO `contacts` SET `ho`='2',`user`='".$tik['user']."',`time`='".time()."'");

					mysql_query("UPDATE `ticket` SET `status`='read' WHERE `id`='".mysql_real_escape_string($tik['id'])."'");

					?>				
	
						<div class="block"><div class="content">
						<span color="green">Сообщение добавлено!</span>
						</div>
</div>

					<?



				}



		}
	

   function cst($i) {
        
        switch($i) {

  case 1:
    $cst = 'другое';
     break;
    case 2:
    $cst = 'Восстановления аккаунта';
     break;
    case 3:
    $cst = 'Ошибки / баги';
     break;
    case 4:
    $cst = 'Вопросы по игре';
     break;
    case 5:
    $cst = 'Вопросы по оплате';
     break;
        }
        
    return $cst;
    
    }



		?>

	    <div class="content">
            <div class="line"></div>            <div class="block">
                            <img src="/images/icons/1.png" width="16" height="16" alt=""> <a class="color3" href="/user/<?=$tik['user']?>"><?=$tik['login']?></a><span class="small green"> * </span><span class="color2 small">
                            , <?=(date('d ', $tik['time']) . $monthes[(date('n', $tik['time']))] . date(' H:i', $tik['time']));?>
</span>
                                    
                        <div> <?echo "".nl2br($tik['text'])."";?></div>
                    </div>
        <div class="dotted"></div>
        
<div class="block">
			Причина обращения: <span style="color: green"><?=cst($tik['ob'])?></span><br/></div>
<div class="dotted"></div>
<div class="h-navig"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tbody><tr>
<td class="h-navig-item"><a href="?mode=admin&id=<?=$tik['id'];?>&open=true">Открыть</a></td><td class="h-navig-item"><span class="active"><a href="?mode=admin&id=<?=$tik['id'];?>&close=true">Закрыть</a></span></td><td class="h-navig-item"><a href="?mode=admin&id=<?=$tik['id'];?>&delete=true">Удалить</a></td>
</tr></tbody></table></div>

</div>

<div class="dotted"></div>
<form class="block" action="?mode=admin&id=<?=$tik['id'];?>&answer=true" method="post">
<div class="form-group field-ticketmessagecreateform-text required">
<label class="control-label" for="ticketmessagecreateform-text">Комментарий</label>
<textarea id="ticketmessagecreateform-text" class="form-control" name="sms" rows="5"></textarea>

<div class="help-block"></div>
</div>    <span class="m3 btn_start middle"><span class="btn_end">
    <button type="submit" class="btn">Отправить</button></span>
</span>
</form>


			
		
<?

	$answer=mysql_query("SELECT  * FROM `ticket_bt` WHERE `ticket`='".$tik['id']."' ORDER BY `id` DESC");

	if(mysql_num_rows($answer)==0){


		?>

<div class="dotted"></div>
		<div class="content">
 <div class="block">Сообщений не найдено</div>
		</div>
<div class="dotted"></div>
		<?
	
	}elseif(mysql_num_rows($answer)>0)
	{

			while ($feed=mysql_fetch_array($answer))
			{
			  
$a=mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id` = '".$feed['ot']."'"));

				if($feed['type']=="admin")

				{

	
?>
  
    <div class="dotted"></div>
            <div class="block">
<?
if($a['vip'] == 0 && $a['access'] == 0){
?>
<img src="/images/icons/<?=$a['r']?>.png" width="16" height="16" alt="">
<?
}
if($a['access'] == 1) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt="">
<?}
if($a['access'] == 2) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt="">
<?}
if($a['access'] == 3) {
?>
<img src="/images/icons/adminy.png" width="16" height="16" alt="">
<?
}
if($a['vip'] == 1 && $a['access'] == 0){
?>
<img src="/images/icons/vip_<?=($a['r'] == man ? 'woman':'man')?>_<?=$a['r']?>.png" width="16" height="16" alt="">
<?
}
?>
 <a class="color3" href="/user/<?=$a['id']?>/"><?=$a['login']?></a> 

<?
  if($a['access'] == 1) {
?>
<font color='f09060'>
<?
  }
  if($a['access'] == 2) {
?>
<font color='008080'>
<?
  }
  if($a['access'] == 3) {
?>
<font color='90c0c0'>
<?}
?>

<?=$feed['text']?>

</font>
     <div class="small"><span class="color2">
<?=(date('d ', $feed['time']) . $monthes[(date('n', $feed['time']))] . date(' H:i', $feed['time']));?>
  </span>
</div>   
</div>
<?

}elseif($feed['type']=="user")
				{
?>

    <div class="dotted"></div>
            <div class="block">
<?
if($a['vip'] == 0 && $a['access'] == 0){
?>
<img src="/images/icons/<?=$a['r']?>.png" width="16" height="16" alt="">
<?
}
if($a['access'] == 1) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt="">
<?}
if($a['access'] == 2) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt="">
<?}
if($a['access'] == 3) {
?>
<img src="/images/icons/adminy.png" width="16" height="16" alt="">
<?
}
if($a['vip'] == 1 && $a['access'] == 0){
?>
<img src="/images/icons/vip_<?=($a['r'] == man ? 'woman':'man')?>_<?=$a['r']?>.png" width="16" height="16" alt="">
<?
}
?>
 <a class="color3" href="/user/<?=$a['id']?>/"><?=$a['login']?></a> 

<?
  if($a['access'] == 1) {
?>
<font color='f09060'>
<?
  }
  if($a['access'] == 2) {
?>
<font color='008080'>
<?
  }
  if($a['access'] == 3) {
?>
<font color='90c0c0'>
<?}
?>

<?=$feed['text']?>

</font>
     <div class="small"><span class="color2">
<?=(date('d ', $feed['time']) . $monthes[(date('n', $feed['time']))] . date(' H:i', $feed['time']));?>
  </span>
</div>   
</div>
<?}

}}

	}elseif(!$tik)
	{

		header("Location:/ticket/");


		exit;

	}








}

break;
case 'viev_all';

if(!$user['access']>"3")
{


	header("Location:/");

	exit;





}

$all=mysql_query("SELECT * FROM `ticket`  ORDER BY `id` DESC");

if(mysql_num_rows($all)==0)
{

?>

<div class="line">
</div>
    <div class="block">Нет ни одного обращения</div>
	
		<?

}elseif(mysql_num_rows($all)>0)
{


	while ($at=mysql_fetch_array($all))
	{
	  
					switch ($at[status])
		{
			case 'new';

			$status="<font color='yellow'>Ожидание</font>";

			break;

			case 'read';

			$status="<font color='green'>Есть ответ</font>";

			break;

			case 'close';

			$status="<font color='red'>Закрыт</font>";

			break;

			case 'user';

			$status="<font color='red'>Ответил пользователь</font>";

			break;
		}

				?>	  
 <div class="menu">        <li><a href="?mode=admin&id=<?=$at['id'];?>"><img src="/images/icons/.jpg" width="16" height="16" alt=""> <?=$at['title'];?>(<?=$status;?>)</a></li></div>   
  
<div class="dotted"></div>

			

		<?
	



	}






}


break;


}

include './system/f.php';

?>