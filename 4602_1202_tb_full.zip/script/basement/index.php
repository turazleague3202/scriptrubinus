<?

include '../system/common.php';
    
include '../system/functions.php';
        
include '../system/user.php';


if(!$user) {

  header('location: /menu');
    
exit;

}
if($user['level'] >= 150) {
}else{

$_SESSION['not']='<div class="alert"><div>                закрыт временно!!!</div></div>';
header('location: /menu?'.$udet.'');
    exit;
}


if(!$clan) {

  header('location: /menu');
    
exit;

}


$action = _string($_GET['action']);

switch($action) {
  default:


$title = 'Подвал';

include '../system/h.php';
    





$bk = mysql_query('SELECT * FROM `bes_u` WHERE `user` = "'.$user['id'].'"');  
  $bk = mysql_fetch_array($bk);
if($bk['boss'] == 0){
       }else{
header('location: /basement/index/ataka/?'.$udet.'');
}
if($claun['boss'] == 0){
       }else{
header('location: /basement/index/ataka/?'.$udet.'');
}


$big = mysql_query('SELECT * FROM `bes_ataka` WHERE `clan` = "'.$clan['id'].'"');  
  $big = mysql_fetch_array($big);


$po = mysql_query('SELECT * FROM `bes_ataka` WHERE `battle` = "'.$bk['battle'].'" AND `clan` = "'.$clan['id'].'"');  
  $po = mysql_fetch_array($po);

$bigu = mysql_query('SELECT * FROM `bes_u` WHERE `clan` = "'.$clan['id'].'"');  
  $bigu = mysql_fetch_array($bigu);
$boi = mysql_query('SELECT * FROM `bas_battle` WHERE `clan` = "'.$clan['id'].'"');
  $boty = mysql_fetch_array($boi);

if(isset($_GET['pri'])){
mysql_query('INSERT INTO `bes_u` SET  `clan` = "'.$clan['id'].'",`user` = "'.$user['id'].'",`battle` = "'.$boty['battle'].'",`boss`="1",`bos`="'.(time() + (4200)).'"');
header('location: /basement/index/ataka/?'.$udet.'');
}


$no = mysql_query('SELECT * FROM `bes_ataka` WHERE  `clan` = "'.$clan['id'].'" AND `battle` = "'.$boty['battle'].'" ORDER BY `id` DESC LIMIT 1');
  $no = mysql_fetch_array($no);
$nop = mysql_query('SELECT * FROM `bes_u` WHERE  `clan` = "'.$clan['id'].'" AND `battle` = "'.$boty['battle'].'" ORDER BY `id` DESC LIMIT 1');
  $nop = mysql_fetch_array($nop);

$bo = mysql_query('SELECT * FROM `bas_battle` WHERE  `clan` = "'.$clan['id'].'" AND `battle` = "'.$boty['battle'].'"');
  $bot = mysql_fetch_array($bo);

      if(!$po['battle'] != $nop['battle']){
}else{
		  

echo '    <div class="content"><div class="block center color3 s125">Идёт сражение</div>
            <div class="line"></div><div class="block center s125">
    Твоя банда сражается с беспредельщиком
</div>
<div class="dotted"></div>
<div class="block">        
    <span>    <img class="left mr8" src="/images/basement/'.$no['boss'].'.jpg" width="50" height="50" alt="">    </span>
                                <img src="/images/icons/boss.png" width="16" alt="" hegiht="16"> <span>'.$no['name'].'  </span>        <span class="white">
    
    <img src="/images/icons/level.png" width="16" height="16" alt=""> '.$no['lvl'].'  ур.    </span>
    <div class="m3" style="padding-left: 58px">    <div style="width: 100%; height: 4px"
            class="progress-grey">
            <div style="width: 100%; height: 4px" class="progress-green"></div></div>    </div>    <div>
            
    <img src="/images/icons/currentHealth.png" width="16" height="16" alt=""> '.$no['hp'].'            
    <img src="/images/icons/damage.png" width="16" height="16" alt=""> '.$no['str'].'             
    <img src="/images/icons/armor.png" width="16" height="16" alt=""> '.$no['def'].'         </div>
<div class="clear"></div>
</div>    <div class="dotted"></div>
    <div class="block center">
        <span class="btn_start"><span class="btn_end"><a class="btn" href="?pri">Присоединиться</a></span> </span>    </div>
</div>';


include '../system/f.php';
exit();


}


$start = _string(_num($_GET['start']));
if($start) {
	
 $shop = mysql_fetch_array(mysql_query('SELECT * FROM `basement` WHERE `id` = \''.$start.'\''));



if($clan['boss'] == 0){
       }else{
header('location: /menu/?'.$udet.'');
}

if($user['boss_u'] == 0){
       }else{
header('location: /menu/?'.$udet.'');
}
if($po['bo'] == 0){
       }else{
header('location: /menu/?'.$udet.'');
}

if($shop['id'] == 17) {
   if($clan['key16'] <0) {header('location: /basement/?'.$udet.'');
    exit;
}
}else{
}
if($shop['id'] == 16) {
   if($clan['key15'] <0) {header('location: /basement/?'.$udet.'');
    exit;
}
}else{
}
if($shop['id'] == 15) {
   if($clan['key14'] <0) {header('location: /basement/?'.$udet.'');
    exit;
}
}else{
}
if($shop['id'] == 14) {
   if($clan['key13'] <0) {header('location: /basement/?'.$udet.'');
    exit;
}
}else{
}
if($shop['id'] == 13) {
   if($clan['key12'] < 0) {header('location: /basement/?'.$udet.'');
    exit;
}
}else{
}
if($shop['id'] == 12) {
   if($clan['key11'] < 0) {header('location: /basement/?'.$udet.'');
    exit;
}
}else{
}
if($shop['id'] == 11) {
   if($clan['key10'] < 0) {header('location: /basement/?'.$udet.'');
    exit;
}
}else{
}
if($shop['id'] == 10) {
   if($clan['key9'] <0) {header('location: /basement/?'.$udet.'');
    exit;
}
}else{
}
if($shop['id'] == 9) {
   if($clan['key8'] < 0) {header('location: /basement/?'.$udet.'');
    exit;
}
}else{
}
if($shop['id'] == 8) {
   if($clan['key7'] <0) {header('location: /basement/?'.$udet.'');
    exit;
}
}else{
}
if($shop['id'] == 7) {
   if($clan['key6'] < 0) {header('location: /basement/?'.$udet.'');
    exit;
}
}else{
}
if($shop['id'] == 6) {
   if($clan['key5'] <0) {header('location: /basement/?'.$udet.'');
    exit;
}
}else{
}
if($shop['id'] == 5) {
   if($clan['key4'] <0) {header('location: /basement/?'.$udet.'');
    exit;
}
}else{
}
if($shop['id'] == 4) {
   if($clan['key3'] <0) {header('location: /basement/?'.$udet.'');
    exit;
}
}else{
}
if($shop['id'] == 3) {
   if($clan['key2'] <0) {header('location: /basement/?'.$udet.'');
    exit;
}
}else{
}
if($shop['id'] == 2) {
   if($clan['key1'] <0) {header('location: /basement/?'.$udet.'');
    exit;
}
}else{
}

if($clan_memb['rank']==0){
$_SESSION['not']='<div class="alert"><div>                Открыть может только, Главарь</div></div>';
header('location: /menu/?'.$udet.'');
exit;
}
if($clan_memb['rank']==3){
$_SESSION['not']='<div class="alert"><div>                Открыть может только, Главарь</div></div>';
header('location: /menu/?'.$udet.'');
exit;
}
if($clan_memb['rank']==2){
$_SESSION['not']='<div class="alert"><div>                Открыть может только, Главарь</div></div>';
header('location: /menu/?'.$udet.'');
exit;
}
if($clan_memb['rank']==1){
$_SESSION['not']='<div class="alert"><div>                Открыть может только, Главарь</div></div>';
header('location: /menu/?'.$udet.'');
exit;
}



  $ko = mysql_query('SELECT * FROM `bes_ataka` WHERE `user` = "'.$user['id'].'" ORDER BY `id` DESC LIMIT 1');
  $ko = mysql_fetch_array($ko);

  if($errors) {
      
        echo '<div class=\'content\' align=\'center\'>';
        
        foreach($errors as $error) {
          
          echo $error.'<br/>';
          
        }
      
        echo '</div>
<div class=\'line\'></div>';
      
  }
  else
  {
	  

 if($clan['level'] >= $shop['lvl']) {
}else{

$_SESSION['not']='<div class="alert"><div>                '.$shop['name'].' доступен с '.$shop['lvl'].' уровня банды</div></div>';
header('location: ?'.$udet.'');
    exit;
}

mysql_query('UPDATE `useers` SET `boss_u` =  "1" WHERE `id` = "'.$user['id'].'"');

mysql_query('UPDATE `clans` SET `boss` =  "1" WHERE `id` = "'.$clan['id'].'"');

mysql_query('INSERT INTO `bes_u` SET  `clan` = "'.$clan['id'].'",`user` = "'.$user['id'].'",`battle` = "'.($ko['id']).'",`boss`= "1"');

mysql_query('INSERT INTO `bas_battle` SET  `clan` = "'.$clan['id'].'",`battle` = "'.($ko['id']).'"');

mysql_query('INSERT INTO `bes_ataka` SET  `clan` = "'.$clan['id'].'",`user` = "'.$user['id'].'",`name` = "'.$shop['name'].'",`boss` = "'.$shop['id'].'",`hp` = "'.$shop['hp'].'",`str` = "'.$shop['str'].'",`def` = "'.$shop['def'].'",`time` = "'.(time() + (4600)).'",`gold` = "'.$shop['gold'].'",`exp` = "'.$shop['exp'].'",`lvl` = "'.$shop['lvl'].'",`hp_m` = "'.$shop['hp'].'",`battle`="'.($ko['id']).'",`bo`="1"');


if($clan){
if($shop['id'] == 1) {
}
if($shop['id'] == 2) {
mysql_query('UPDATE `clans` SET `key1` =  `key1` - 1 WHERE `id` = "'.$clan['id'].'"');

}
if($shop['id'] == 3) {
mysql_query('UPDATE `clans` SET `key2` =  `key2` - 1 WHERE `id` = "'.$clan['id'].'"');

}
if($shop['id'] == 4) {
mysql_query('UPDATE `clans` SET `key3` =  `key3` - 1 WHERE `id` = "'.$clan['id'].'"');

}
if($shop['id'] == 5) {
mysql_query('UPDATE `clans` SET `key4` =  `key4` - 1 WHERE `id` = "'.$clan['id'].'"');

}
if($shop['id'] == 6) {
mysql_query('UPDATE `clans` SET `key5` =  `key5` - 1 WHERE `id` = "'.$clan['id'].'"');

}
if($shop['id'] == 7) {
mysql_query('UPDATE `clans` SET `key6` =  `key6` - 1 WHERE `id` = "'.$clan['id'].'"');

}
if($shop['id'] == 8) {
mysql_query('UPDATE `clans` SET `key7` =  `key7` - 1 WHERE `id` = "'.$clan['id'].'"');

}
if($shop['id'] == 9) {
mysql_query('UPDATE `clans` SET `key8` =  `key8` - 1 WHERE `id` = "'.$clan['id'].'"');

}
if($shop['id'] == 10) {
mysql_query('UPDATE `clans` SET `key9` =  `key9` - 1 WHERE `id` = "'.$clan['id'].'"');

}
if($shop['id'] == 11) {
mysql_query('UPDATE `clans` SET `key10` =  `key10` - 1 WHERE `id` = "'.$clan['id'].'"');

}
if($shop['id'] == 12) {
mysql_query('UPDATE `clans` SET `key11` =  `key11` - 1 WHERE `id` = "'.$clan['id'].'"');

}
if($shop['id'] == 13) {
mysql_query('UPDATE `clans` SET `key12` =  `key12` - 1 WHERE `id` = "'.$clan['id'].'"');

}
if($shop['id'] == 14) {
mysql_query('UPDATE `clans` SET `key13` =  `key13` - 1 WHERE `id` = "'.$clan['id'].'"');

}
if($shop['id'] == 15) {
mysql_query('UPDATE `clans` SET `key14` =  `key14` - 1 WHERE `id` = "'.$clan['id'].'"');

}
if($shop['id'] == 16) {
mysql_query('UPDATE `clans` SET `key15` =  `key15` - 1 WHERE `id` = "'.$clan['id'].'"');

}
if($shop['id'] == 17) {
mysql_query('UPDATE `clans` SET `key16` =  `key16` - 1 WHERE `id` = "'.$clan['id'].'"');

}
}

   header('location: /basement/index/ataka/?'.$udet.'');
  
}
}
?>


    <div class="content"><div class="block center color3 s125">Подвал</div>
            <div class="line"></div>    
<?
$complexity = _string(_num($_GET['complexity']));
if($complexity) {

  if($complexity == 1 OR $complexity == 2 OR $complexity == 3 OR $complexity == 4 OR $complexity == 5 OR $complexity == 6 OR $complexity == 7 OR $complexity == 8 ) {
    

    
  }

?>
<?
if($complexity == 1) {
?>
<div class="h-navig"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tbody><tr>
<td class="h-navig-item"><span
            class="active">лёгкие</span></td>
<td class="h-navig-item"><a href="/basement/index?complexity=2?<?=$udet?>">средние</a></td><td class="h-navig-item"><a href="/basement/index?complexity=3?<?=$udet?>">сложные</a></td><td class="h-navig-item"><a href="/basement/index?complexity=4?<?=$udet?>">сверх-сложные</a></td>
</tr></tbody></table></div>
<?
}
?>
<?
if($complexity == 2) {
?>
<div class="h-navig"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tbody><tr>
<td class="h-navig-item"><a href="/basement/index?complexity=1?<?=$udet?>">лёгкие</a></td>
<td class="h-navig-item"><span
            class="active">средние</span></td><td class="h-navig-item"><a href="/basement/index?complexity=3?<?=$udet?>">сложные</a></td><td class="h-navig-item"><a href="/basement/index?complexity=4?<?=$udet?>">сверх-сложные</a></td>
</tr></tbody></table></div>
<?
}
?>
<?
if($complexity == 3) {
?>
<div class="h-navig"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tbody><tr>
<td class="h-navig-item"><a href="/basement/index?complexity=1?<?=$udet?>">лёгкие</a></td>
<td class="h-navig-item"><a href="/basement/index?complexity=2?<?=$udet?>">средние</a></td><td class="h-navig-item"><span
            class="active">сложные</span></td><td class="h-navig-item"><a href="/basement/index?complexity=4?<?=$udet?>">сверх-сложные</a></td>
</tr></tbody></table></div>
<?
}
?>
<?
if($complexity == 4) {
?>
<div class="h-navig"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tbody><tr>
<td class="h-navig-item"><a href="/basement/index?complexity=1?<?=$udet?>">лёгкие</a></td>
<td class="h-navig-item"><a href="/basement/index?complexity=2?'.$udet.'">средние</a></td><td class="h-navig-item"><a href="/basement/index?complexity=3?<?=$udet?>">сложные</a></td><td class="h-navig-item"><span
            class="active">сверх-сложные</span></td>
</tr></tbody></table></div>
<?
}
?>
<div class="line"></div>
<?
 $q = mysql_query('SELECT * FROM `basement` WHERE `quality` = \''.$complexity.'\'');    
  while($bas = mysql_fetch_array($q)) {

?>



    <div class="block">        
    <span>    <a href="gggggg"><img class="left mr8" src="/images/basement/
<?=$bas['id']?>.jpg" width="50" height="50" alt=""></a>    </span>
                                <img src="/images/icons/boss.png" width="16" alt="" hegiht="16"> <span>
<?=$bas['name']?></span>        <span class="white">
    
    <img src="/images/icons/level.png" width="16" height="16" alt=""> 
<?=$bas['lvl']?> ур.    </span>
    <div>
            
    <img src="/images/icons/health.png" width="16" height="16" alt=""> 
<?=$bas['hp']?>            
    <img src="/images/icons/damage.png" width="16" height="16" alt=""> 
<?=$bas['str']?>            
    <img src="/images/icons/armor.png" width="16" height="16" alt=""> 
<?=$bas['def']?>        </div>
<div class="clear"></div>
</div>
<?
if($bas['id'] == 17){
if($clan['key16'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key16']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 16){
if($clan['key15'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key15']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 15){
if($clan['key14'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key14']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 14){
if($clan['key13'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key13']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 13){
if($clan['key12'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key12']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 12){
if($clan['key11'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key11']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 11){
if($clan['key10'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key10']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 10){
if($clan['key9'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key9']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 9){
if($clan['key8'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>

<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key8']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 8){
if($clan['key7'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key7']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 7){
if($clan['key6'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key6']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 6){
if($clan['key5'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key5']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 5){
if($clan['key4'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key4']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 4){
if($clan['key3'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key3']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 3){
if($clan['key2'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key2']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 2){
if($clan['key1'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key1']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 1){
?> <div class="block center color3">
</div>
<div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
?>
   
        <div class="line"></div>

<?
}
}else {
?>
<div class="h-navig"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tbody><tr>
<td class="h-navig-item"><span
            class="active">лёгкие</span></td>
<td class="h-navig-item"><a href="/basement/index?complexity=2?<?=$udet?>">средние</a></td><td class="h-navig-item"><a href="/basement/index?complexity=3?<?=$udet?>">сложные</a></td><td class="h-navig-item"><a href="/basement/index?complexity=4?<?=$udet?>">сверх-сложные</a></td>
</tr></tbody></table></div>
<div class="line"></div>
<?
 $q = mysql_query('SELECT * FROM `basement` WHERE `quality` = "1"');    
  while($bas = mysql_fetch_array($q)) {


?>



    <div class="block">        
    <span>    <a href="gggggg"><img class="left mr8" src="/images/basement/
<?=$bas['id']?>.jpg" width="50" height="50" alt=""></a>    </span>
                                <img src="/images/icons/boss.png" width="16" alt="" hegiht="16"> <span>
<?=$bas['name']?></span>        <span class="white">
    
    <img src="/images/icons/level.png" width="16" height="16" alt=""> 
<?=$bas['lvl']?> ур.    </span>
    <div>
            
    <img src="/images/icons/health.png" width="16" height="16" alt=""> 
<?=$bas['hp']?>            
    <img src="/images/icons/damage.png" width="16" height="16" alt=""> 
<?=$bas['str']?>            
    <img src="/images/icons/armor.png" width="16" height="16" alt=""> 
<?=$bas['def']?>        </div>
<div class="clear"></div>
</div>
<?
if($bas['id'] == 17){
if($clan['key16'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key16']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 16){
if($clan['key15'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key15']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 15){
if($clan['key14'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key14']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 14){
if($clan['key13'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key13']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 13){
if($clan['key12'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key12']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 12){
if($clan['key11'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key11']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 11){
if($clan['key10'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key10']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 10){
if($clan['key9'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key9']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 9){
if($clan['key8'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>

<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key8']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 8){
if($clan['key7'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key7']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 7){
if($clan['key6'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key6']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 6){

if($clan['key5'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key5']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 5){
if($clan['key4'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key4']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 4){
if($clan['key3'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key3']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 3){
if($clan['key2'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key2']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 2){
if($clan['key1'] <= 0){
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="red">0 шт.</b>
</div>
<?
}else{
?>
<div class="dotted"></div>
 <div class="block center color3">
<img src="/images/icons/key.png" alt=""> Ключи: <b class="green"><?=$clan['key1']?> шт.</b>
     </div>
 <div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
}
if($bas['id'] == 1){
?> <div class="block center color3">
</div>
<div class="dotted"></div>

        <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/?start=<?=$bas['id']?>/?<?=$udet?>">Ηачать cражение</a></span> </span>        </div>
<?
}
?>
        <div class="line"></div>


<?
}
}
?>
</div>
<?
include '../system/f.php';

break;
  case 'ataka':
  $title = 'noy';    
  include '../system/h.php';



$big = mysql_query('SELECT * FROM `bes_ataka` WHERE `clan` = "'.$clan['id'].'"');  
  $big = mysql_fetch_array($big);
$nk = mysql_query('SELECT * FROM `bes_u` WHERE `user` = "'.$user['id'].'"');  
  $nk = mysql_fetch_array($nk);

$bog = mysql_query('SELECT * FROM `bes_u` WHERE `user` = "'.$user['id'].'" AND `battle` = "'.$nk['battle'].'"');  
  $bog = mysql_fetch_array($bog);
              $bossu = mysql_query('SELECT * FROM `bes_ataka` WHERE `battle` = "'.$nk['battle'].'"');
               $bg = mysql_fetch_array($bossu);

			   $pets_t = (20+10);
			   $param = (rand(1,2));

$borg = mysql_query('SELECT * FROM `bes_u` WHERE `user` = "'.$user['id'].'" AND `clan` = "'.$clan['id'].'"');  
  $borg = mysql_fetch_array($borg);


$bug = mysql_query('SELECT * FROM `bes_u` WHERE `clan` = "'.$clan['id'].'"');  
  $bug = mysql_fetch_array($bug);
 
if(isset($_GET['deled'])){

mysql_query('DELETE FROM `bas_battle` WHERE `clan` = "'.$clan['id'].'"');

mysql_query('DELETE FROM `bes_u` WHERE `user` = "'.$user['id'].'"');
mysql_query('DELETE FROM `bes_log` WHERE `user` = "'.$user['id'].'"');
header('location: /basement/index/?'.$udet.'');
exit();
}


if(isset($_GET['po'])){
echo ' <div class="content"><div class="block center s125 red">
    Ты потерпел поражение
</div>
<div class="dotted"></div>
<div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/ataka/deled?'.$udet.'">Завeршить сpажениe</a></span> </span>    </div>';
include '../system/f.php';
exit();
}

if($bg['time'] < time()){

header('location: /basement/index/ataka/po');
}


if($user['vip']==0){
$ex=$bog['exp'];
$go=$bog['gold'];
}else{
$ex=$bog['exp']*2;
$go=$bog['gold']*2;
}


if(isset($_GET['deledp'])){


if($bog['hp'] <= 1){


mysql_query('DELETE FROM `bes_u` WHERE `user` = "'.$user['id'].'"');


mysql_query('DELETE FROM `bes_log` WHERE `user` = "'.$user['id'].'"');
mysql_query('UPDATE `bes_u` SET `boss` =  "0" WHERE `user` = "'.$user['id'].'"');


if($bog['uron'] > 0){
$gol=($bg['boss']*4);
mysql_query('UPDATE `users` SET `s` = `s` +"'.($go).'", `exp` = `exp` + "'.($ex+$clan['built_4']).'", `exepy` = `exepy` + "'.($ex+$clan['built_4']).'",`g` = `g` + "'.($gol).'" WHERE `id` = "'.$user['id'].'"'); 


mysql_query('UPDATE `clans` SET `s` = `s` + "'.($go*3).'", `exp` = `exp` + "'.($ex + $clan['built_5']).'", `g` = `g` + 5 WHERE `id` = "'.$clan['id'].'"');
       mysql_query('UPDATE `clan_memb` SET `exp` = `exp` + 1 WHERE `clan` = "'.$clan['id'].'" AND `user` = "'.$user['id'].'"');
}


mysql_query('UPDATE `bes_ataka` SET `clan` =  "0" WHERE `clan` = "'.$clan['id'].'"');

mysql_query('UPDATE `bass_battle` SET `clan` =  "0" WHERE `battle` = "'.$nk['battle'].'"');

mysql_query('DELETE FROM `baas_battle` WHERE `battle` = "'.$nk['battle'].'"');

if($user['id'] == $bg['user']){

if($bg['boss'] == 1) {

mysql_query('UPDATE `bes_ataka` SET `user` = "0" WHERE `clan` = "'.$clan['id'].'"');
mysql_query('UPDATE `clans` SET `key1` =  `key1` + 1 WHERE `id` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_m` SET `u` =  `u` + 1,`name` = "'.$bg['name'].'", `boss` = "1" WHERE `clan` = "'.$clan['id'].'"');
}
if($bg['boss'] == 2) {
mysql_query('UPDATE `clans` SET `key2` =  `key2` + 1 WHERE `id` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_m` SET `u2` =  `u2` + 1,`name2` = "'.$bg['name'].'", `boss2` = "2" WHERE `clan` = "'.$clan['id'].'"');
}
if($bg['boss'] == 3) {
mysql_query('UPDATE `clans` SET `key3` =  `key3` + 1 WHERE `id` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_m` SET `u3` =  `u3` + 1,`name3` = "'.$bg['name'].'", `boss3` = "3" WHERE `clan` = "'.$clan['id'].'"');
}
if($bg['boss'] == 4) {
mysql_query('UPDATE `clans` SET `key4` =  `key4` + 1 WHERE `id` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_m` SET `u4` =  `u4` + 1,`name4` = "'.$bg['name'].'", `boss4` = "4" WHERE `clan` = "'.$clan['id'].'"');
}
if($bg['boss'] == 5) {
mysql_query('UPDATE `clans` SET `key5` =  `key5` + 1 WHERE `id` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_m` SET `u5` =  `u5` + 1,`name5` = "'.$bg['name'].'", `boss5` = "5" WHERE `clan` = "'.$clan['id'].'"');
}
if($bg['boss'] == 6) {
mysql_query('UPDATE `clans` SET `key6` =  `key6` + 1 WHERE `id` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_m` SET `u6` =  `u6` + 1,`name6` = "'.$bg['name'].'", `boss6` = "6" WHERE `clan` = "'.$clan['id'].'"');

}

if($bg['boss'] == 7) {
mysql_query('UPDATE `clans` SET `key7` =  `key7` + 1 WHERE `id` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_m` SET `u7` =  `u7` + 1,`name7` = "'.$bg['name'].'", `boss7` = "7" WHERE `clan` = "'.$clan['id'].'"');
}
if($bg['boss'] == 8) {
mysql_query('UPDATE `clans` SET `key8` =  `key8` + 1 WHERE `id` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_m` SET `u8` =  `u8` + 1,`name8` = "'.$bg['name'].'", `boss8` = "8" WHERE `clan` = "'.$clan['id'].'"');
}
if($bg['boss'] == 9) {
mysql_query('UPDATE `clans` SET `key9` =  `key9` + 1 WHERE `id` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_m` SET `u9` =  `u9` + 1,`name9` = "'.$bg['name'].'", `boss9` = "9" WHERE `clan` = "'.$clan['id'].'"');
}
if($bg['boss'] == 10) {
mysql_query('UPDATE `clans` SET `key10` =  `key10` + 1 WHERE `id` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_m` SET `u10` =  `u10` + 1,`name10` = "'.$bg['name'].'", `boss10` = "10" WHERE `clan` = "'.$clan['id'].'"');
}
if($bg['boss'] == 11) {
mysql_query('UPDATE `clans` SET `key11` =  `key11` + 1 WHERE `id` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_m` SET `u11` =  `u11` + 1,`name11` = "'.$bg['name'].'", `boss11` = "11" WHERE `clan` = "'.$clan['id'].'"');
}
if($bg['boss'] == 12) {
mysql_query('UPDATE `clans` SET `key12` =  `key12` + 1 WHERE `id` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_m` SET `u12` =  `u12` + 1,`name12` = "'.$bg['name'].'", `boss12` = "12" WHERE `clan` = "'.$clan['id'].'"');
}
if($bg['boss'] == 13) {
mysql_query('UPDATE `clans` SET `key13` =  `key13` + 1 WHERE `id` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_m` SET `u13` =  `u13` + 1,`name13` = "'.$bg['name'].'", `boss13` = "13" WHERE `clan` = "'.$clan['id'].'"');
}
if($bg['boss'] == 14) {
mysql_query('UPDATE `clans` SET `key14` =  `key14` + 1 WHERE `id` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_m` SET `u14` =  `u14` + 1,`name14` = "'.$bg['name'].'", `boss14` = "14" WHERE `clan` = "'.$clan['id'].'"');
}
if($bg['boss'] == 15) {
mysql_query('UPDATE `clans` SET `key15` =  `key15` + 1 WHERE `id` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_m` SET `u15` =  `u15` + 1,`name15` = "'.$bg['name'].'", `boss15` = "15" WHERE `clan` = "'.$clan['id'].'"');
}
if($bg['boss'] == 16) {
mysql_query('UPDATE `clans` SET `key16` =  `key16` + 1 WHERE `id` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_m` SET `u16` =  `u16` + 1,`name16` = "'.$bg['name'].'", `boss16` = "16" WHERE `clan` = "'.$clan['id'].'"');
}
if($bg['boss'] == 17) {
mysql_query('UPDATE `clans` SET `key17` =  `key17` + 1 WHERE `id` = "'.$clan['id'].'"');
mysql_query('UPDATE `clan_m` SET `u17` =  `u17` + 1,`name17` = "'.$bg['name'].'", `boss17` = "17" WHERE `clan` = "'.$clan['id'].'"');

}
}

$gol=($bg['boss']*4);
if($nk['uron'] > 0){
$_SESSION['not']=' <div class="alert"><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Прибыль:</div>
 <img src="/images/icons/experience.png" width="16" height="16" alt=""> Авторитет:+'.($ex+$clan['built_4']).'  <img src="/images/icons/silver.png" width="16" height="16" alt=""> Рубли +'.$go.' <img src="/images/icons/gold.png" width="16" height="16" alt=""> Сахар +'.$gol.' '.$candy.'</div></div><div class="alert_bottom"></div>';
header('location: /basement/index/?'.$udet.'');
exit();
}
 }else{
header('location: ?'.$udet.'');
}
}

 
if($bog['hp'] <0){

if(isset($_GET['pobeda'])){
if($nk['uron'] ==0){
echo ' <div class="content"><div class="block center s125 red">
    Вы не участвовали в бою
</div>
<div class="dotted"></div>
<div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/ataka/deled">Завeршить сpажениe</a></span> </span>    </div>';
}
if($nk['uron'] >=1){
echo '    <div class="content"><div class="block center s125 green">
    Враг повержен
</div>
<div class="dotted"></div>
    <div class="block center s125">
        <img src="/images/icons/reward.png" width="16" height="16" alt="">        Награда:     <img src="/images/icons/experience.png" width="16" height="16" alt=""> '.($bg['exp'] + $clan['built_5']).'    <img src="/images/icons/silver.png" width="16" height="16" alt=""> '.($bg['gold']*3).'    </div>
<div class="dotted"></div>
<div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/ataka/deledp?'.$udet.'">Завepшить cpажениe</a></span> </span>    </div>';
}

include '../system/f.php';
exit();
}


header('location: /basement/index/ataka/pobeda?'.$udet.'');
}





if($bog['uron'] > 0){
if($bg){
mysql_query('UPDATE `bes_u` SET `gold` = "'.($bg['gold']).'", `exp` = "'.($bg['exp']).'" WHERE `user` = "'.$user['id'].'"');
}
}
if($bg){
mysql_query('UPDATE `bes_u` SET `clan` = "'.$clan['id'].'",`hp` = "'.$bg['hp'].'"WHERE `user` = "'.$user['id'].'"');
}

$h = mysql_query('SELECT * FROM `bes_u` WHERE `user` = "'.$user['id'].'"');
  $h = mysql_fetch_array($h);

  
if(isset($_GET['atk'])) {



if($bog['time'] > time()) {
  
 header('location: /basement/index/ataka/');
exit;
  }

$_hp = ceil($user['vit']*40/80);
if($user['hp'] < $_hp){
header('location: /basement/index/ataka/hpnoy?'.$udet.'');
exit;
}else{
}

$stru = ceil($user['str']*90/100);
$stri = ceil($user['str']*95/100);
$st=rand($stru,$stri);

$my_atk += rand(round($user['str']/1), round($user['str']/2));
$bos_atk += rand(round($bg['str']/1), round($bg['str']/2));
$bos_atk -= rand(round($user['def']/1), round($user['def']/2));
$my_atk -= rand(round($bg['def']/1), round($bg['def']/6));

if($bos_atk < 0)$bos_atk = 0;
if($my_atk < 0)$my_atk = 0;

$bos_atka = $bos_atk;
$bos_ataka = $bos_atk;

$my_a = ($my_atk*2);
$my_atka = $my_atk;


$my_ataka = $my_atk;
if($bos_atka > 0){ $bos_atka="нанёс $bos_atka";}else{$bos_atka=" <span class=color2> промах </span>";}


if($bog['hp'] <= 0){


}else{
if($user['g']>=1)
{


$sek=rand(1,2);
mysql_query('UPDATE `bes_ataka` SET `hp` =  `hp` - "'.$my_atka.'" WHERE `clan` = "'.$clan['id'].'" AND `battle` = "'.$nk['battle'].'"');
mysql_query('UPDATE `bes_u` SET `uron` =  `uron` + "'.$my_atka.'", `time` = "'.(time()+1).'" WHERE `user` = "'.$user['id'].'"');
mysql_query('UPDATE `bes_u` SET `hp` =  `hp` - "'.$my_atka.'" WHERE `battle` = "'.$nk['battle'].'"');
mysql_query('UPDATE `users` SET `hp` =  `hp` - "'.$bos_ataka.'" WHERE `id` = "'.$user['id'].'"');

$atas= " <img src=/images/icons/$user[r].png width=16 height=16 alt=> <span class=color3>$user[login]</span> нанёс $my_atka <img src=/images/icons/uron.png width=16 height=16 alt=> урона <span class=red>$bg[name]</span> ";

mysql_query('INSERT INTO `bes_log` SET  `clan` = "'.$clan['id'].'",`user` = "'.$user['id'].'",`time` = "'.time().'",`text` = "'.$atas.'",`boss` = "'.$bg['boss'].'",`uron` = "'.$my_atka.'"');


$ats= "<img src=/images/icons/boss.png width=16 height=16 alt=> <span class=color3>$bg[name]</span> $bos_atka ";

mysql_query('INSERT INTO `bes_log` SET  `clan` = "'.$clan['id'].'",`user` = "'.$user['id'].'",`time` = "'.time().'",`text` = "'.$ats.'",`boss` = "'.$bg['boss'].'",`uron` = "'.$bos_atka.'"');

}else{
}
}    

header('location: /basement/index/ataka/?'.$udet.'');

}
 #
$h = mysql_query('SELECT * FROM `bes_u` WHERE `user` = "'.$user['id'].'"');
  $h = mysql_fetch_array($h);
  $bosy = mysql_query('SELECT * FROM `bes_u` WHERE `battle` = "'.$nk['battle'].'"');
  $bot = mysql_fetch_array($bosy);

      if(!$bot){
		  
		  header('location: /basement/index/?'.$udet.'');

       }else{


if(isset($_GET['potion'])) {
    mysql_query('UPDATE `users` SET `s` = `s` - 80, `hp` = "'.($user['vit']).'"WHERE `id` = "'.$user['id'].'"');


header('location: /basement/index/ataka/?'.$udet.'');
exit;
}

if(isset($_GET['hpnoy'])) {


echo '<div class="alert"><div>    <div class="red s125">Не хватает здоровья</div>
    <div class="a_separator"></div>
    <div class="inline-block"><div class="block">
            <a href="#"><img class="left mr8" src="/images/items/794.jpg" alt=""></a>
            <img src="/images/icons/mixture.png" width="16" height="16" alt=""> <a class="" href="#"><span class="">Здоровяк</span></a>
        <span class="white">
    <img src="/images/icons/level.png" width="16" height="16" alt=""> 1 ур.    </span>
<div>
<span class="green">
<img src="/images/icons/currentHealth.png" width="16" height="16" alt="">&nbsp;+100%,</span>
<img src="/images/icons/date.png" width="16" height="16" alt="">    моментально
</div><div class="clear"></div>
</div>
<div class="clear"></div>
</div>
    <div class="a_separator"></div>
    <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/ataka/potion?'.$udet.'">Восстановить за     <img src="/images/icons/silver.png" width="16" height="16" alt=""> 84</a></span> </span></div></div><div class="alert_bottom"></div>';
}




      $dmg +=round(rand(($user['str']/6),($user['str']/4)));
      

      $dmg -= round(rand(($bg['def']/12),($bg['def']/7)));
    if($dmg < 0) {
    
      $dmg = 0;
    
    }

      $opponent_dmg +=round(rand(($bg['str']/6),($bg['str']/4)));


      $opponent_dmg -= round(rand(($user['def']/12),($user['def']/7)));
    
    if($opponent_dmg < 0) {
    
      $opponent_dmg = 0;
    
    }



$bh = mysql_query('SELECT * FROM `bes_u` WHERE `user` = "'.$user['id'].'"');  
  $an = mysql_fetch_array($bh);

if($an['boss'] == 1){

$hp_b = round(100 / ($bg['hp_m']/ $bg['hp']));
if($hp_m){
$hp_m=100;
}


?>
   <div class="content"><div class="block center color3 s125"><img src="/images/icons/circle.png" alt=""> <a href="/basement/index/ataka/?'.$udet.'"><?=$bg['name']?></a><span class="white">, <?=_time($bg['time'] - time())?>
</span></div>
            

<div class="line"></div><div class="h-navig"><table width="100%" border="0" cellpadding="0" cellspacing="0">
        <tbody><tr><td class="h-navig-item"><span
            class="active">Бой</span></td><td class="h-navig-item"><a href="/chat/clan">Чат </a></td></tr></tbody></table></div><div class="line"></div>
<?
if($user['id'] == $bg['user']){
?>
    <div class="block center">
        <span class="s125">
            <img src="/images/icons/reward.png" width="16" height="16" alt=""> Ништяки:
                <img src="/images/icons/experience.png" width="16" height="16" alt=""> <?=$bog['exp']?>    <img src="/images/icons/silver.png" width="16" height="16" alt=""> <?=$bog['gold']?>        </span>
            </div>
    <div class="dotted"></div>
<?
}
?>
<div class="block">        
    <div class="center">    <a href="/basement/index/ataka/atk"><img class="center " src="/images/basement/<?=$bg['boss']?>.jpg" width="50" height="50" alt=""></a>    </div>
                                <img src="/images/icons/boss.png" width="16" alt="" hegiht="16"> <span class="center"><?=$bg['name']?></span>        <span class="white">
    

    <img src="/images/icons/level.png" width="16" height="16" alt=""> <?=$bg['lvl']?> ур.    </span>
    <div class="m3" style="">    <div style="width: 100%; height: 4px"
            class="progress-grey">
            <div style="width: <?=$hp_b?>%; height: 4px" class="progress-green"></div></div>    </div>    <div>
            
    <img src="/images/icons/currentHealth.png" width="16" height="16" alt=""> <?=$bg['hp']?>            
    <img src="/images/icons/damage.png" width="16" height="16" alt=""> <?=$bg['str']?>            
    <img src="/images/icons/armor.png" width="16" height="16" alt=""> <?=$bg['def']?>        </div>
<div class="clear"></div>
</div>    <div class="dotted"></div>
    <div class="block center">
        <span class="btn_start"><span class="btn_end"><a class="btn" href="/basement/index/ataka/atk">Ηaнеcти yдар</a></span> </span>    </div>
    <div class="dotted"></div>
<div class="block">           
<?

   $w_1 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$user['id'].'" AND `id` = "'.$user['w_1'].'"');
    $w_1 = mysql_fetch_array($w_1);
if(!$w_1) {
$w_1['item'] = 0;
}
    $w_2 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$user['id'].'" AND `id` = "'.$user['w_2'].'"');
    $w_2 = mysql_fetch_array($w_2);
if(!$w_2) {
$w_2['item'] = 0;
}
    $w_3 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$user['id'].'" AND `id` = "'.$user['w_3'].'"');
    $w_3 = mysql_fetch_array($w_3);
if(!$w_3) {
$w_3['item'] = 0;
}
    $w_4 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$user['id'].'" AND `id` = "'.$user['w_4'].'"');
    $w_4 = mysql_fetch_array($w_4);
if(!$w_4) {
$w_4['item'] = 0;
}
    $w_5 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$user['id'].'" AND `id` = "'.$user['w_5'].'"');
    $w_5 = mysql_fetch_array($w_5);
if(!$w_5) {
$w_5['item'] = 0;
}
    $w_6 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$user['id'].'" AND `id` = "'.$user['w_6'].'"');
    $w_6 = mysql_fetch_array($w_6);
if(!$w_6) {
$w_6['item'] = 0;
}



    $w_7 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$user['id'].'" AND `id` = "'.$user['w_7'].'"');
    $w_7 = mysql_fetch_array($w_7);
if(!$w_7) {
$w_7['item'] = 0;
}
    $w_8 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$user['id'].'" AND `id` = "'.$user['w_8'].'"');
    $w_8 = mysql_fetch_array($w_8);
if(!$w_8) {
$w_8['item'] = 0;
}

if($user['r'] == 0) {
?>
       <img class="left mr8" src="http://bespredel.mobi/maneken?sex=man&amp;width=120&amp;height=160&amp;fragment=1&amp;frame=&amp;equip%5B1%5D=<?=$w_1['item']?>&amp;equip%5B2%5D=<?=$w_2['item']?>&amp;equip%5B3%5D=<?=$w_3['item']?>&amp;equip%5B4%5D=<?=$w_4['item']?>&amp;equip%5B5%5D=<?=$w_5['item']?>&amp;equip%5B6%5D=<?=$w_6['item']?>&amp;equip%5B7%5D=<?=$w_7['item']?>&amp;equip%5B8%5D=<?=$w_8['item']?>" width="50" height="50" alt="">


<?
}
if($user['r'] == 1) {
?>
      <img class="left mr8" src="http://bespredel.mobi/maneken?sex=woman&amp;width=120&amp;height=160&amp;fragment=1&amp;frame=&amp;equip%5B1%5D=<?=$w_1['item']?>&amp;equip%5B2%5D=<?=$w_2['item']?>&amp;equip%5B3%5D=<?=$w_3['item']?>&amp;equip%5B4%5D=<?=$w_4['item']?>&amp;equip%5B5%5D=<?=$w_5['item']?>&amp;equip%5B6%5D=<?=$w_6['item']?>&amp;equip%5B7%5D=<?=$w_7['item']?>&amp;equip%5B8%5D=<?=$w_8['item']?>" width="50" height="50" alt="">


<?
}
?>
                    <img src="/images/icons/<?=$user['r']?>.png" width="16" height="16" alt=""> <span><?=$user['login']?></span> <span class="small green"> * </span>        <span class="white">
    
    <img src="/images/icons/level.png" width="16" height="16" alt=""> <?=$user['level']?> ур.    </span>
    <div class="m3" style="padding-left: 58px">    <div style="width: 100%; height: 4px"
            class="progress-grey">
            <div style="width: <?=$hp_u?>%; height: 4px" class="progress-green"></div></div>    </div>    <div>
            
    <img src="/images/icons/currentHealth.png" width="16" height="16" alt=""> <?=$user['hp']?>            
    <img src="/images/icons/damage.png" width="16" height="16" alt=""> <?=$user['str']?>            
    <img src="/images/icons/armor.png" width="16" height="16" alt=""> <?=$user['def']?>        </div>
<div class="clear"></div>
</div>    


  <div class="dotted"></div>

        

<?

echo '<div class="block"><div class="color2 small"> <img src="/images/icons/swords.png" width="16" height="16" alt=""> Журнал сражения:</div>';

$q = mysql_query('SELECT * FROM `bes_log` WHERE `user` = "'.$user['id'].'" ORDER BY `time` DESC LIMIT 5');    
  while($row = mysql_fetch_array($q)) {


echo '<div class="small">

'.$row['text'].'
 <span class="color2 small">, '._times(time() - $row['time']).'</span>

</div>';
}
?>

</div>
<?


$b = mysql_query('SELECT * FROM `bes_u` WHERE `user` = "'.$user['id'].'"');  
$an = mysql_fetch_array($b);
echo '<div class="dotted"></div><div class="block">
        <img src="/images/icons/members.png" width="16" height="16" alt="">        <span class="blue">Участники сражения:</span> ('.mysql_result(mysql_query('SELECT COUNT(*) FROM `bes_u` WHERE `battle` = "'.$an['battle'].'"'),0).')
    </div>';

  
$q = mysql_query('SELECT * FROM `bes_u` WHERE `clan` = "'.$clan['id'].'" AND `battle` = "'.$an['battle'].'" ORDER BY `uron` DESC LIMIT 10');    
  while($row = mysql_fetch_array($q)) {

$i++;

$ank=mysql_fetch_array(mysql_query('SELECT * FROM `users` WHERE `id` = "'.$row['user'].'" LIMIT 1'));
  

if($i<10){
    
   echo ' <div class="dotted"></div>
<div class="block"><div>';
?>
<?
if($ank['vip'] == 0){
?>
<img src="/images/icons/<?=$ank['r']?>.png" width="16" height="16" alt="">
<?
}
if($ank['vip'] == 1){
?>
<img src="/images/icons/vip_<?=($ank['r'] == man ? 'woman':'man')?>_<?=$ank['r']?>.png" width="16" height="16" alt="">
<?
}
?>
<?
echo '<a class="color3" href="/user/'.$ank['id'].'">'.$ank['login'].' </a>, урон: <img src="/images/icons/uron.png" width="16" height="16" alt="">'.($row['uron']).'</div>
            </div>';
        
}
}
?>

</div>
</div>
<?
 }
}

include '../system/f.php';

break;
}
?>