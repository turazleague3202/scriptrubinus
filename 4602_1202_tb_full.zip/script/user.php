<?
    
    include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';
    
if(!$user) {

  header('location: /');
  exit;

}

$id = _string(_num($_GET['id']));
  if($id) {
    $i = mysql_query('SELECT * FROM `users` WHERE `id` = "'.$id.'"');
    $i = mysql_fetch_array($i);
    
    if(!$i) {
      header('location: /user/');
      exit;
    }

    }
    else
    { 
      $i = $user;
    }
    
    $title = $i['login'];


include './system/h.php';



if($i['id'] == $user['id']) {
}else{
  $clan_memb = mysql_query('SELECT * FROM `clan_memb` WHERE `user` = "'.$i['id'].'"');
  $clan_memb = mysql_fetch_array($clan_memb);

  
    if($clan_memb) {

       $clany = mysql_fetch_array(mysql_query('SELECT * FROM `clans` WHERE `id` = "'.$clan_memb['clan'].'"'));

   
    $clan_1y= ($clany['built_1'] * 250);


    if($clany['built_1'] > 0 && $clan_1y) {
 
      $i['vit'] += $clan_1y*6;

      $i['hp'] += $clan_1y*4;

    }

 $clan_2y = ($clany['built_2'] * 250);


    
 if($clany['built_2'] > 0 && $clan_2y) {
    
 
       $i['str'] += $clan_2y*6;
    }

 $clan_3y = ($clany['built_3'] * 250);



 if($clany['built_3'] > 0 && $clan_3y) {
  
      $i['def'] += $clan_3y*6;
 
  }}}


function time_last($time){
$sec = time()-$time;
if($sec < 60) $_time = "<span class='green'> сейчас в игре</span>";
if($sec >= 60 && $sec < (60*60)) $_time ="<span class='green'> сейчас в игре</span>";
if($sec >= (60*60) && $sec < ((60*60)*6))$_time = "Сегодня в ".date("H:i",$time);
if($sec >= ((60*60)*6) && $sec < ((60*60)*12)) $_time = "Сегодня в ".date("H:i",$time);
if($sec >= ((60*60)*12) && $sec < (((60*60)*12)*2)) $_time = "Вчера в ".date("H:i",$time);
if($sec >= ((60*60)*168) && $sec < (((60*60)*168)*2)) $_time = " Заходил"."Заходил".(date('d ', $time) . $monthes[(date('n', $time))] . date(' Y г H:i', $time));
if($sec >= (((60*60)*24)*2)){
$__time = date("d F Y в H:i", $time);
$__time = str_replace("January","января",$__time);
$__time = str_replace("February","февраля",$__time);
$__time = str_replace("March","марта",$__time);
$__time = str_replace("April","апреля",$__time);
$__time = str_replace("May","мая",$__time);
$__time = str_replace("June","июня",$__time);
$__time = str_replace("July","июля",$__time);
$__time = str_replace("August","августа",$__time);
$__time = str_replace("September","сентября",$__time);
$__time = str_replace("October","октября",$__time);
$__time = str_replace("November","ноября",$__time);
$__time = str_replace("December","декабря",$__time);
$_time = $__time;
}
return $_time;
}
function time_adm($time){
$sec = time()-$time;
if($sec < 60) $_time = "<span class='green'>".$sec." сек. назад</span>";
if($sec >= 60 && $sec < (60*60)) $_time = round($sec/60)." мин. назад";
if($sec >= (60*60) && $sec < ((60*60)*6))$_time = "Сегодня в ".date("H:i",$time);
if($sec >= ((60*60)*6) && $sec < ((60*60)*24)) $_time = "Сегодня в ".date("H:i",$time);
if($sec >= ((60*60)*24) && $sec < (((60*60)*24)*2)) $_time = "Вчера в ".date("H:i",$time);
if($sec >= ((60*60)*168) && $sec < (((60*60)*168)*2)) $_time = " Заходил ".(date('d ', $time) . $monthes[(date('n', $time))] . date(' Y г H:i', $time));
if($sec >= (((60*60)*24)*2)){
$__time = date("d F Y в H:i", $time);
$__time = str_replace("January","января",$__time);
$__time = str_replace("February","февраля",$__time);
$__time = str_replace("March","марта",$__time);
$__time = str_replace("April","апреля",$__time);
$__time = str_replace("May","мая",$__time);
$__time = str_replace("June","июня",$__time);
$__time = str_replace("July","июля",$__time);
$__time = str_replace("August","августа",$__time);
$__time = str_replace("September","сентября",$__time);
$__time = str_replace("October","октября",$__time);
$__time = str_replace("November","ноября",$__time);
$__time = str_replace("December","декабря",$__time);
$_time = $__time;
}
return $_time;
}
$gup= date(' H:i', $i['online']);
function sec2day($sec=NULL)
{
$days = floor($sec/86400);
$hours = floor(($sec/3600)-$days*24);
$minuts = floor(($sec-$hours*3600-$days*86400)/60);
$seconds = $sec-($minuts*60+$hours*3600+$days*86400);

if ($days!=0)$days = $days.' дн. ';
else $days = NULL;
if ($hours!=0)$hours = $hours.' час. ';
else $hours = NULL;
if ($minuts!=0)$minuts = $minuts.' мин. ';
else $minuts = NULL;

$sectoday = $days.''.$hours.''.$minuts.''.$seconds.' сек.';

return $sectoday;
}


$gupi= date(' H:i', $i['online']);
function _tim($i) {

      $d  = floor($i / 86400); 
      
      $h  = floor(($i / 3600) - $d * 24); 
      
      $m  = floor(($i - $h * 3600 - $d * 86400) / 60); 
      
      $s  = $i - ($m * 60 + $h * 3600 + $d * 86400);

    
       if($d > 0) {
      
        $result = $d.' д. назад, был(а) в игре';
       
      }
      elseif($h > 0)
                 {
       
        $result = $h.' ч. назад, был(а) в игре';
                
      }elseif($m > 0)
                 {
       
      $result = ' сейчас в игре';
                
      }elseif($s >= 0)
                 {
       
      $result = ' сейчас в игре';
                
      }


  return $result.' ';
  
  }


    function _timr($i) {

      $d  = floor($i / 86400); 
      
      $h  = floor(($i / 3600) - $d * 24); 
      
      $m  = floor(($i - $h * 3600 - $d * 86400) / 60); 
      
      $s  = $i - ($m * 60 + $h * 3600 + $d * 86400);

    

      if($d > 0) {
      
        $result = $d.' д';
       
      }
      elseif($h > 0)
                 {
       
        $result = $h.' ч';
                
      }elseif($m > 0)
                 {
       
      $result = $m.' м';
                
      }elseif($s >= 0)
                 {
       
      $result = $s.' сек';
                
      }

  return $result.' ';
  
  }


$w_1 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$i['id'].'" AND `id` = "'.$i['w_1'].'"');
$w_1 = mysql_fetch_array($w_1);
if(!$w_1) {
  $w_1['item'] = 0;
}
$w_1_item = mysql_query('SELECT * FROM `items` WHERE `id` = "'.$w_1['item'].'"');
$w_1_item = mysql_fetch_array($w_1_item);

$w_2 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$i['id'].'" AND `id` = "'.$i['w_2'].'"');
$w_2 = mysql_fetch_array($w_2);
if(!$w_2) {
  $w_2['item'] = 0;
}

$w_2_item = mysql_query('SELECT * FROM `items` WHERE `id` = "'.$w_2['item'].'"');
$w_2_item = mysql_fetch_array($w_2_item);

$w_3 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$i['id'].'" AND `id` = "'.$i['w_3'].'"');
$w_3 = mysql_fetch_array($w_3);
if(!$w_3) {
  $w_3['item'] = 0;
}

$w_3_item = mysql_query('SELECT * FROM `items` WHERE `id` = "'.$w_3['item'].'"');
$w_3_item = mysql_fetch_array($w_3_item);


$w_4 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$i['id'].'" AND `id` = "'.$i['w_4'].'"');
$w_4 = mysql_fetch_array($w_4);

if(!$w_4) {
  $w_4['item'] = 0;
}

$w_4_item = mysql_query('SELECT * FROM `items` WHERE `id` = "'.$w_4['item'].'"');
$w_4_item = mysql_fetch_array($w_4_item);

$w_5 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$i['id'].'" AND `id` = "'.$i['w_5'].'"');
$w_5 = mysql_fetch_array($w_5);
if(!$w_5) {
  $w_5['item'] = 0;
}
$w_5_item = mysql_query('SELECT * FROM `items` WHERE `id` = "'.$w_5['item'].'"');
$w_5_item = mysql_fetch_array($w_5_item);

$w_6 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$i['id'].'" AND `id` = "'.$i['w_6'].'"');
$w_6 = mysql_fetch_array($w_6);
if(!$w_6) {
  $w_6['item'] = 0;
}
$w_6_item = mysql_query('SELECT * FROM `items` WHERE `id` = "'.$w_6['item'].'"');
$w_6_item = mysql_fetch_array($w_6_item);

$w_7 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$i['id'].'" AND `id` = "'.$i['w_7'].'"');
$w_7 = mysql_fetch_array($w_7);
if(!$w_7) {
  $w_7['item'] = 0;
}
$w_7_item = mysql_query('SELECT * FROM `items` WHERE `id` = "'.$w_7['item'].'"');
$w_7_item = mysql_fetch_array($w_7_item);

$w_8 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$i['id'].'" AND `id` = "'.$i['w_8'].'"');
$w_8 = mysql_fetch_array($w_8);
if(!$w_8) {
  $w_8['item'] = 0;
}
$w_8_item = mysql_query('SELECT * FROM `items` WHERE `id` = "'.$w_8['item'].'"');
$w_8_item = mysql_fetch_array($w_8_item);


  $i_clan_memb = mysql_query('SELECT * FROM `clan_memb` WHERE `user` = "'.$i['id'].'"');
  $i_clan_memb = mysql_fetch_array($i_clan_memb);
  
    if(!$i_clan_memb) {
    
    if($clan && $clan_memb['rank'] >= 0 && _string($_GET['clan_invite'] == true)) {
    
    if(mysql_result(mysql_query('SELECT COUNT(`id`) FROM `clan_invite` WHERE `user` = "'.$i['id'].'" AND `clan` = "'.$clan['id'].'"'),0) == 0) {
      mysql_query('INSERT INTO `clan_invite` (`clan`,`user`,`logn`,`us`) VALUES ("'.$clan['id'].'",
"'.$i['id'].'","'.$user['login'].'","'.$user['id'].'")');

?>


<div class="alert"><div><img src="/images/icons/ok.png" width="16" height="16" alt=""> Приглашение в банду успешно отправлено!</div></div><div class="alert_bottom"></div>    
<?

    }
    else
    {
    
    }

  
    }
  
  }
  
?>

                           
    <div class="content"><div class="block">
    <div>
<?
if($i['vip'] == 0 && $i['access'] == 0){
?>
<img src="/images/icons/<?=$i['r']?>.png" width="16" height="16" alt="">
<?
}

if($i['access'] == 1) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt=""><?
}
if($i['access'] == 2) {
?>
<img src="/images/icons/mod.png" width="16" height="16" alt="">
<?}
if($i['access'] == 3) {
?>
<img src="/images/icons/adminy.png" width="16" height="16" alt="">
<?
}
if($i['vip'] == 1 && $i['access'] == 0){
?>
<img src="/images/icons/vip_<?=($i['r'] == man ? 'woman':'man')?>_<?=$i['r']?>.png" width="16" height="16" alt="">
<?
}
?>
<span style="font-weight: 500; font-size: 110%;"><?=$i['login']?></span> <img src="/images/icons/level.png" width="16" height="16" alt=""><?=$i['level']?> ур.</div>

<?

  if($i_clan_memb) {

    $i_clan = mysql_query('SELECT * FROM `clans` WHERE `id` = "'.$i_clan_memb['clan'].'"');
    $i_clan = mysql_fetch_array($i_clan);

  switch($i_clan_memb['rank']) {
  
    case 1:
    $rank = 'Новобранец';
     break;
    case 2:
    $rank = 'Смотрящий';
     break;
    case 3:
    $rank = 'Помощник';
     break;
    case 4:
    $rank = 'Заместитель';
     break;
    case 5:
    $rank = 'Главарь';
     break;
    
  }

?>

        <div><img src="/images/icons/clan.png" width="16" height="16" alt=""> <a href="/clan/<?=$i_clan['id']?>/"><?=$i_clan['name']?></a>, <?=$rank?></div>

 
<?

  }

?>
<?
if($i['r'] == 0) {
?>
       <a href="?"><img src="http://bespredel.mobi/maneken?sex=man&amp;width=121&amp;height=160&amp;fragment=0&amp;frame=&amp;equip%5B1%5D=<?=$w_1['item']?>&amp;equip%5B2%5D=<?=$w_2['item']?>&amp;equip%5B3%5D=<?=$w_3['item']?>&amp;equip%5B4%5D=<?=$w_4['item']?>&amp;equip%5B5%5D=<?=$w_5['item']?>&amp;equip%5B6%5D=<?=$w_6['item']?>&amp;equip%5B7%5D=<?=$w_7['item']?>&amp;equip%5B8%5D=<?=$w_8['item']?>" alt="">
</a>
</div>

<?
}
if($i['r'] == 1) {
?>
       <a href="?"><img src="http://bespredel.mobi/maneken?sex=woman&amp;width=121&amp;height=160&amp;fragment=0&amp;frame=&amp;equip%5B1%5D=<?=$w_1['item']?>&amp;equip%5B2%5D=<?=$w_2['item']?>&amp;equip%5B3%5D=<?=$w_3['item']?>&amp;equip%5B4%5D=<?=$w_4['item']?>&amp;equip%5B5%5D=<?=$w_5['item']?>&amp;equip%5B6%5D=<?=$w_6['item']?>&amp;equip%5B7%5D=<?=$w_7['item']?>&amp;equip%5B8%5D=<?=$w_8['item']?>" alt=""></a>
</div>

<?
}
?>
<?
if($i['access'] == 3)
{
?>
   <div class="dotted"></div>
    <div class="block color5">
        <img src="/images/icons/privilege.png" width="16" height="16" alt="">        Администратор    </div>

<?
}
if($i['access'] == 2)
{
?>
   <div class="dotted"></div>
    <div class="block color8">
        <img src="/images/icons/privilege.png" width="16" height="16" alt=""> Старший модератор    </div>

<?

}
?>
<?
if($i['access'] == 1)
{
?>
    <div class="dotted"></div>
    <div class="block color7">

        <img src="/images/icons/privilege.png" width="16" height="16" alt="">        Модератор    </div>


<?

}
?>



<div class="line"></div>


<div class="menu">

<?
$ban = mysql_fetch_array(mysql_query('SELECT * FROM `ban` WHERE `user` = "'.$i['id'].'"'));
if($ban['user'] && $ban['time'] > time()){
?>
        <div class="block">
        <img src="/images/icons/cross.png" width="16" height="16" alt="">        <span class="s125 red">Заблокирован до <?=(date('d ', $ban['time']) . $monthes[(date('n',$ban['time']))] . date(',  H:i. ', $ban['time']));?></span></div>
    <div class="line"></div>
<?
}
?>

<?
$band = mysql_fetch_array(mysql_query('SELECT * FROM `banned` WHERE `user` = "'.$i['id'].'"'));
if($band['user'] && $band['time'] > time()){
?>
        <div class="block">
        <img src="/images/icons/cross.png" width="16" height="16" alt="">        <span class="s125 red">Блок <?=(date('d ', $band['time']) . $monthes[(date('n',$band['time']))] . date(',  H:i. ', $band['time']));?></span>
</div>
    <div class="line"></div>
<?
}
?>

<?

  $equips = 0;

  if($i['w_1']) {
    $equips++;
  }
  if($i['w_2']) {
    $equips++;
  }
  if($i['w_3']) {
    $equips++;
  }
  if($i['w_4']) {
    $equips++;
  }
  if($i['w_5']) {
    $equips++;
  }
  if($i['w_6']) {
    $equips++;
  }
  if($i['w_7']) {
    $equips++;
  }
  if($i['w_8']) {
    $equips++;
  }

?>


<?
  if(!$i_clan_memb && $clan && $clan_memb['rank'] >= 0) {

    if(mysql_result(mysql_query('SELECT COUNT(*) FROM `clan_invite` WHERE `user` = "'.$i['id'].'" AND `clan` = "'.$clan['id'].'"'),0) == 0) {

?>
  <li><a href='/user/<?=$i['id']?>/?clan_invite=true'><img src='/images/icons/clan.png' alt='*'/> Пригласить в  банду</a></li>
<?

  }

  }

  if($i['id'] == $user['id']) {
}else{
if($user['level']>=20){
?>

<li><a href="/gifts/<?=$i['id']?>/"><img src="/images/icons/gift.png" width="16" height="16" alt=""> Отправить подарок</a></li>
<?


}



}
?>
<li><a href="/equip/<?=$i['id']?>/"><img src="/images/icons/equip.png" width="16" height="16" alt=""> Снаряжение <span class="white">
        (<?=$equips?>/8)</span></a></li>


<?
$cu = mysql_fetch_array(mysql_query('SELECT * FROM `quest` WHERE `user` = "'.$i['id'].'"'));
  if($i['id'] == $user['id']) {
}else{
?>

<li><a href="/mail/<?=$i['id']?>/"><img src="/images/icons/mail.png" width="16" height="16" alt=""> Черкануть маляву</a></li>
<?if($user['level']>=60){
?>
<li><a href="/daily/<?=$i['id']?>/"><img src="/images/icons/dailyQuest.png" width="16" height="16" alt=""> Срочняки <span class='white'>(<?=$ach = $cu['bunt']+$cu['go']+$cu['are']+$cu['boss4']+$cu['bos7']+$cu['bos10']+$cu['bosy2']+$cu['bosy4']+$cu['bosy6']+$cu['are1']+$cu['bossy3']+$cu['bossy5']?> из 12)</span></a></li>
<?}?>
<li><a href="/gift/<?=$i['id']?>/"><img src="/images/icons/gift.png" width="16" height="16" alt=""> Подарок <span class='white'>(<?=n_f(mysql_result(mysql_query('SELECT COUNT(*) FROM `gifts` WHERE `id_user` = "'.$i['id'].'"'),0))?>)</span>
</a></li>
<?
}
  if($i['id'] == $user['id']) {
?>

 <li><a href='/inv/bag/'> <img src='/images/icons/bag.png'  width='16' height='16' alt=''/> Тумбочка<span class="white"> (<?=mysql_result(mysql_query('SELECT COUNT(`id`) FROM `inv` WHERE `user` = "'.$user['id'].'" AND `equip` = "0" AND `place` = "0"'),0)?>/50) </span><?=(mysql_result(mysql_query('SELECT COUNT(*) FROM `inv` WHERE `user` = "'.$user['id'].'" AND `equip` = "0" AND `place` = "0" AND `new` = "0"'),0) > 0 ? '<font color=\'#30c030\'>(+)</font>':'')?> </a></li>
<?if($user['level']>=60){
?>
<li><a href="/daily/<?=$i['id']?>/"><img src="/images/icons/dailyQuest.png" width="16" height="16" alt=""> Срочняки <span class='white'>(<?=$ach = $cu['bunt']+$cu['go']+$cu['are']+$cu['boss4']+$cu['bos7']+$cu['bos10']+$cu['bosy2']+$cu['bosy4']+$cu['bosy6']+$cu['are1']+$cu['bossy3']+$cu['bossy5']?> из 12)</span></a></li>
<?}?>
<li><a href="/mail"><img src="/images/icons/mail.png" width="16" height="16" alt=""> Малявы </a></li>
<li><a href="/gift/<?=$i['id']?>/"><img src="/images/icons/gift.png" width="16" height="16" alt=""> Подарок <span class='white'>(<?=n_f(mysql_result(mysql_query('SELECT COUNT(*) FROM `gifts` WHERE `id_user` = "'.$i['id'].'"'),0))?>)</span>
</a></li>

</div>
<div class="dotted"></div>
<div class="block">
<?
  }
?>
<div class="block">
    <div>
    <img src="/images/icons/currentHealth.png" width="16" height="16" alt=""> Здоровье: <?=$i['vit']?>    </div>
                                                        
    <div>
    <img src="/images/icons/damage.png" width="16" height="16" alt=""> Сила: <?=$i['str']?>    </div>
                                            
    <div>
    <img src="/images/icons/armor.png" width="16" height="16" alt=""> Защита: <?=$i['def']?>    </div>
                                            
    <div>
    <img src="/images/icons/currentEnergy.png" width="16" height="16" alt=""> Энергия: <?=$i['mana']?>    </div>
                                                                    <div class="m3"></div>            
  


            </div>
</div>
<?

  if($i['id'] == $user['id']) {
?>
<div class="dotted"></div>

<div class="block">
        <img src="/images/icons/experience.png" width="16" height="16" alt=""> Авторитет:  <?=$i['exepy']?>            /  <?=_exp($i['level'])?>        <br/>    <img src="/images/icons/silver.png" width="16" height="16" alt=""> Рубли:  <?=$i['s']?>    <br/>    <img src="/images/icons/gold.png" width="16" height="16" alt=""> Сахар:  <?=$i['g']?>    <br/>    <img src="/images/icons/donate.png" width="16" height="16" alt="">  <?=$i['d']?></div>


    <div class="dotted"></div>
    <div class="menu">                <li><a href="/vip?nocache=1872144541"><img src="/images/icons/crown.png" width="16" height="16" alt=""> Пахан ТБ </a></li></div>
    <div class="dotted"></div>
    <div class="menu">        <li><a href="/train?nocache=4635677774"><img src="/images/icons/train.png" width="16" height="16" alt=""> Качалка</a></li></div>
    <div class="dotted"></div>
<div class="menu"><li><a href="/ability?nocache=262410348"> <img src="/images/icons/ability.png" width="18" height="18" alt=""> Способности <span class='white'>(<?=$i['lvl_sp']?>/20)</span></a></li></div>
    <div class="dotted"></div>
    <div class="menu">        <li><a href="/settings/"><img src="/images/icons/settings.png" width="16" height="16" alt=""> Настройки</a></li></div>

<div class="dotted"></div>
 <div class="menu"><li><a href='/chest/user/'> <img src='/images/icons/bag.png'  width='16' height='16' alt=''/> Мои сундуки</a></li></div><div class="dotted"></div>
<img src="/images/icons/right_blue.png" alt=""/> Игровое время: <span style="color:khaki"><?=_times($i['timon'])?></span><br/>
<div class="dotted"></div>
<div class="block">

    <img src="/images/icons/bulb_1.png" width="16" height="16" alt="">    ID: <?=$i['id']?>,
            <span class="green"><?=time_last($i['online'])?>
</span>
    </div></div>


<?

  }
  else
  {

?>
<div class="dotted"></div>

<div class="block">
        <img src="/images/icons/experience.png" width="16" height="16" alt=""> Авторитет:  <?=$i['exepy']?>            /   <?=_exp($i['level'])?>
       <br/>    <img src="/images/icons/silver.png" width="16" height="16" alt=""> Рубли:  <?=$i['s']?>
</div>
<div class='list'>

<div class="dotted"></div>
<img src="/images/icons/right_blue.png" alt=""/> Игровое время: <span style="color:khaki"><?=_times($i['timon'])?></span><br/>
<div class="dotted"></div>
<div class="block">

    <img src="/images/icons/bulb_1.png" width="16" height="16" alt="">    ID: <?=$i['id']?>,  <span class=""><?=time_last($i['online'])?>
</span>
    </div></div>
<?
if($user['access']>=1){
?>

<div class="dotted"></div>
<div class="menu">
  <li>
    <a href='/golds/<?=$i['id'];?>/'/> <img src="/images/icons/right_blue.png" width="16" height="16" alt=""> Лог ресурсов</a>
  </li>
  <li>
    <a href='/banlog/<?=$i['id'];?>/'/> <img src="/images/icons/right_blue.png" width="16" height="16" alt=""> История нарушения</a>
  </li>
  <li>
    <a href='/adm/clon/?id=<?=$i['id']?>'/> <img src="/images/icons/right_blue.png" width="16" height="16" alt=""> Мультоводство</a>
  </li>
</div>
<?
}
if($user['access']>=2){
  ?>

<div class="dotted"></div>
<div class="block">
 <center><font color='white'> Информация</center></font>

<img src="/images/icons/ability.png" width="16" height="16" alt=""> способности:  (<?=$i['lvl_sp']?>/20)    <br/>
 <img src="/images/icons/key.png" width="16" height="16" alt=""> Ключи:  <?=$i['vor']?>    <br/>
   <img src="/images/icons/gold.png" width="16" height="16" alt=""> Сахар:  <?=$i['g']?>    <br/>    <img src="/images/icons/donate.png" width="16" height="16" alt=""> Сгущёнка: <?=$i['d']?>
<br/>
<img src="/images/icons/right_blue.png" width="16" height="16" alt=""> IP: <?=$i['ip'];?><br/>
<img src="/images/icons/right_blue.png" width="16" height="16" alt="">Получил Подарок =
<?=($i['podarok_vsem'] == 0 ? 'нет':'да')?><br/>

<img src="/images/icons/right_blue.png" width="16" height="16" alt=""> ua: <?=$i['ua'];?><br/>
<img src="/images/icons/right_blue.png" width="16" height="16" alt=""> последние действия (<?=time_adm($i['online'])?>
)
<br/>
</div>

<div class="dotted"></div>
<div class="menu">
  <li>
    <a href='/admin/edit_access.php?val=<?=$i['id'];?>'/> <img src="/images/icons/right_blue.png" width="16" height="16" alt=""> Редактировать права</a>
  </li>
</div>
  <?
}
?>

</div>
<?
}

include './system/f.php';

?>