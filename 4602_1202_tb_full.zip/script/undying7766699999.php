<?php
$sql_host="localhost";
$sql_id="starkkga_lopppuu";
$sql_pass="lopyyy123";
$sql_db="starkkga_lopppuu";
$link = @mysql_connect ("$sql_host", "$sql_id", "$sql_pass") or die ("Нема конекта");
$link2 = @mysql_select_db("$sql_db") or die ("aaa");
mysql_query("SET NAMES 'utf8'");
$query = mysql_query("SELECT * FROM `users`");
while($user = mysql_fetch_assoc($query)){
/*распределим по лигам имеющихся игроков, тут измените по своим параметрам в зависимости от уровней у вас*/	

$battle = mysql_query('SELECT * FROM `undying` WHERE `start` = "0"');
  $battle = mysql_fetch_array($battle);  

$time=3600;
mysql_query('INSERT INTO `undying` (`time`,`lvl`) VALUES ("'.(time() + $time).'","1")');

mysql_query('INSERT INTO `undying` (`time`,`lvl`) VALUES ("'.(time() + $time).'","2")');

mysql_query('INSERT INTO `undying` (`time`,`lvl`) VALUES ("'.(time() + $time).'","3")');


mysql_query('INSERT INTO `undying` (`time`,`lvl`) VALUES ("'.(time() + $time).'","4")');

mysql_query('INSERT INTO `undying` (`time`,`lvl`) VALUES ("'.(time() + $time).'","5")');

mysql_query('INSERT INTO `undying` (`time`,`lvl`) VALUES ("'.(time() + $time).'","6")');

mysql_query('INSERT INTO `undying` (`time`,`lvl`) VALUES ("'.(time() + $time).'","7")');

  if($battle['time'] <= time()) {
    mysql_query('UPDATE `undying` SET `start` = "1", `time` = "'.(time() + (240)).'" WHERE `id` = "'.$battle['id'].'"');
}


}
?>
