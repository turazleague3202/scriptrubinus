<?
    
    include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';
    
if(!$user) {

  header('location: /');
    
exit;

}
 if($user['access'] <4) {

}else{

$_SESSION['not']='<div class="alert"><div>                Ведутся тех.работы!</div></div>';
header('location: /menu?'.$udet.'');
    exit;

}

    $title = 'Тренировка';


include './system/h.php'; 

$sil = 10 + ($user['_str'] * 180)*2;
$saxar = 4 + ($user['_str'] * 10);
if(isset($_GET['str'])) {
$random = rand(4999,5999);



if($saxar <$user['g'] && $sil <$user['s']){

}else{

$_SESSION['not'] = '<div class="alert">
    <div class="color1 s125">Не хватает Ресурсов</div>
    <div class="a_separator"></div>
</div>';
header('location: ?'.$udet.'');
exit;
}

if($user['_str'] >= 80) {

}else{
        mysql_query('UPDATE `users` SET `str` =   `str` + "'.$ky = 15 + ($user['_str'] * 17).'", `_str` =  `_str` + 1, `skill` = `skill` + 1 WHERE `id` = "'.$user['id'].'"');
    mysql_query('UPDATE `users` SET `s` = "'.($user['s']-$sil).'", `g` = "'.($user['g']-$saxar).'" WHERE `id` = "'.$user['id'].'"');
$_SESSION['not'] = '<div class="alert"><div><div class="s125 green">Параметр успешно прокачен!</div>
<div class="a_separator"></div>
    Прокачка: +'.$ky = 15 + ($user['_str'] * 17).'<img src="/images/icons/damage.png" width="16" height="16" alt=""></div></div><div class="alert_bottom"></div> ';
}
header('location: /train.php?'.$random);
}


$sil2 = 10 + ($user['_vit'] * 180)*2;
$saxar2 = 4 + ($user['_vit'] * 10);
if(isset($_GET['hp'])) {
$random = rand(4999,5999);
if($saxar2 < $user['g'] && $sil2 <$user['s']){
}else{
$_SESSION['err'] = '<div class="alert">
    <div class="color1 s125">Не хватает Ресурсов</div>
    <div class="a_separator"></div>
</div>';
header('location: ?'.$udet.'');
exit;
}
if($user['_vit'] >= 80) {
}else{
        mysql_query('UPDATE `users` SET `vit` =   `vit` + "'.$khp = 15 + ($user['_vit'] * 17).'", `_vit` =  `_vit` + 1, `skill` = `skill` + 1 WHERE `id` = "'.$user['id'].'"');
    mysql_query('UPDATE `users` SET `s` = "'.($user['s']-$sil2).'", `g` = "'.($user['g']-$saxar2).'" WHERE `id` = "'.$user['id'].'"');
$_SESSION['not'] = '<div class="alert"><div><div class="s125 green">Параметр успешно прокачен!</div>
<div class="a_separator"></div>
    Прокачка: +'.$khp = 15 + ($user['_vit'] * 17).'<img src="/images/icons/currentHealth.png" width="16" height="16" alt=""></div></div><div class="alert_bottom"></div> ';
}
header('location: /train.php?'.$random);
}

$sil3 = 10 + ($user['_def'] * 180)*2;
$saxar3 = 4 + ($user['_def'] * 10);
if(isset($_GET['dem'])) {
$random = rand(4999,5999);
if($sil3 < $user['s'] && $saxar3 < $user['g']){
}else{
$_SESSION['err'] = '<div class="alert">
    <div class="color1 s125">Не хватает Ресурсов</div>
    <div class="a_separator"></div>
</div>';
header('location: ?'.$udet.'');
exit;
}
if($user['_def'] >= 80) {
}else{
        mysql_query('UPDATE `users` SET `def` =   `def` + "'.$kdef = 15 + ($user['_def'] * 17).'", `_def` =  `_def` + 1, `skill` = `skill` + 1 WHERE `id` = "'.$user['id'].'"');
    mysql_query('UPDATE `users` SET `s` = "'.($user['s']-$sil3).'", `g` = "'.($user['g']-$saxar3).'" WHERE `id` = "'.$user['id'].'"');
$_SESSION['not'] = '<div class="alert"><div><div class="s125 green">Параметр успешно прокачен!</div>
<div class="a_separator"></div>
    Прокачка: +'.$kdef = 15 + ($user['_def'] *17).'<img src="/images/icons/armor.png" width="16" height="16" alt=""></div></div><div class="alert_bottom"></div> ';
}
header('location: /train.php?'.$random);
}

$sil4 = 10 + ($user['_mana'] * 180)*2;
$saxar4 = 4 + ($user['_mana'] * 10);
if(isset($_GET['eny'])) {
$random = rand(4999,5999);
if($sil4 < $user['s'] && $saxar4 < $user['g']){
}else{
$_SESSION['err'] = '<div class="alert">
    <div class="color1 s125">Не хватает Ресурсов</div>
    <div class="a_separator"></div></div>';
header('location: ?'.$udet.'');
exit;
}
if($user['_mana'] >= 80) {
}else{
        mysql_query('UPDATE `users` SET `mana` =   `mana` + 35, `_mana` =  `_mana` + 1, `skill` = `skill` + 1 WHERE `id` = "'.$user['id'].'"');
    mysql_query('UPDATE `users` SET `s` = "'.($user['s']-$sil4).'", `g` = "'.($user['g']-$saxar4).'" WHERE `id` = "'.$user['id'].'"');
$_SESSION['not'] = '<div class="alert"><div><div class="s125 green">Параметр успешно прокачен!</div>
<div class="a_separator"></div>
    Прокачка: +35<img src="/images/icons/currentEnergy.png" width="16" height="16" alt=""></div></div><div class="alert_bottom"></div> ';
}
header('location: /train.php?'.$random);
}

 
?>
                         
    <div class="content"><div class="block center color3 s125">Качалка</div>
            <div class="line"></div>    <div class="block">
        <div class="left">
    <div>
    <img src="/images/icons/currentHealth.png" width="16" height="16" alt=""> Здоровье: <?=$user['vit']?>    </div>
        </div>
        <div>&nbsp;(<?=$user['_vit']?>/80)</div>
        <div class="clear"></div>
<?
  $_vit_progress = round(100 / (80 / $user['_vit']));
?>
        <div class="m3"><div style="width: 50%; height: 6px"
            class="progress-white">
            <div style="width: <?=$_vit_progress?>%; height: 6px" class="progress-green"></div></div></div>
                    <ul class="small bold">
<?
    $kv = 15 + ($user['_vit'] * 17);
?>
                <li>Прокачка: +<?=$kv?>                    <img src="/images/icons/currentHealth.png" width="16" height="16" alt="">                </li>
            </ul>
            </div>
    <div class="dotted"></div>
<?
$sil2 = 10 + ($user['_vit'] * 180)*2;
$saxar2 = 4 + ($user['_vit'] * 10);
  if($user['_vit'] < 80) {
?>
            <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="?hp">Прокачать за    <img src="/images/icons/silver.png" width="16" height="16" alt=""> <?=$sil2?>  <img src="/images/icons/gold.png" width="16" height="16" alt=""> <?=$saxar2?></a></span> </span>        </div>
        <div class="dotted"></div>
<?
  }
?>
        <div class="block">
        <div class="left">
    <div>
    <img src="/images/icons/damage.png" width="16" height="16" alt=""> Сила: <?=$user['str']?>    </div>
        </div>
        <div>&nbsp;(<?=$user['_str']?>/80)</div>
        <div class="clear"></div>
<?
  $_str_progress = round(100 / (80 / $user['_str']));
?>
        <div class="m3"><div style="width: 50%; height: 6px"
            class="progress-white">
            <div style="width: <?=$_str_progress?>%; height: 6px" class="progress-green"></div></div></div>
                    <ul class="small bold">
<?
    $ky = 15 + ($user['_str'] * 17);
?>
                <li>Прокачка: +<?=$ky?>                    <img src="/images/icons/damage.png" width="16" height="16" alt="">                </li>
            </ul>
            </div>
    <div class="dotted"></div>
<?
$sil = 10 + ($user['_str'] * 180)*2;
$saxar = 4 + ($user['_str'] * 10);
  if($user['_str'] < 80) {
?>
            <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="?str">Прокачать за     <img src="/images/icons/silver.png" width="16" height="16" alt=""> <?=$sil?>  <img src="/images/icons/gold.png" width="16" height="16" alt=""> <?=$saxar?></a></span> </span>        </div>
        <div class="dotted"></div>
<?
  }
?>
        <div class="block">

        <div class="left">
    <div>
    <img src="/images/icons/armor.png" width="16" height="16" alt=""> Защита: <?=$user['def']?>    </div>
        </div>
        <div>&nbsp;(<?=$user['_def']?>/80)</div>
        <div class="clear"></div>

<?
  $_def_progress = round(100 / (80 / $user['_def']));
?>
        <div class="m3"><div style="width: 50%; height: 6px"
            class="progress-white">
            <div style="width: <?=$_def_progress?>%; height: 6px" class="progress-green"></div></div></div>
                    <ul class="small bold">
<?
    $ko = 15 + ($user['_def'] * 17);
?>
                <li>Прокачка: +   <?=$ko?>    <img src="/images/icons/armor.png" width="16" height="16" alt="">                </li>
            </ul>
            </div>
    <div class="dotted"></div>
<?
$sil3 = 10 + ($user['_def'] * 180)*2;
$saxar3 = 4 + ($user['_def'] * 10);
  if($user['_def'] < 80) {
?>
            <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="?dem">Прокачать за      <img src="/images/icons/silver.png" width="16" height="16" alt=""> <?=$sil3?>  <img src="/images/icons/gold.png" width="16" height="16" alt=""> <?=$saxar3?></a></span> </span>        </div>
        <div class="dotted"></div>
<?
  }
?>
        <div class="block">
        <div class="left">
    <div>
    <img src="/images/icons/currentEnergy.png" width="16" height="16" alt=""> Энергия: <?=$user['mana']?>    </div>
        </div>
        <div>&nbsp;(<?=$user['_mana']?>/60)</div>
        <div class="clear"></div>
<?
  $_mana_progress = round(100 / (60 / $user['_mana']));
?>
        <div class="m3"><div style="width: 50%; height: 6px"
            class="progress-white">
            <div style="width: <?=$_mana_progress?>%; height: 6px" class="progress-green"></div></div></div>
                    <ul class="small bold">
                <li>Прокачка: +35                    <img src="/images/icons/currentEnergy.png" width="16" height="16" alt="">                </li>
            </ul>
            </div>
    <div class="dotted"></div>
<?
$sil4 = 10 + ($user['_mana'] * 180)*2;
$saxar4 = 4 + ($user['_mana'] * 10);
  if($user['_mana'] < 60) {
?>
            <div class="block center">
            <span class="btn_start"><span class="btn_end"><a class="btn" href="?eny">Прокачать за       <img src="/images/icons/silver.png" width="16" height="16" alt=""> <?=$sil4?>  <img src="/images/icons/gold.png" width="16" height="16" alt=""> <?=$saxar4?></a></span> </span>        </div>
        <div class="dotted"></div>
<?
  }
include './system/f.php';

?>