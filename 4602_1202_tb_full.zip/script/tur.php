<?
require_once 'system/common.php';
require_once 'system/functions.php';
require_once 'system/user.php';
$title = 'Турнир';
require_once 'system/h.php';
?>


<div class="content"><div class="block center color3 s125">Турнир лучший Авторитет</div>
            <div class="line"></div>            

<?

$sort = _string($_GET['sort']);



    $max = 10;

  $count = mysql_result(mysql_query('SELECT COUNT(*) FROM `users` WHERE `avtor` > 0'),0);
  $pages = ceil($count/$max);
   $page = _string(_num($_GET['page']));

    if($page > $pages) {
    
   $page = $pages;
    
    }
  
    if($page < 1) {
    
   $page = 1;
    
    }
    
  $start = $page * $max - $max;


  if($page == 1) {
  
    $i = $page - 1;
  
  }
  elseif($page == 2) {
    
    $i = ($page + 9);
  
  }
  else
  {
  
    $i = ($page * 10) - 9;
  
  }

switch($sort) {
    default:
$q = mysql_query('SELECT * FROM `users` WHERE `avtor` > 0 ORDER BY `avtor` DESC LIMIT '.$start.', '.$max.'');
  
      break;
}

  


 while($row = mysql_fetch_array($q)) {

  $i++;

?>
        <div class="dotted"></div>
                        <div class="block">
<?=$i?>. <?
if($row['vip'] == 0){
?>
<img src="/images/icons/<?=$row['r']?>.png" width="16" height="16" alt="">
<?

}
if($row['vip'] == 1){
?>
<img src="/images/icons/vip_<?=($row['r'] == man ? 'woman':'man')?>_<?=$row['r']?>.png" width="16" height="16" alt="">
<?
}
?>
<a href="/user/<?=$row['id']?>/"><span><?=$row['login']?></span></a>      <b> <img src='/images/icons/experience.png' alt=''/> <?=($row['avtor'])?></b>
 
<div class="clear"></div>
</div>



<?
}
?>
   <div class="dotted"></div>
<ul class="pagination"><li class="next"><?=pages('?');?></li></ul>

<div class="dotted"></div>

<ul class="block small">
   <li>
<span class='blue'>Призовые места:</span><br/><div class='medium'>1 место - <img src='/images/icons/gold.png' alt=''/> <span class='bold'>3'000</span><br/>2 место - <img src='/images/icons/gold.png' alt=''/> <span class='bold'>1500</span><br/>3 место - <img src='/images/icons/gold.png' alt=''/> <span class='bold'>1000</span>
</div></li></ul>

<ul class="block small">
   <li>
Турнир лучший Авторитет - начало в Понедельник, окончания в воскресенье по игровому времени 00:00</li></ul>
</div>




<?require_once 'system/f.php';?>

