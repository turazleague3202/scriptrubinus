<?php


include_once 'system/common.php';
include_once 'system/functions.php';
include_once 'system/user.php';
if(!$user) {

  header('location: /');
  exit;

}
$title = 'Барыга';
include_once 'system/h.php';


$amy = mysql_query('SELECT * FROM `amylet` WHERE `user` = "'.$user['id'].'"');  
  $amy = mysql_fetch_array($amy);
if (isset($_GET['start']) && $user['vor']>=1)
{
  $w_chanse = rand($amy['lvl1'],5);

	$chanse = rand(1,30);

	if ($chanse ==8)
	{
$saxr = rand(4,70);
		$_SESSION['not']= '  <div class="alert"><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Вы украли у барыги:</div>
    <img src="/images/icons/gold.png" width="16" height="16" alt=""> Сахар:+'.$saxr.'</div></div><div class="alert_bottom"></div>';
		mysql_query("UPDATE `users` SET `g`=`g`+'$saxr' WHERE `id`='".$user['id']."'");
	}
	elseif($chanse==3)
	{
$rub = rand(1000,8000);
		$_SESSION['not']='<div class="alert"><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Вы украли у барыги:</div>
    <img src="/images/icons/silver.png" width="16" height="16" alt=""> Рубли:+'.$rub.'</div></div><div class="alert_bottom"></div>';
		mysql_query("UPDATE `users` SET `s`=`s`+'$rub' WHERE `id`='".$user['id']."'");
	}
	elseif ($chanse==5) {
		$_SESSION['not']=' <div class="alert"><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Вы украли у барыги:</div>
    <img src="/images/icons/experience.png" width="16" height="16" alt=""> Авторитет:+500</div></div><div class="alert_bottom"></div>';
		mysql_query("UPDATE `users` SET `exp`=`exp`+'500', `exepy`=`exepy`+'500'WHERE `id`='".$user['id']."'");
	}
	elseif ($chanse==2) {
		$_SESSION['not']=' <div class="alert"><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Вы украли у барыги:</div>
    <img src="/images/icons/key.png" width="16" height="16" alt=""> Ключ:+3</div></div><div class="alert_bottom"></div>';
		mysql_query("UPDATE `users` SET `vor`=`vor`+'3' WHERE `id`='".$user['id']."'");
	}elseif ($chanse==9) {
$kly=rand(1,7);
		$_SESSION['not']='  <div class="alert"><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Вы украли у барыги:</div>
    <img src="/images/icons/key.png" width="16" height="16" alt=""> Ключи на Копа:+'.$kly.'</div></div><div class="alert_bottom"></div>';
		mysql_query("UPDATE `users` SET `key2`=`key2`+'$kly' WHERE `id`='".$user['id']."'");
	}elseif ($chanse==12) {
		$_SESSION['not']='  <div class="alert"><div>                                     <div class="blue"><img src="/images/icons/reward.png" width="16" height="16" alt=""> Вы украли у барыги:</div>
    <img src="/images/icons/donate.png" width="16" height="16" alt=""> Сгущёнка:+10</div></div><div class="alert_bottom"></div>';
		mysql_query("UPDATE `users` SET `d`=`d`+'10' WHERE `id`='".$user['id']."'");
	}elseif ($chanse) {
		$_SESSION['not']=' <div class="alert"><div>                                     <div class="blue">Вас поймали</div></div></div><div class="alert_bottom"></div>';

	}

	mysql_query("UPDATE `users` SET `vor`=`vor`-'1' WHERE `id`='".$user['id']."'");

	?>
	<?=$text;?>
	<?

header('location: /vor/?');
  exit;
}

?>

    <div class="content">
    <div class="block center color3 s125"><a href="?">Аршин</a>/ Барыга</div>
            <div class="line"></div>
<div class="block center blue">
    <img src="/images/title/outfit.png" width="150" height="75" alt="">    <div class="blue m3">
        Игрок — это вор, который крадет, не рискуя попасть под суд.
    </div>
</div>

<div class="dotted"></div>


    <div class="block center s125">
У вас  <img src="/images/icons/key.png" width="16" height="16" alt=""> <?=$user['vor']?> ключей
    </div>
<?

if ($user['vor']>=1)
{
	?>
   <div class="dotted"></div>
    <div class="block center">
                <span class="btn_start"><span class="btn_end">
<a class="btn" href="?start=<?=$randp = rand(2222,9998)?>">Украсть <img src="/images/icons/key.png" width="16" height="16" alt=""> 1</a>
</span> </span>    </div>

<?
}
else
{
	?>
    <div class="dotted"></div>
    <div class="block center">
                <span class="btn_start"><span class="btn_end"><a class="btn" href="#">У вас нет ключей <img src="/images/icons/key.png" width="16" height="16" alt=""></a></span> </span>    </div>
	<?
}

?>

       <div class="line"></div>
<ul class="block small">
    <li class="color2">У барыги можно украсть сахар, рубли, авторитет и ключи.</li>
</ul></div>
</div>
<?

include_once 'system/f.php';