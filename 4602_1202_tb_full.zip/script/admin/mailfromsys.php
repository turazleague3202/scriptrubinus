<?
include_once '../system/common.php';
include_once '../system/functions.php';
include_once '../system/user.php';
if(!$user OR $user['access']!='3'){
	header("Location:/");
	exit;
}
$title='Написать с системы';
include_once '../system/h.php';

if(isset($_GET['send'])){
	$nick=_string($_POST['nick']);
	$text=_string($_POST['msg']);
	$usto=mysql_fetch_array(mysql_query("SELECT `login`,`id`,`save` FROM `users` WHERE `login`='$nick' and `save`='1'"));
	if(!$usto){
		$_SESSION['light']="Пользователь не найден.";
		header('location:?');
		exit;
	}
	mysql_query("INSERT INTO `mail` SET `from`='2',`to`='".$usto['id']."',`text`='$text',`time`='".time()."'");
	if(mysql_num_rows(mysql_query("SELECT * FrOM `contacts` WHERE `ho`='2' and `user`='".$usto['id']."'"))==0){
	mysql_query("INSERT INTO `contacts` SET `ho`='2',`user`='".$usto['id']."',`time`='".time()."'"); 
	}else{
	mysql_query("UPDATE `contacts` SET `time`='".time()."' WHERE `ho`='2' and `user`='".$usto['id']."'");	
	}
	$_SESSION['light']="Сообщение доставлено";
	header('location:?');
}
?>
<div class="content">    <div class="block center color3 s125"><?=$title?></div>
 <div class='line'></div>
<left>
<form action='?send' method='post'/>
<input type='text' name='nick' placeholder='Кому Ник'/><br/>
<textarea type='text' name='msg' placeholder='Введите Ваше сообщение' rows='4' cols='50'/></textarea><br/>
<input type='submit' value='Отправить'/>
</form>
</left>
</div>
<?
include_once '../system/f.php';
?>