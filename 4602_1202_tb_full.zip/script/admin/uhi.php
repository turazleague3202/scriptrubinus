<?
    
    include '../system/common.php';
    
 include '../system/functions.php';
        
      include '../system/user.php';
    
if(!$user OR $user['access']>3 or $user['id'] >1) {

  header('location: /menu');
    
exit;

}



$title = 'Добавить вещь';    

include '../system/h.php';  


$id = _string($_POST['id']);
$w = _string($_POST['w']);
$name = _string($_POST['name']);
$quality = _string($_POST['quality']);
$lvl = _string($_POST['lvl']);

if($id){
 
 mysql_query('INSERT INTO `items` SET `id` = \''.$id.'\', `w` = \''.$w.'\', `name` = \''.$name.'\', `quality` = \''.$quality.'\', `lvl` = \''.$lvl.'\'');
   
 echo ' items';
}
?>
<div class='title'><?=$title?></div>
<div class='line'></div>
<div class='content' align='center'>
</div>
<div class='line'></div>
<div class='content' align='center'>
  <form action='/admin/uhi/' method='post'>
 id:<br/>
  <input name='id' value=''.$id.'' style="width: 90%;"/><br/>
id:<br/>
   <select name='w'>
   <option value='1'>Голова</option>
   <option value='2'>Глаза</option>
   <option value='3'>Шея</option>
   <option value='4'>Торс</option>
   <option value='5'>Правая рука </option>
   <option value='6'>Левая рука</option>
   <option value='7'>Ноги</option>
   <option value='8'>Стопы</option>
   </select><br/>
 название вещий:<br/>
  <input name='name' value=''.$name.'' style="width: 90%;"/><br/>
 качество:<br/>
  <select name='quality'>
   <option value='1'>Старое</option>
   <option value='2'>Обычное</option>
   <option value='3'>Редкое</option>
   <option value='4'>Очень редкое</option>
   <option value='5'>Великолепное</option>
   <option value='6'>Легендарное</option>
   <option value='7'>Божественное</option>    
   <option value='8'>Сверх-божественное</option>
   <option value='9'>Эксклюзивное</option>
   </select><br/>
 уровень:<br/>
    <select name='lvl'>
   <option value='1'> 1 уровень</option>
   <option value='15'> 15 уровень</option>
   <option value='30'> 30 уровень</option>
   <option value='45'> 45 уровень</option>
   <option value='60'> 60 уровень </option>
   <option value='70'> 70 уровень</option>
   <option value='100'> 100 уровень</option>
   </select><br/><br/><br/>


  <input type='submit' value='Сохранить'/><br/>
</form><br/><br/>
</div>
<div class='line'></div>
<div class='list'></div>
<?
include '../system/f.php';

?>