<?
include_once '../system/common.php';
include_once '../system/functions.php';
include_once '../system/user.php';
if(!$user OR $user['access']!='3'){
	header("Location:/");
	exit;
}

$title="Статистика рефералов";
include_once '../system/h.php';

$allrefs=mysql_num_rows(mysql_query("SELECT `id` FROM `ref`"));
$start=abs(intval($_GET['all']));
$all_cycl=mysql_query("SELECT * FROM `ref` ORDER BY `id` DESC LIMIT $start");

?>
<div class="content">    <div class="block center color3 s125"><?=$title?></div>
 <div class='line'></div>
Всего привлечено рефералов : <?=$allrefs;?>
</div>

<div class='line'></div>
<div class="content">

<?

$max = 10;
$count = mysql_result(mysql_query('SELECT COUNT(*) FROM `ref`'),0);
$pages = ceil($count/$max);
$page = _string(_num($_GET['page']));
if($page > $pages) {
$page = $pages;
}
if($page < 1) {
$page = 1;
}
$start = $page * $max - $max;



$q = mysql_query('SELECT `user`,`ho` FROM `ref` ORDER BY `id` DESC LIMIT '.$start.', '.$max.'');
while($ref = mysql_fetch_array($q)) {


$parse_ref=mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id`='".$ref['ho']."'"));
$parse_user=mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id`='".$ref['user']."'"));
if($parse_user['ua']<=$parse_ref['ua'] OR $parse_user['ip']<=$parse_ref['ip']){
$color_m='dred';
$check_m='Мульт';
}else{
$color_m='green';
$check_m='Реферал';
}
  ?>
ID: <a href='/user/<?=$ref['user'];?>/'> <?=$parse_user['login'];?></a><?=$parse_user['ip']?>
<br/>

Referal: <a href='/user/<?=$ref['ho'];?>/'><?=$parse_ref['login']?></a><?=$parse_ref['ip']?>
</br/>

<span class="<?=$color_m;?>"/><?=$check_m;?></span><br/>
<div class='line'></div>
<?
}
?>
 <div class="dotted"></div>
<ul class="pagination"><li class="next"><?=pages('?');?></li></ul>

<div class="dotted"></div>

</div>
<?
include_once '../system/f.php';
?>