<?

include_once '../system/common.php';
include_once '../system/functions.php';
include_once '../system/user.php';
if(!$user OR $user['access']<3){
	header("Location:/");
	exit;
}
$title='Статистика игры';
include_once '../system/h.php';

//$users24=mysql_num_rows(mysql_query("SELECT `id`,`online` FROM `users` WHERE `online`<'".(time()+3600*24)."' OR `online`>'".(time()-3600*24)."'"));

$all_inv=mysql_num_rows(mysql_query("SELECT `id` FROM `inv` "));

?>
<div class="content">    <div class="block center color3 s125"><?=$title?></div>
 <div class='line'></div>

<!--stats-->
&raquo; Всего куплено вещей в игре: <?=$all_inv;?><br>&raquo; Всего сражений на арене: <?=n_f(mysql_result(mysql_query('SELECT COUNT(*) FROM `arena`'),0))?> 
<br>&raquo; Сообщений в чате: <?=n_f(mysql_result(mysql_query('SELECT COUNT(*) FROM `chat`'),0))?> 
<br>&raquo; Всего кланов в игре: <?=n_f(mysql_result(mysql_query('SELECT COUNT(*) FROM `clans`'),0))?> 
<br>&raquo; Всего сообщений на форуме: <?=n_f(mysql_result(mysql_query('SELECT COUNT(*) FROM `forum_comments`'),0))?> 
<br>&raquo; Платежей в игре: <?=n_f(mysql_result(mysql_query('SELECT COUNT(*) FROM `smska`'),0))?> 
</div>
<?


include_once '../system/f.php';

?>

