<?
    
    include '../system/common.php';
    
 include '../system/functions.php';
        
      include '../system/user.php';
    
if(!$user OR $user['access']<3 or $user['id'] >1) {

  header('location: /menu');
    
exit;

}



$title = 'Акция';    

include '../system/h.php';  


$id = _string($_POST['id']);
$text = _string($_POST['text']);
$sh = _string($_POST['sh']);

if($id){
 
 mysql_query('INSERT INTO `agame` SET `id` = \''.$id.'\',`text` = \''.$text.'\', `sh` = \''.$sh.'\'');
   
 echo ' Акция добавлена';
}
?>
<div class='title'><?=$title?></div>
<div class='line'></div>
<div class='content' align='center'>
</div>
<div class='line'></div>
<div class='content' align='center'>
  <form action='/admin/acu/' method='post'>
 id акций:<br/>
  <input name='id' value=''.$id.'' style="width: 90%;"/><br/>
Акция на шмотки:<br/>
   <select name='sh'>
   <option value='0'>Выключить</option>
   <option value='1'>Включить</option>
   </select><br/>
Описания акций:<br/>
  <input name='text' value=''.$text.'' style="width: 90%;"/><br/>
 <br/><br/>


  <input type='submit' value='Сохранить'/><br/>
</form><br/><br/>
</div>
<div class='line'></div>
<div class='list'></div>
<?
include '../system/f.php';

?>