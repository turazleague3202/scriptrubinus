<?

require_once '../system/common.php';
require_once '../system/functions.php';
require_once '../system/user.php';
if(!$user OR $user['access']<'2' OR $user['access']<'3'){
	header("Location:/");
	exit;
}

$title='Редактор прав';
require_once '../system/h.php';

$acc = array("Пользователь","Модератор","Администратор");
$val=abs(intval($_GET['val']));
$edit=mysql_fetch_array(mysql_query("SELECT * FROM `users` WHERE `id`='$val'"));

if($edit['id']==1){

	$_SESSION['not']="Нельзя редактировать гл.Администратора!";
	header("Location:/");
	exit;

}

if(isset($_GET['change']) && !empty($val) && isset($edit) ){

	$_access=_string(_num($_POST['access']));
	mysql_query("UPDATE `users` SET `access`='$_access' WHERE `id`='$val'");
	$_SESSION['not']="Права игрока успешно изменены.";
	header("Location:/user/".$edit['id']."");
	exit;

}

if(!$edit){
	$_SESSION['not']="Игрок не найден.";
	header("Location:/adm/");
	exit;
}



?>
<div class="content">    <div class="block center color3 s125"><?=$title?></div>
 <div class='line'></div>
<form action='/admin/edit_access.php?val=<?=$edit['id'];?>&amp;change' method='post'/>
	ID игрока:
	<input type='text' value='<?=$edit['id'];?>' disabled/>
	<br/>
	<?
	for($i=0;$i<4;$i++){
		?>
		<?
	}
	?>
	<span class='dred'/> Выдать права: </span>
<select class="form-control" name="access">
<? if($user['access'] == 3){?><option value="3">Администратор</option>
<?}?>
<? if($user['access'] == 3){?><option value="2">Старший модератор</option>
<?}?>
<option value="1">Модератор</option>
<option value="0">Пользователь</option>

</select>
	
	<br/>
	<input class='btn' type='submit' value='Изменить'/>
	</form/>


<div class="dotted"></div>
<div class="menu">
  <li><a href='/user/<?=$edit['id'];?>'><img src='/images/icons/right_blue.png' alt='*'/> Вернуться в камеру</a></li>
</div>

</div>
<?

require_once '../system/f.php';

?>