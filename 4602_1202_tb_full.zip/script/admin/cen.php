<?
    
    include '../system/common.php';
    
 include '../system/functions.php';
        
      include '../system/user.php';
    
if(!$user OR $user['access']>3 or $user['id'] >1) {

  header('location: /menu');
    
exit;

}



$title = 'добавить цену вещий';    

include '../system/h.php';  


$id = _string($_POST['id']);
$quality = _string($_POST['quality']);
$cost = _string($_POST['cost']);
$cost2 = _string($_POST['cost2']);
$cost3 = _string($_POST['cost3']);
$cost4 = _string($_POST['cost4']);
$_str = _string($_POST['_str']);
$_vit = _string($_POST['_vit']);
$_def = _string($_POST['_def']);

if($id){
 
 mysql_query('INSERT INTO `shopy` SET `id` = \''.$id.'\', `quality` = \''.$quality.'\', `cost` = \''.$cost.'\', `cost2` = \''.$cost2.'\',`cost3` = \''.$cost3.'\',`cost4` = \''.$cost4.'\',`_str` = \''.$_str.'\', `_vit` = \''.$_vit.'\', `_def` = \''.$_def.'\'');
   
echo ' shop';
 
}

echo '<div class=\'title\'>'.$title.'</div>
<div class=\'line\'></div>
<div class=\'content\' align=\'center\'>
</div>
<div class=\'line\'></div>
<div class=\'content\' align=\'center\'>
  <form action=\'/admin/cen/\' method=\'post\'>
 id:<br/>
  <input name=\'id\' value=\''.$id.'\' style="width: 90%;"/><br/>';
?>
качество:<br/>
   <select name='quality'>
   <option value='1'>Старое</option>
   <option value='2'>Обычное</option>
   <option value='3'>Редкое</option>
   <option value='4'>Очень редкое</option>
   <option value='5'>Великолепное</option>
   <option value='6'>Легендарное</option>
   <option value='7'>Божественное</option>    
   <option value='8'>Сверх-божественное</option>
 <option value='9'>Эксклюзивный</option>
   </select><br/>
<?
echo 'цена:<br/>
  <input name=\'cost\' value=\''.$cost.'\' style="width: 90%;"/><br/>
цена2:<br/>
  <input name=\'cost2\' value=\''.$cost2.'\' style="width: 90%;"/><br/>
цена3 акция:<br/>
  <input name=\'cost3\' value=\''.$cost3.'\' style="width: 90%;"/><br/>
цена4 акция:<br/>
  <input name=\'cost4\' value=\''.$cost4.'\' style="width: 90%;"/><br/>
сила:<br/>
  <input name=\'_str\' value=\''.$_str.'\' style="width: 90%;"/><br/>
жизнь:<br/>
  <input name=\'_vit\' value=\''.$_vit.'\' style="width: 90%;"/><br/>
защита:<br/>
  <input name=\'_def\' value=\''.$_def.'\' style="width: 90%;"/><br/>';
?>
<?

  echo '<br/><br/>
  <input type=\'submit\' value=\'Сохранить\'/>
</form><br/><br/>
</div>
<div class=\'line\'></div>
<div class=\'list\'></div>';
  
include '../system/f.php';

?>