<?
    
    include '../system/common.php';
    
 include '../system/functions.php';
        
      include '../system/user.php';
    
		if($user['access'] < 3 or $user['id'] >1) {
			header('location: /adm/');
			exit;
		}
		$title = 'Редактирование Акций';
		include '../system/h.php';
		if(isset($_GET['yes'])){
		echo _string($_POST['id']);
			mysql_query('UPDATE `agame` SET `text` = \''._string($_POST['text']).'\', `sh` = '._string(_num($_POST['sh'])).', `tren` = '._string(_num($_POST['tren'])).' WHERE `id` = '._string(_num($_GET['yes'])).' LIMIT 1');
			header('location: /admin/auc/');
			exit;
		}
		if(isset($_POST['submit']) & !empty($_POST['id'])){
			$acc = mysql_fetch_array(mysql_query('SELECT * FROM `agame` WHERE `id` = '._string(_num($_POST['id'])).' LIMIT 1'));
			?>
<div class="content">    <div class="block center color3 s125"><?=$title?></div>
 <div class='line'></div>
				<form action='/admin/auc/yes/<?=_string(_num($_POST['id']))?>/' method='post'>
					Описание:
					<br/>
<textarea class='form-control' name='text' rows='10' value='<?=$acc['text']?>'><?=$acc['text']?></textarea>
					<br/>
					Акция на шмотки:
					<br/>
					<input name='sh' value='<?=$acc['sh']?>'/> 
					<br/>
					Акция на:
					<br/>
					<input name='tren' value='<?=$acc['tren']?>'/> 
					<br/>

					<br/>
       <span class="btn_start"><span class="btn_end">
					<input type='submit' class='btn' name='submit' value='Сохранить'/>
 </span> </span>
				</form>
			</div>
			<?
		}
		else{
		?>
		<div class="content">
			<form action='/admin/auc/' method='post'>
				ID акций:
				<br/>
				<input name='id'/> 
				<br/>
       <span class="btn_start"><span class="btn_end">
				<input type='submit' class='btn' name='submit' value='Продолжить'/>
</span> </span>
			</form>
<div class="dotted"></div>
<div class="menu">
  <li><a href='/adm/'><img src='/images/icons/right_blue.png' alt='*'/> вернуться к панели</a></li>
</div>
		</div>
		
		<?
		}
include '../system/f.php';

?>