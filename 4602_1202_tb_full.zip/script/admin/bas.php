<?
    
    include '../system/common.php';
    
 include '../system/functions.php';
        
      include '../system/user.php';
    
if(!$user OR $user['access']==3 or $user['id'] >1) {

  header('location: /');
    
exit;

}



$title = 'Добавить босса';    

include '../system/h.php';  


$id = _string($_POST['id']);
$name = _string($_POST['name']);
$quality = _string($_POST['quality']);
$str = _string($_POST['str']);
$hp = _string($_POST['hp']);
$def = _string($_POST['def']);
$gold = _string($_POST['gold']);
$exp = _string($_POST['exp']);
$lvl = _string($_POST['lvl']);
if($id) {
 
 mysql_query('INSERT INTO `basement` SET `id` = \''.$id.'\', `name` = \''.$name.'\', `quality` = \''.$quality.'\', `str` = \''.$str.'\', `hp` = \''.$hp.'\', `def` = \''.$def.'\', `gold` = \''.$gold.'\', `exp` = \''.$exp.'\', `lvl` = \''.$lvl.'\'');

echo 'Босс добавлен';
}

echo '<div class=\'title\'>'.$title.'</div>
<div class=\'line\'></div>
<div class=\'content\' align=\'center\'>
</div>
<div class=\'line\'></div>
<div class=\'content\' align=\'center\'>
  <form action=\'/bas/\' method=\'post\'>
 id:<br/>
  <input name=\'id\' value=\''.$id.'\' style="width: 90%;"/><br/>
имя босса:<br/>
  <input name=\'name\' value=\''.$name.'\' style="width: 90%;"/><br/>';
?>
уровень сложности босса:<br/>
   <select name='quality' value=''.$quality.''>
   <option value='1'>лёгкие</option>
   <option value='2'>средние</option>
   <option value='3'>сложные</option>
   <option value='4'>сверх-сложные</option>
   <option value='5'>нет</option>
   </select><br/>
<?
echo 'сила босса:<br/>
<input name=\'str\' value=\''.$str.'\' style="width: 90%;"/><br/>
жизнь босса:<br/>
<input name=\'hp\' value=\''.$hp.'\' style="width: 90%;"/><br/>
защита босса:<br/>
<input name=\'def\' value=\''.$def.'\' style="width: 90%;"/><br/>
монеты:<br/>
<input name=\'gold\' value=\''.$gold.'\' style="width: 90%;"/><br/>
опыт:<br/>
<input name=\'exp\' value=\''.$exp.'\' style="width: 90%;"/><br/>
уровень босса:<br/>';
?>
   <select name='lvl' value=''.$lvl.''>
   <option value='1'>1 уровень</option>
   <option value='5'>5 уровень</option>
   <option value='12'>12 уровень</option>
   <option value='15'>15 уровень</option>
   <option value='25'>25 уровень</option>
   <option value='35'>35 уровень</option>
   <option value='50'>50 уровень</option>
   <option value='70'>70 уровень</option>
   <option value='72'>72 уровень</option>
   <option value='75'>75 уровень</option>
   <option value='100'>100 уровень</option>

   </select><br/>
<br/><br/>
<?
  echo '
  <input type=\'submit\' value=\'Сохранить\'/>
</form>
</div><br/><br/>
<div class=\'line\'></div>
<div class=\'list\'></div>';
  
include '../system/f.php';

?>