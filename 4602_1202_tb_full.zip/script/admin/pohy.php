<?
    
    include '../system/common.php';
    
 include '../system/functions.php';
        
      include '../system/user.php';
    
if(!$user OR $user['access']>3 or $user['id'] >1) {

  header('location: /menu');
    
exit;

}



$title = 'Добавить комплект';    

include '../system/h.php';  


$id = _string($_POST['id']);
$quality = _string($_POST['quality']);
$avatar = _string($_POST['avatar']);
$name = _string($_POST['name']);
$w_1 = _string($_POST['w_1']);
$w_2 = _string($_POST['w_2']);
$w_3 = _string($_POST['w_3']);
$w_4 = _string($_POST['w_4']);
$w_5 = _string($_POST['w_5']);
$w_6 = _string($_POST['w_6']);
$w_7 = _string($_POST['w_7']);
$w_8 = _string($_POST['w_8']);

if($id){


 mysql_query('INSERT INTO `complectsy` SET `id` = \''.$id.'\', `quality` = \''.$quality.'\', `name` = \''.$name.'\', `avatar` = \''.$avatar.'\', `w_1` = \''.$w_1.'\', `w_2` = \''.$w_2.'\', `w_3` = \''.$w_3.'\', `w_4` = \''.$w_4.'\', `w_5` = \''.$w_5.'\', `w_6` = \''.$w_6.'\', `w_7` = \''.$w_7.'\', `w_8` = \''.$w_8.'\'');
   
echo ' comlect';
}
 


echo '<div class=\'title\'>'.$title.'</div>
<div class=\'line\'></div>
<div class=\'content\' align=\'center\'>
</div>
<div class=\'line\'></div>
<div class=\'content\' align=\'center\'>
  <form action=\'/admin/pohy/\' method=\'post\'>
 id:<br/>
  <input name=\'id\' value=\''.$id.'\' style="width: 90%;"/><br/>
качество:<br/>';
?>
   <select name='quality'>
   <option value='1'>Старое</option>
   <option value='2'>Обычное</option>
   <option value='3'>Редкое</option>
   <option value='4'>Очень редкое</option>
   <option value='5'>Великолепное</option>
   <option value='6'>Легендарное</option>
   <option value='7'>Божественное</option>    
   <option value='8'>Сверх-божественное</option>
<option value='9'>Эксклюзивное</option>
   </select><br/>
<?
 echo 'название комплекта:<br/>
  <input name=\'name\' value=\''.$name.'\' style="width: 90%;"/><br/>
avatar:<br/>
  <input name=\'avatar\' value=\''.$avatar.'\' style="width: 90%;"/><br/>
 id:<br/>
  <input name=\'w_1\' value=\''.$w_1.'\' style="width: 90%;"/><br/>
 id:<br/>
  <input name=\'w_2\' value=\''.$w_2.'\' style="width: 90%;"/><br/>
 id:<br/>
  <input name=\'w_3\' value=\''.$w_3.'\' style="width: 90%;"/><br/>
 id:<br/>
  <input name=\'w_4\' value=\''.$w_4.'\' style="width: 90%;"/><br/>
 id:<br/>
  <input name=\'w_5\' value=\''.$w_5.'\' style="width: 90%;"/><br/>
 id:<br/>
  <input name=\'w_6\' value=\''.$w_6.'\' style="width: 90%;"/><br/>
 id:<br/>
  <input name=\'w_7\' value=\''.$w_7.'\' style="width: 90%;"/><br/>
 id:<br/>
  <input name=\'w_8\' value=\''.$w_8.'\' style="width: 90%;"/><br/>';
?>
<?

  echo '<br/><br/>
  <input type=\'submit\' value=\'Сохранить\'/>
</form><br/><br/>
</div>
<div class=\'line\'></div>
<div class=\'list\'></div>';
  
include '../system/f.php';

?>