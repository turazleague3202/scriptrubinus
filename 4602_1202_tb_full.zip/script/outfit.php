<?
    
    include './system/common.php';
    
 include './system/functions.php';
         
      include './system/user.php';

if(!$user) {
  header('location: /');
  exit;
}

$title = 'Шмотки';    

include './system/h.php';  

$udet=rand(111111,999999);





$quality = _string(_num($_GET['quality']));
if($quality) {

  if($quality == 1 && $user['level'] < 1 OR $quality == 2 && $user['level'] < 1 OR $quality == 3 && $user['level'] < 1 OR $quality == 4 && $user['level'] < 1 OR $quality == 5 && $user['level'] < 1 OR $quality == 6 && $user['level']  < 1 OR $quality == 7 && $user['level']  < 1 OR $quality == 8 && $user['level']  < 1) {
    
      header('location: /outfit/');
      exit;
    
  }





$itemqualit = array('нет', 'Старый', 'Обычный', 'Редкий', 'Очень редки', 'Великолепное', 'Легендарный', 'Божественный', 'Сверх-Божественный');


echo '   <div class="content"><div class="block center color3 s125"><a href="/outfit?'.$udet.'">Шмот</a>/ '.$itemqualit[$quality].'</div>
            <div class="line"></div>';

  $q = mysql_query('SELECT * FROM `complects` WHERE `quality` = \''.$quality.'\'');    
  while($row = mysql_fetch_array($q)) {



echo '    <div class="block center">
        <a href="/complect/'.$row['id'].'/?'.$udet.'">
                        <img src="/images/m/'.$row['avatar'].'.jpg" alt="">        </a>
    </div>
    <div class="dotted"></div>
    <div class="block center">
        <img src="/images/icons/equip.png" width="16" height="16" alt=""> <a href="/complect/'.$row['id'].'/?'.$udet.'"> '.$row['name'].'</a>
    </div>
    <div class="dotted"></div>
';
 
   
      
  }



}
else
{
 
$sho = mysql_query('SELECT * FROM `agame` WHERE `id` = "1"');
  $sho = mysql_fetch_array($sho);
echo '                          
    <div class="content"><div class="block center color3 s125"><a href="/outfit?'.$udet.'">Барыга</a>/ Шмот</div>
            <div class="line"></div>';
if($sho['sh'] <= 0){}else{
echo' <div class="alert">
    <div class="bold green">Акция!</div>
    <div class="a_separator"></div>
    <div class="small color3">
'.$sho['text'].'
</div>
</div>
';}

echo'<div class="block center">
    <img src="/images/title/outfit.png" width="150" height="75" alt="">    <div class="m3 blue">Одним тюрьма - урок суровый <br/>другим же - сладкий перекур</div>
</div>
<div class="dotted"></div>
        <div class="block">
        <img class="left mr8" src="/images/quality/1.png" width="28" height="28" alt="">        <img src="/images/icons/equip.png" width="16" height="16" alt=""> <a href="/outfit/1/?'.$udet.'">Старое        <div class="clear"></div>
    </div>
    <div class="dotted"></div>
        <div class="block">
        <img class="left mr8" src="/images/quality/2.png" width="28" height="28" alt="">        <img src="/images/icons/equip.png" width="16" height="16" alt=""> <a href="/outfit/2/?'.$udet.'">Обычное        <div class="clear"></div>
    </div>
    <div class="dotted"></div>
        <div class="block">
        <img class="left mr8" src="/images/quality/3.png" width="28" height="28" alt="">        <img src="/images/icons/equip.png" width="16" height="16" alt=""> <a href="/outfit/3/?'.$udet.'">Редкое        <div class="clear"></div>
    </div>
    <div class="dotted"></div>
        <div class="block">
        <img class="left mr8" src="/images/quality/4.png" width="28" height="28" alt="">        <img src="/images/icons/equip.png" width="16" height="16" alt=""> <a href="/outfit/4/?'.$udet.'">Очень редкое        <div class="clear"></div>
    </div>
    <div class="dotted"></div>
        <div class="block">
        <img class="left mr8" src="/images/quality/5.png" width="28" height="28" alt="">        <img src="/images/icons/equip.png" width="16" height="16" alt=""> <a href="/outfit/5/?'.$udet.'">Великолепное        <div class="clear"></div>
    </div>
    <div class="dotted"></div>
        <div class="block">
        <img class="left mr8" src="/images/quality/6.png" width="28" height="28" alt="">        <img src="/images/icons/equip.png" width="16" height="16" alt=""> <a href="/outfit/6/?'.$udet.'">Легендарное        <div class="clear"></div>
    </div>
    <div class="dotted"></div>
        <div class="block">
        <img class="left mr8" src="/images/quality/7.png" width="28" height="28" alt="">        <img src="/images/icons/equip.png" width="16" height="16" alt=""> <a href="/outfit/7/?'.$udet.'">Божественное        <div class="clear"></div>
    </div>
    <div class="dotted"></div>
        <div class="block">
        <img class="left mr8" src="/images/quality/8.png" width="28" height="28" alt="">        <img src="/images/icons/equip.png" width="16" height="16" alt=""> <a href="/outfit/8/?'.$udet.'">Сверх-божественное        <div class="clear"></div>
    </div>
    <div class="dotted"></div></a>';
}
  
include './system/f.php';

?>