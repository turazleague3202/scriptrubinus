<?
    
    include './system/common.php';
    
 include './system/functions.php';
        
      include './system/user.php';
    
if(!$user) {

  header('location: /');
    
exit;

}


    $title = 'Блатная малина';    

include './system/h.php';  

?>

   <div class="content"><div class="block center color3 s125">Блатная малина</div>
            <div class="line"></div>            


 

<?

$sort = _string($_GET['sort']);



    $max = 10;
  $count = mysql_result(mysql_query('SELECT COUNT(*) FROM `users`'),50);
  $pages = ceil(50/$max);
   $page = _string(_num($_GET['page']));

    if($page > $pages) {
    
   $page = $pages;
    
    }
  
    if($page < 1) {
    
   $page = 1;
    
    }
    
  $start = $page * $max - $max;


  if($page == 1) {
  
    $i = $page - 1;
  
  }
  elseif($page == 2) {
    
    $i = ($page + 9);
  
  }
  else
  {
  
    $i = ($page * 10) - 9;
  
  }

switch($sort) {
    default:
$q = mysql_query('SELECT * FROM `users` WHERE `access` = "0" ORDER BY `str`+`vit`+`def` DESC LIMIT '.$start.', '.$max.'');
      break;

}

  while($row = mysql_fetch_array($q)) {

  $i++;


$clan_memb = mysql_query('SELECT * FROM `clan_memb` WHERE `user` = "'.$row['id'].'"');
  $clan_memb = mysql_fetch_array($clan_memb);

  
    if($clan_memb) {

       $clanu = mysql_fetch_array(mysql_query('SELECT * FROM `clans` WHERE `id` = "'.$clan_memb['clan'].'"'));

 
    $clan_1 = ($clanu['built_1'] * 250);

    if($clanu['built_1'] > 0 && $clan_1) {
 
      $row['vit'] += $clan_1;

      $row['hp'] += $clan_1;

    }

 $clan_2 = ($clanu['built_2'] * 250);

 if($clanu['built_2'] > 0 && $clan_2) {
    
 
       $row['str'] += $clan_2;
    }

 $clan_3 = ($clanu['built_3'] * 250);

 if($clanu['built_3'] > 0 && $clan_3) {
  
      $row['def'] += $clan_3;
 
    }
}
  


    



    $w_1 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$row['id'].'" AND `id` = "'.$row['w_1'].'"');
    $w_1 = mysql_fetch_array($w_1);


if(!$w_1) {

$w_1['item'] = 0;

}

    $w_2 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$row['id'].'" AND `id` = "'.$row['w_2'].'"');
    $w_2 = mysql_fetch_array($w_2);

if(!$w_2) {

$w_2['item'] = 0;

}


    $w_3 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$row['id'].'" AND `id` = "'.$row['w_3'].'"');
    $w_3 = mysql_fetch_array($w_3);

if(!$w_3) {

$w_3['item'] = 0;

}


    $w_4 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$row['id'].'" AND `id` = "'.$row['w_4'].'"');
    $w_4 = mysql_fetch_array($w_4);

if(!$w_4) {

$w_4['item'] = 0;

}


    $w_5 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$row['id'].'" AND `id` = "'.$row['w_5'].'"');
    $w_5 = mysql_fetch_array($w_5);

if(!$w_5) {

$w_5['item'] = 0;

}


    $w_6 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$row['id'].'" AND `id` = "'.$row['w_6'].'"');
    $w_6 = mysql_fetch_array($w_6);

if(!$w_6) {

$w_6['item'] = 0;

}


    $w_7 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$row['id'].'" AND `id` = "'.$row['w_7'].'"');
    $w_7 = mysql_fetch_array($w_7);

if(!$w_7) {

$w_7['item'] = 0;

}


    $w_8 = mysql_query('SELECT * FROM `inv` WHERE `user` = "'.$row['id'].'" AND `id` = "'.$row['w_8'].'"');
    $w_8 = mysql_fetch_array($w_8);

if(!$w_8) {

$w_8['item'] = 0;

}

switch($sort) {
     default:

?>

<?

break;

    }

if($i < 5) {
?>

<?
if($i == 1){
?>

<div class="dotted"></div>
 <div class="block center s125"><?=$i?> место</div>
        <div class="dotted"></div>
                        <div class="block">
<?
if($row['r'] == 0) {
?>
       <a href="/user/<?=$row['id']?>/"><img class="left mr8" src="http://bespredel.mobi/maneken?sex=man&amp;width=120&amp;height=160&amp;fragment=0&amp;frame=images%2Fframes%2Ftop1.png&amp;equip%5B1%5D=<?=$w_1['item']?>&amp;equip%5B2%5D=<?=$w_2['item']?>&amp;equip%5B3%5D=<?=$w_3['item']?>&amp;equip%5B4%5D=<?=$w_4['item']?>&amp;equip%5B5%5D=<?=$w_5['item']?>&amp;equip%5B6%5D=<?=$w_6['item']?>&amp;equip%5B7%5D=<?=$w_7['item']?>&amp;equip%5B8%5D=<?=$w_8['item']?>" width="120" height="160" alt=""></a>


<?
}
if($row['r'] == 1) {
?>
       <a href="/user/<?=$row['id']?>/"><img class="left mr8" src="http://bespredel.mobi/maneken?sex=woman&amp;width=120&amp;height=160&amp;fragment=0&amp;frame=images%2Fframes%2Ftop1.png&amp;equip%5B1%5D=<?=$w_1['item']?>&amp;equip%5B2%5D=<?=$w_2['item']?>&amp;equip%5B3%5D=<?=$w_3['item']?>&amp;equip%5B4%5D=<?=$w_4['item']?>&amp;equip%5B5%5D=<?=$w_5['item']?>&amp;equip%5B6%5D=<?=$w_6['item']?>&amp;equip%5B7%5D=<?=$w_7['item']?>&amp;equip%5B8%5D=<?=$w_8['item']?>" width="120" height="160" alt=""></a>


<?
}
?>

 

                <?
if($row['vip'] == 0){
?>
<img src="/images/icons/<?=$row['r']?>.png" width="16" height="16" alt="">
<?

}
if($row['vip'] == 1){
?>
<img src="/images/icons/vip_<?=($row['r'] == man ? 'woman':'man')?>_<?=$row['r']?>.png" width="16" height="16" alt="">
<?
}
?>
    
 <a href="/user/<?=$row['id']?>/"><span><?=$row['login']?></span></a>         <span class="red">
    
    <img src="/images/icons/level.png" width="16" height="16" alt=""> <?=$row['level']?> ур.    </span>
    <div>
            
    <div>
    <img src="/images/icons/currentHealth.png" width="16" height="16" alt=""> Здоровье: <?=$row['vit']?>    </div>
            
    <div>
    <img src="/images/icons/damage.png" width="16" height="16" alt=""> Сила: <?=$row['str']?>    </div>
            
    <div>
    <img src="/images/icons/armor.png" width="16" height="16" alt=""> Защита: <?=$row['def']?>    </div>
            
    <div>
    <img src="/images/icons/currentEnergy.png" width="16" height="16" alt=""> Энергия: <?=$row['mana']?>    </div>
        </div>
<div class="clear"></div>
</div>
<?
}else {
?>

<div class="dotted"></div>
 <div class="block center s125"><?=$i?> место</div>
        <div class="dotted"></div>
                        <div class="block">

<?
if($row['r'] == 0) {
?>
       <a class="left mr8" href="/user/<?=$row['id']?>/"><img src="http://bespredel.mobi/maneken?sex=man&amp;width=120&amp;height=160&amp;fragment=0&amp;frame=&amp;equip%5B1%5D=<?=$w_1['item']?>&amp;equip%5B2%5D=<?=$w_2['item']?>&amp;equip%5B3%5D=<?=$w_3['item']?>&amp;equip%5B4%5D=<?=$w_4['item']?>&amp;equip%5B5%5D=<?=$w_5['item']?>&amp;equip%5B6%5D=<?=$w_6['item']?>&amp;equip%5B7%5D=<?=$w_7['item']?>&amp;equip%5B8%5D=<?=$w_8['item']?>" width="120" height="160" alt=""></a>


<?
}
if($row['r'] == 1) {
?>
       <a class="left mr8" href="/user/<?=$row['id']?>/"><img src="http://bespredel.mobi/maneken?sex=woman&amp;width=120&amp;height=160&amp;fragment=0&amp;frame=&amp;equip%5B1%5D=<?=$w_1['item']?>&amp;equip%5B2%5D=<?=$w_2['item']?>&amp;equip%5B3%5D=<?=$w_3['item']?>&amp;equip%5B4%5D=<?=$w_4['item']?>&amp;equip%5B5%5D=<?=$w_5['item']?>&amp;equip%5B6%5D=<?=$w_6['item']?>&amp;equip%5B7%5D=<?=$w_7['item']?>&amp;equip%5B8%5D=<?=$w_8['item']?>" width="120" height="160" alt=""></a>


<?
}
?>

                <?
if($row['vip'] == 0){
?>
<img src="/images/icons/<?=$row['r']?>.png" width="16" height="16" alt="">
<?

}
if($row['vip'] == 1){
?>
<img src="/images/icons/vip_<?=($row['r'] == man ? 'woman':'man')?>_<?=$row['r']?>.png" width="16" height="16" alt="">
<?
}
?>
    
 <a href="/user/<?=$row['id']?>/"><span><?=$row['login']?></span></a>         <span class="red">
    
    <img src="/images/icons/level.png" width="16" height="16" alt=""> <?=$row['level']?> ур.    </span>
    <div>
            
    <div>
    <img src="/images/icons/currentHealth.png" width="16" height="16" alt=""> Здоровье: <?=$row['vit']?>    </div>
            
    <div>
    <img src="/images/icons/damage.png" width="16" height="16" alt=""> Сила: <?=$row['str']?>    </div>
            
    <div>
    <img src="/images/icons/armor.png" width="16" height="16" alt=""> Защита: <?=$row['def']?>    </div>
            
    <div>
    <img src="/images/icons/currentEnergy.png" width="16" height="16" alt=""> Энергия: <?=$row['mana']?>    </div>
        </div>
<div class="clear"></div>
</div>



<?

}
    }
  

if($i >4) {
?>



<div class="dotted"></div>
            <div class="block center s125"><?=$i?>  место</div>
        <div class="dotted"></div>
                        <div class="block">            

<?
if($row['id']) {
if($row['r'] == 0) {
?>
       <a class="left mr8" href="/user/<?=$row['id']?>/"><img src="http://bespredel.mobi/maneken?sex=man&amp;width=120&amp;height=160&amp;fragment=1&amp;frame=&amp;equip%5B1%5D=<?=$w_1['item']?>&amp;equip%5B2%5D=<?=$w_2['item']?>&amp;equip%5B3%5D=<?=$w_3['item']?>&amp;equip%5B4%5D=<?=$w_4['item']?>&amp;equip%5B5%5D=<?=$w_5['item']?>&amp;equip%5B6%5D=<?=$w_6['item']?>&amp;equip%5B7%5D=<?=$w_7['item']?>&amp;equip%5B8%5D=<?=$w_8['item']?>" width="50" height="50" alt=""></a>


<?
}
if($row['r'] == 1) {
?>
       <a class="left mr8" href="/user/<?=$row['id']?>/"><img src="http://bespredel.mobi/maneken?sex=woman&amp;width=120&amp;height=160&amp;fragment=1&amp;frame=&amp;equip%5B1%5D=<?=$w_1['item']?>&amp;equip%5B2%5D=<?=$w_2['item']?>&amp;equip%5B3%5D=<?=$w_3['item']?>&amp;equip%5B4%5D=<?=$w_4['item']?>&amp;equip%5B5%5D=<?=$w_5['item']?>&amp;equip%5B6%5D=<?=$w_6['item']?>&amp;equip%5B7%5D=<?=$w_7['item']?>&amp;equip%5B8%5D=<?=$w_8['item']?>" width="50" height="50" alt=""></a>


<?
}
}
?>

                    <?
if($row['vip'] == 0){
?>
<img src="/images/icons/<?=$row['r']?>.png" width="16" height="16" alt="">
<?

}
if($row['vip'] == 1){
?>
<img src="/images/icons/vip_<?=($row['r'] == man ? 'woman':'man')?>_<?=$row['r']?>.png" width="16" height="16" alt="">
<?
}
?>
 <a href="/user/<?=$row['id']?>/"><span><?=$row['login']?></span></a>         <span class="red">
    
    <img src="/images/icons/level.png" width="16" height="16" alt=""> <?=$row['level']?> ур.    </span>
    <div>
            
    <img src="/images/icons/currentHealth.png" width="16" height="16" alt=""> <?=$row['vit']?>            
    <img src="/images/icons/damage.png" width="16" height="16" alt=""> <?=$row['str']?>            
    <img src="/images/icons/armor.png" width="16" height="16" alt=""> <?=$row['def']?>        </div>
<div class="clear"></div>
</div>      


<?

switch($sort) {
     default:

?>


<?

      break;
    
    }
?>

<br/>

<?

    }
  
  }
  

?>
   <div class="dotted"></div>
<ul class="pagination"><li class="next"><?=pages('/rating/'.$sort.'/?');?></li></ul>
</div>

<?
  
include './system/f.php';

?>